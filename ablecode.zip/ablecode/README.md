# Mode 2 UI

## Development

### Prerequisite:

- Node.js (11.3.0) - [Download here](https://nodejs.org/en/download/)
- NPM (6.4.1) - Node Package Manager comes with Node.js

You can check with the following commands on your terminal:
```
node --version

npm -v
```

### Installation

Go to the Root folder on the application, can be identified with having package.json, then run the following commands on the terminal of the location.

```
npm install
```
First time installation can take sometime, wait for it to complete.

### Running the application
1. Open a terminal and run the following command to start the server
```
npm run server
```
Following result will be shown:
```
> nodemon server/server.js

[nodemon] 2.0.2
[nodemon] to restart at any time, enter `rs`
[nodemon] watching dir(s): *.*
[nodemon] watching extensions: js,mjs,json
[nodemon] starting `node server/server.js`
info: [YYYY-MM-DDThh:mm:sss.SSSZ] => Server is running
```
2. Open another terminal to run the UI
```
npm start
```
Following result will be shown:
```
Compiled successfully!

You can now view mode-ui in the browser.

  Local:            http://localhost:3000/
  On Your Network:  http://127.0.0.1:3000/

Note that the development build is not optimized.
To create a production build, use npm run build.
```
The application will automatically launch on your default browser.

### Application PORTs:
```
Server: http://localhost:4000

Client: http://localhost:3000
```
