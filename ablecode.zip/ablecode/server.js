const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const logger = require('./server/services/logger.service');

const SearchRoute = require('./server/routes/search.route')();

const server = express();

server.use(bodyParser.urlencoded({ extended: false }));
server.use(bodyParser.json());

const PORT = process.env.PORT || 4000;



const HTTP_SERVER_ERROR = 500;
server.use(function(err, req, res, next) {
  if (res.headersSent) {
    return next(err);
  }

  return res.status(err.status || HTTP_SERVER_ERROR).render('500');
});

// server.use(function (req, res, next) {
//   process.on('unhandledRejection', function(reason, p) {
//     console.log("Unhandled Rejection:", reason.stack);
//     res.status(500).send('Unknown Error');
//     //or next(reason);
//   });
// });

//console.log("Envirement ========= ", process.env.NODE_ENV);
server.get("/test", (req, res) => {
  logger.info('test API was called!');
  res.send("Testing... 1 2 3 ...");
});

server.use(SearchRoute);

server.use(express.static(path.join(__dirname, "/build")));

server.get("*", (req, res) => {
  res.sendFile(path.join(__dirname + "/build/index.html"));
});

server.listen(PORT, () => {
  logger.info(`Server is running on ${PORT}`);
});