module.exports = {
  PES_SERVICE: {
    URL: 'https://gateway-dmz.optum.com/api/pdr/pes/professionals/v10.0/search'
  }
};