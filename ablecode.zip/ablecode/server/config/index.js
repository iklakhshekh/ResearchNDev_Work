const demo_config = require('./demo.config');

// Handle environment variables here

module.exports = demo_config;
