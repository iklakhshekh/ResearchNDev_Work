module.exports = {
    ES_SERVICE: {
        URL: 'http://search-api-able-test.origin-elr-core-nonprod.optum.com/api/search/providersearch/v1.0/res_able_result_search_page_incre_development/',
        EXPORT_URL: 'http://search-api-able-test.origin-elr-core-nonprod.optum.com/api/search/providerScrollSearch/v1.1/res_able_result_search_page_incre_development/',
        ABLE_PROFILE_URL: 'http://profile-api-able-test.origin-elr-core-nonprod.optum.com/api/providerProfile/profilepagesearch/v1.0/res_able_result_search_page_incre_development/res_able_profile_page3_incre_development/',
    }
};



