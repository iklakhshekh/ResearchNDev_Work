const es_config = require('./es.config');

// Handle environment variables here

module.exports = es_config;