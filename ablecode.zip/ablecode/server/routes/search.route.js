const express = require('express');
const { professionalsService, professionalsService_ES, professionalsServiceAbleProfile_ES } = require('../services/professionals.service');
const SearchRoute = express.Router();
function routes() {
  try {
    SearchRoute.route('/api/search').post(async (req, res) => {
      let professionalsResponse;
      if (req.body.action == "profile")
        professionalsResponse = await professionalsServiceAbleProfile_ES(req.body);
      else
        professionalsResponse = await professionalsService_ES(req.body);
      // console.log("*************************************")
      // console.log(professionalsResponse)
      // console.log("*************************************")
      res.send(professionalsResponse);
    });
    return SearchRoute;
  } catch (exp) {
    // console.log("*************************************")
    // console.log(exp)
    // console.log("*************************************")
    throw exp;

  }




}
module.exports = routes;