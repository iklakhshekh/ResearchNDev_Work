const { createLogger, transports, format } = require("winston");

const consoles = new transports.Console({
  level: 'info',
  format: format.combine(
    format.colorize(),
    format.simple(),
    format.timestamp(),
    format.printf(({ level, message, timestamp }) => {
      return `${level}: [${timestamp}] => ${message}`;
    })
  )
});

const logger = createLogger({exitOnError: false});

logger.add(consoles);

module.exports = logger;
