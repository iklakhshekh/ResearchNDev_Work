const request = require('request-promise').defaults({ rejectUnauthorized: false });
const axios = require('axios');
const logger = require('./logger.service');
const { PES_SERVICE } = require('../config/index');
const { ES_SERVICE } = require('../es_config/index');
const { error } = require('winston');
const { response } = require('express');

function professionalsService(body) {
  const url = PES_SERVICE.URL;
  const apiDetails = {
    url: url,
    form: {
      'active-ind': 'both',
      'app-nm': 'able',
      'attribute-set': 'summary_0006',
    },
    headers: {
      Accept: 'application/json'
    }
  };


  const requestDetails = setRequestBody(apiDetails, body);
  //console.log("request details",requestDetails)
  return new Promise((resolve, reject) => {
    request.post(requestDetails, (error, response, body) => {
      if (error || (response && response.statusCode >= 300)) {
        const errorMsg = error ? error : body;
        const statusCode = response ? response.statusCode : "N/A";
        logger.error({ message: errorMsg, error: statusCode });
        reject(errorMsg);
      } else {
        let data = JSON.parse(body);
        logger.info({ message: `Response: ${JSON.stringify(data.metadata)}` });
        resolve(data);
      }
    });
  });
}

function setRequestBody(requestDetails, body) {
  //console.log("body",body)
  const _form = requestDetails.form;
  if (body['lastGroupName']) {
    _form['prof-last-nm'] = body['lastGroupName'];
  }
  if (body.firstName) {
    _form['prof-first-nm'] = body.firstName;
  }
  if (body.telephone) {
    _form['phone-nbr'] = body.telephone;
  }
  if (body.areacode) {
    _form['area-cd'] = body.areacode;
  }
  if (body.state) {
    _form['st-cd'] = body.state;
  }
  if (body.zip) {
    _form['zip'] = body['zip'];
  }
  if (body.taxId) {
    _form['tax-id-nbr'] = body.taxId;
  } if (body.mpin) {
    _form['prov-id'] = body.mpin;
  }
  if (body.npi) {
    _form['npi-id'] = body.npi;
  }
  if (body.count) {
    _form["count"] = body.count;
  }
  //console.log("body.start",body.start)
  if (body.start) {
    _form["start"] = body.start;
  }
  /**
   * Following parameters are commented as
   * respecting PES parameter is not
   * available
  if (body.middleName) {
    _form[] = body.middleName;
  }
  if (body.ssn) {
    _form[] = body.ssn;
  }
  if (body.pfxsfx) {
    _form[] = body.pfxsfx;
  }
  if (body.ptiMpin) {
    _form[] = body.ptiMpin;
  }
  if (body.maid) {
    _form[] = body.maid;
  }
  if (body.baid) {
    _form[] = body.baid;
  }
  if (body.uhcid) {
    _form[] = body.uhcid;
  }
  if (body.bsar) {
    _form[] = body.bsar;
  }
  if (body.hccp) {
    _form[] = body.hccp;
  }
  if (body.decFac) {
    _form[] = body.decFac;
  }
  if (body.claimId) {
    _form[] = body.claimId;
  }
  if (body.pulseId) {
    _form[] = body.pulseId;
  }
  if (body.cspId) {
    _form[] = body.cspId;
  }
  */

  return {
    ...requestDetails,
    form: _form
  };
}

const professionalsServiceAbleProfile_ES = (searchParams) => {
  // console.log("ABLE data HERE11111 tutorials searchParams =========== ", searchParams);
  const url = ES_SERVICE.ABLE_PROFILE_URL;
  const apiDetails = {
    url: url,
    body: searchParams,
    json: true,
    headers: {
      Accept: 'application/json'
    }
  };


  return new Promise((resolve, reject) => {
    request.post(apiDetails, (error, response, body) => {

      // console.log("Error === ", error)
      // console.log("response === ", response)
      // console.log("body metadata === ", body)
      //console.log("body data === ", body.ProfessionalSummary0006Response.length )
      if (error || (response && response.statusCode >= 300)) {
        const errorMsg = error ? error : body;
        const statusCode = response ? response.statusCode : "N/A";
        logger.error({ message: errorMsg, error: statusCode });
        reject(errorMsg);
      } else {

        // let data = JSON.parse(body);
        //   logger.info({ message: `Response: ${JSON.stringify(body.metadata)}` });
        resolve(body);
      }
    })
  })
}

const professionalsService_ES = (searchParams) => {
  // console.log("ABLE API searchParams =========== ", searchParams);
  const userobj = searchParams.openIdInfo;
  const url = searchParams.action === "scroll" ? ES_SERVICE.EXPORT_URL : ES_SERVICE.URL;
  const apiDetails = {
    url: url,
    body: {
      "size": "50",
      "from": 0
    },
    json: true,
    headers: {
      Accept: 'application/json'
    }
  };

  const requestBody = setSearchRequestBody(apiDetails, searchParams);
  let date_ob = new Date();

  // current date
  // adjust 0 before single digit date
  let date = ("0" + date_ob.getDate()).slice(-2);

  // current month
  let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);

  // current year
  let year = date_ob.getFullYear();

  // current hours
  let hours = date_ob.getHours();

  // current minutes
  let minutes = date_ob.getMinutes();

  // current seconds
  let seconds = date_ob.getSeconds();
  if (requestBody.body.size == "50") {
    logger.log('info', "Date : " + year + "-" + month + "-" + date + " Time : " + hours + ":" + minutes + ":" + seconds);
    logger.log('info', `Parameters :  ${JSON.stringify(requestBody.body)}`);
  }
  return new Promise((resolve, reject) => {

    // axios.post(requestBody).then(res=>{
    //   console.log(res)
    //   resolve(res)
    // }).catch(err=>{
    //   console.log("************************",err)
    //   reject(err)
    // })

    request.post(requestBody, (error, response, body) => {
      console.log("response statusCode === ", response ? response.statusCode : "")
      // console.log("response statusCode === ", body)
      if (error || response.statusCode >= 300) {
        return resolve({ ok: false, body: body });
      } else {
        return resolve(body);
      }
    })
  })
}
function setSearchRequestBody(requestBody, searchParams) {
  // console.log("ES body ======= ", requestBody)
  // console.log("ES Requested searchParams ======= ", searchParams)
  const _body = requestBody.body;
  for (const key in searchParams) {
    if (key === "mpin" && searchParams[key] != "") {
      Object.assign(_body, { prov_id: searchParams.mpin });
    }
    if (key === "ptiMpin" && searchParams[key] != "") {
      Object.assign(_body, {
        "taxidinfo.paye_prov_id": searchParams.ptiMpin
      });
    }
    if (key === "maid" && searchParams[key] != "") {
      Object.assign(_body, {
        adr_id: parseInt(searchParams.maid)
      });
    }
    if (key === "baid" && searchParams[key] != "") {
      Object.assign(_body, { "addressinfo.bill_postal_information.bil_adr_id": parseInt(searchParams.baid) });
    }
    if (key === "uhcid" && searchParams[key] != "") {
      if (searchParams.uhcid.length == 16) {
        Object.assign(_body, {
          "addressinfo.uhcidinfo.uhc_id": searchParams.uhcid
        });
      }
      if (searchParams.uhcid.length == 4) {
        Object.assign(_body, {
          "addressinfo.uhcidinfo.uhc_id": searchParams.uhcid + '*'
        });
      }
      if (searchParams.uhcid.length == 12 || searchParams.uhcid.length == 13) {
        Object.assign(_body, {
          "addressinfo.uhcidinfo.uhc_id": searchParams.uhcid + '*'
        });
      }
      if (searchParams.uhcid.length == 3) {
        Object.assign(_body, {
          "addressinfo.uhcidinfo.uhc_id": '*' + searchParams.uhcid.toUpperCase()
        });
      }
    }
    if (key === "bsar" && searchParams[key] != "") {
      Object.assign(_body, {
        "addressinfo.bsarinfo.adr_rel_seq_nbr": searchParams.bsar
      });
    }
    if (key === "cspId" && searchParams[key] != "") {
      Object.assign(_body, {
        csp_id: searchParams.cspId
      });
    }
    if (key === "taxId" && searchParams[key] != "") {
      Object.assign(_body, { tax_id_nbr: parseInt(searchParams.taxId) });
    }
    if (key === "npi" && searchParams[key] != "") {
      Object.assign(_body, {
        "providerinformation.npiinfo.npi_id": searchParams.npi
      }); //need to varify
    }
    if (key === "ssn" && searchParams[key] != "") {
      Object.assign(_body, {
        "providerinformation.soc_secur_nbr": searchParams.ssn
      });
    }
    if (key === "pfxsfx" && searchParams[key] != "") {
      if (searchParams.pfxsfx.length <= 2) {
        let value = searchParams.pfxsfx.split(' ')
        Object.assign(_body, {
          "addressinfo.tops_tin_prfx_cd": value[0]
        });
      }
      else {
        let value = searchParams.pfxsfx.split(' ')
        Object.assign(_body, {
          "addressinfo.tops_tin_prfx_cd": value[0]
        });
        Object.assign(_body, {
          "addressinfo.tops_tin_sufx_cd": parseInt(value[1])
        });
      }
    }
    if (key === "lastGroupName" && searchParams[key] != "") {
      Object.assign(_body, {
        "providerinformation.lst_nm": searchParams.lastGroupName
      });
    }
    if (key === "firstName" && searchParams[key] != "") {
      Object.assign(_body, {
        "providerinformation.fst_nm": searchParams.firstName
      });
    }
    if (key === "middleName" && searchParams[key] != "") {
      Object.assign(_body, {
        "providerinformation.mdl_nm": searchParams.middleName
      });
    }
    if (key === "telephone" && searchParams[key] != "") {
      Object.assign(_body, {
        "addressinfo.telephoneinfo.tel_nbr": searchParams.telephone
      });
    }
    // if (key === "areacode" && searchParams[key] != "") {
    //   Object.assign(_body, {
    //     "addressinfo.telephoneinfo.area_cd": searchParams.areacode
    //   });
    // }
    if (key === "state" && searchParams[key] != "") {
      Object.assign(_body, {
        "addressinfo.postaladdressinfo.st_cd": searchParams.state
      });
    }
    if (key === "zip" && searchParams[key] != "") {
      Object.assign(_body, {
        "addressinfo.postaladdressinfo.zip_cd": parseInt(searchParams.zip)
      });
    }
    if (key === "action" && searchParams[key] != "") {
      Object.assign(_body, {
        "action": searchParams.action
      });
    }
    if (key === "user" && searchParams[key] != "") {
      Object.assign(_body, {
        "user": searchParams.user
      });
    }
    if (key === "totalCount" && searchParams[key] > 0) {
      Object.assign(_body, {
        "totalCount": searchParams.totalCount
      });
    }
    if (key === "responseTime" && searchParams[key] != "") {
      Object.assign(_body, {
        "responseTime": searchParams.responseTime
      });
    }
    if (key === "start" && searchParams[key] != "") {
      Object.assign(_body, {
        from: searchParams.start
      });
    }

    if (key === "count" && searchParams[key] != "") {
      Object.assign(_body, {
        size: searchParams.count
      });
    }
    if (key === "exCount") {
      if (searchParams[key] !== "0") {
        Object.assign(_body, {
          size: "5000"
        });
        Object.assign(_body, {
          from: "0"
        });
      }
    }
  }
  // console.log("ES _body ======= ", _body)
  return {
    ...requestBody,
    body: _body
  };
}

const ESwithPes = {
  professionalsService: professionalsService,
  professionalsService_ES: professionalsService_ES,
  professionalsServiceAbleProfile_ES: professionalsServiceAbleProfile_ES
}
// module.exports  = professionalsService_ES

// module.exports = professionalsService;
module.exports = ESwithPes
