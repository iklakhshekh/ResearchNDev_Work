/* eslint-disable */
import React from 'react'
import { Link, useLocation } from 'react-router-dom';

// import UHC_LOGO from '../../assets/UHC_LOGO.svg';
import UHC_LOGO from '../assets/banner_error_404.jpg';
import { withStyles } from '@material-ui/core/styles';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import PersonIcon from '@material-ui/icons/Person';
import Typography from '@material-ui/core/Typography';
import IconButton from '@material-ui/core/IconButton';

const useStyles = theme => ({
  root: {
    flexGrow: 1
  },
  customAppBar: {
    boxShadow: '0px 0px 0px 0px',
    backgroundColor: '#FFFFFF'
  },
  logo: {
    margin: '15px 0px 10px 25px',
    maxWidth: '180px'
  },
  profileHead: {
    display: 'inline-flex'
  },
  profileText: {
    marginTop: '1em',
    userSelect: 'none',
    color: '#757588',
    fontWeight: 'bold'
  },
  tabRoot: {
    textTransform: 'none'
  },
  panelBg: {
    backgroundColor: '#F9F9F9'
  },
  panel: {
    width: 300
  },
  card: {
    width: 280,
    margin: '0px 10px'
  },
  cardAction: {
    float: 'right'
  }
});


export class Error_page extends React.Component {
  
    constructor(props) {
      super(props);
      this.state = { hasError: false };
    }
  
    static getDerivedStateFromError(error) {
      // Update state so the next render will show the fallback UI.
      return { hasError: true };
    }
  
      // componentDidCatch(error, errorInfo) {
      //   // You can also log the error to an error reporting service
      //   logErrorToMyService(error, errorInfo);
      // }
  
    render() {
      const { classes } = this.props;
      if (this.state.hasError) {
        // You can render any custom fallback UI
        return   <AppBar position="static" className={classes.customAppBar}>
        <Toolbar variant="dense" classes={{ dense: classes.toolBarDenseCustom }}>
            <div className={classes.gap} />
            <img src={UHC_LOGO} alt="UHC_LOGO" heigth="" width="100%" />
        </Toolbar></AppBar>

      }
  
      return this.props.children; 
    }
  }
  
  export default withStyles(useStyles) (Error_page)