/* eslint-disable */
const demo_config = require('./sso.config');

// Handle environment variables here

module.exports = demo_config;
