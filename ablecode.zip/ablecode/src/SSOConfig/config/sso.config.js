/* eslint-disable */
module.exports = {
 
  //group Able_test_user
  SSO_TEST_LINK: {
    URL: 'https://authgateway1-dev.entiam.uhg.com/as/authorization.oauth2?response_type=token id_token&client_id=Reg1Test_Able&redirect_uri=http://localhost:50911/&acr_values=R1_AAL1_MS-AD-Kerberos&scope=openid%20profile%20address%20email%20phone&nonce=test'
  }
  //Able_dev_user
  ,
  SSO_DEV_LINK: {
    //URL: 'https://authgateway1-dev.entiam.uhg.com/as/authorization.oauth2?response_type=token id_token&client_id=Reg1Dev_Able&redirect_uri=http://abledev.uhg.com/&acr_values=R1_AAL1_MS-AD-Kerberos&scope=openid%20profile%20address%20email%20phone&nonce=test'
   URL: 'https://authgateway1-dev.entiam.uhg.com/as/authorization.oauth2?response_type=token id_token&client_id=Reg1Dev_Able&redirect_uri=http://localhost:50911/&acr_values=R1_AAL1_MS-AD-Kerberos&scope=openid%20profile%20address%20email%20phone&nonce=test'
  },
  // group Able_stg_user 
  SSO_stage_LINK: {
 //   URL: 'https://authgateway1-stg.entiam.uhg.com/as/authorization.oauth2?response_type=token%20id_token&client_id=Reg1Stg_Able&redirect_uri=http://localhost:50911/&acr_values=R1_AAL1_MS-AD-Kerberos&scope=openid%20profile%20address%20email%20phone&nonce=test'
    URL: 'https://authgateway1-stg.entiam.uhg.com/as/authorization.oauth2?response_type=token id_token&client_id=Reg1Stg_Able&redirect_uri=https://ablestage.uhg.com&acr_values=R1_AAL1_MS-AD-Kerberos&scope=openid%20profile%20address%20email%20phone&nonce=test'   
  },
   //Group Able_Prod
   SSO_PROD_LINK: {
    URL: 'https://authgateway1.entiam.uhg.com/as/authorization.oauth2?response_type=token%20id_token&client_id=Reg1_Able&redirect_uri=https://able.uhg.com&acr_values=R1_AAL1_MS-AD-Kerberos&scope=openid%20profile%20address%20email%20phone&nonce=test%27'
  }
  
};

