/* eslint-disable */
import fetch from 'isomorphic-fetch';

import {
  UPDATE_DEMOGRAPHICS,
  UPDATE_UNIVERSALS,
  UPDATE_PLATFORMS,
  FETCHING_SEARCH_RESULTS,
  FETCHED_SEARCH_RESULTS_SUCCESS,
  REMOVE_FILTER,
  REMOVE_RESULTS,
  CLEAR_ALL,
  SELECTED_MPIN,
  FETCHED_SEARCH_RESULTS_SUCCESS_FOR_EXCEL,
  UPDATE_DISABLE_BUTTON_ON_ERROR,
  ERROR_RESPONSE,
  FETCHED_SEARCH_RESULTS_SUCCESS_FOR_EXCEL_PARAMS,
  EXCEL_RESPONSE_FOR_LOG,
  FETCHED_ABLE_PROFILE_PAGE_RESULTS
} from '../utils/redux.constant';

export const setSelectedMPIN = value => ({
  type: SELECTED_MPIN,
  value
});

export const setDemographicsInput = (field, value) => ({
  type: UPDATE_DEMOGRAPHICS,
  field,
  value
});

export const setUniversalInput = (field, value) => ({
  type: UPDATE_UNIVERSALS,
  field,
  value
});
export const setErrorInput = (field, value) => ({
  type: UPDATE_DISABLE_BUTTON_ON_ERROR,
  field,
  value
});

export const setPlatformInput = (field, value) => ({
  type: UPDATE_PLATFORMS,
  field,
  value
});

export const removeResultFilter = fieldName => ({
  type: REMOVE_FILTER,
  fieldName
});

export const clearAll = () => ({
  type: CLEAR_ALL
});
export function fetchResults(queryParam) {
  return dispatch => {
    dispatch({
      type: FETCHED_SEARCH_RESULTS_SUCCESS_FOR_EXCEL_PARAMS,
      exParams: queryParam
    });
    dispatch({
      type: FETCHING_SEARCH_RESULTS
    });
    fetch('/api/search', {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(queryParam)
    }).then(response => response.json())
      .then(data => dispatch({
        type: FETCHED_SEARCH_RESULTS_SUCCESS,
        data: data.ProfessionalSummary0006Response,
        metadata: data.metadata,
        searchParams: queryParam,
      }));
  }
}


export function getAbleProfileData(queryParam) {
  // debugger
  return dispatch => {

    fetch('/api/search', {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(queryParam)
    }).then(response => response.json())
      .then(responseJson => dispatch({
        type: FETCHED_ABLE_PROFILE_PAGE_RESULTS,
        payload: responseJson,
        // metadata: responseJson.metadata,
        // searchParams: queryParam,
      }));
  }

  //   console.log("ABLE data HERE11111 tutorials queryParam =========== ", queryParam);
  // const request=   async  ()=>{
  // const response= await   fetch('https://profile-api-able-stage.ocp-elr-core-stg.optum.com/api/providerProfile/profilepagesearch/v1.0/res_able_result_search_page_incre/res_able_profile_page3/', {
  //       method: 'POST',
  //       headers: {
  //         'Accept': 'application/json',
  //         'Content-Type': 'application/json'
  //       },
  //       body: JSON.stringify(queryParam)
  //     })

  //   return await response;
  //   }

  //     return dispatch => {

  //       request().then(response => response.json())
  //       .then(responseJson => 
  //         dispatch({
  //         type: FETCHED_ABLE_PROFILE_PAGE_RESULTS,
  //         payload: responseJson,
  //         metadata: responseJson.metadata,
  //         searchParams: queryParam,
  //       })

  //       );
  //     } ;
}

export function fetchResultsForExcel(queryParam) {
  if (queryParam.action === "scroll") {
    return dispatch => {
      setTimeout(() => {
        fetch('/api/search', {
          method: 'POST',
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(queryParam)
        }).then(response => {
          // console.log(response)
          return response.json();
        }).then(data => {
          // console.log(data)
          if (!data.ok && data.ok !== undefined) {
            dispatch({
              type: FETCHED_SEARCH_RESULTS_SUCCESS_FOR_EXCEL,
              excelData: [],
              excelMetadata: {},
              isHeavyData: true
            })
          } else {
            dispatch({
              type: FETCHED_SEARCH_RESULTS_SUCCESS_FOR_EXCEL,
              excelData: data.ProfessionalSummary0006Response,
              excelMetadata: data.metadata,
              isHeavyData: false
            })
          }
        })
          .catch(err => {
            console.log(err.message)
          })
      }, 1000)

      // .then(response => response.json())
      //   .then(data => dispatch({
      //     type: FETCHED_SEARCH_RESULTS_SUCCESS_FOR_EXCEL,
      //     excelData: data.ProfessionalSummary0006Response,
      //     excelMetadata: data.metadata
      //   }));
    }
  } else if (queryParam.action === "export") {
    return dispatch => {
      fetch('/api/search', {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(queryParam)
      }).then(response => [])
        .then(data => dispatch({
          type: EXCEL_RESPONSE_FOR_LOG,
          // excelData: data.ProfessionalSummary0006Response,
        }));
    }
  } else return





  // return dispatch => {
  //   // dispatch({
  //   //   type: FETCHED_SEARCH_RESULTS_SUCCESS_FOR_EXCEL,
  //   //   excelData: [{ "name": "rohit" }]
  //   // });
  //   // const controller = new AbortController();
  //   // "signal": controller.signal,
  //   fetch('/api/search', {
  //     method: 'POST',
  //     headers: {
  //       'Accept': 'application/json',
  //       'Content-Type': 'application/json'
  //     },
  //     body: JSON.stringify(queryParam)
  //   }).then(response => response.json())
  //     .then(data => dispatch({
  //       type: FETCHED_SEARCH_RESULTS_SUCCESS_FOR_EXCEL,
  //       excelData: data.ProfessionalSummary0006Response
  //     }))
  // }
}
export const clearResults = () => {
  return dispatch => {
    dispatch({
      type: FETCHED_SEARCH_RESULTS_SUCCESS_FOR_EXCEL_PARAMS,
      exParams: {}
    });
    dispatch({
      type: REMOVE_RESULTS
    });
    dispatch({
      type: FETCHED_SEARCH_RESULTS_SUCCESS_FOR_EXCEL,
      excelData: [],
    });
  }
  // type: REMOVE_RESULTS
  // type:FETCHED_SEARCH_RESULTS_SUCCESS_FOR_EXCEL
};