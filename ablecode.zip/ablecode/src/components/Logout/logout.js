/* eslint-disable */
import React, { useContext }  from 'react';
import { UserContext } from '../../UserContext';
import '../../styles/custom.css';
import Button from '@material-ui/core/Button';
import initUrlFun from '../../utils/initUrls'
function HomeButton() {
    const user = useContext(UserContext);
    function handleClick() {
        window.location.href = initUrlFun();
    }
  
    return (
      <center><br/><br/><div class=""><br/><br/><br/><br/><p style={{fontSize:"large"}}>You have been successfully signed out</p><p style={{fontSize:"large"}}>We would like to hear what you think of <b>ABLE</b>. Please click the <b>Feedback</b> button above.</p><br/><Button style={{backgroundColor:"#0096fb", color:"white"}} variant="contained" onClick={handleClick}>Return to Able</Button></div></center> 
    );
  }
 
export default HomeButton;