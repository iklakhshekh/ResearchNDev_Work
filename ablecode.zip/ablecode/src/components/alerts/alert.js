/* eslint-disable */
import React from 'react';
import { Link, useLocation } from 'react-router-dom';

// import UHC_LOGO from '../../assets/UHC_LOGO.svg';

import { makeStyles } from '@material-ui/core/styles';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import PersonIcon from '@material-ui/icons/Person';
import Typography from '@material-ui/core/Typography';
import IconButton from '@material-ui/core/IconButton';


const useStyles = makeStyles(() => ({
  root: {
    flexGrow: 1
  },
  customAppBar: {
    boxShadow: '0px 0px 0px 0px',
    backgroundColor: '#FFFFFF'
  },
  logo: {
    margin: '15px 0px 10px 25px',
    maxWidth: '180px'
  },
  profileHead: {
    display: 'inline-flex'
  },
  profileText: {
    marginTop: '1em',
    userSelect: 'none',
    color: '#757588',
    fontWeight: 'bold'
  },
  tabRoot: {
    textTransform: 'none'
  },
  panelBg: {
    backgroundColor: '#F9F9F9'
  },
  panel: {
    width: 300
  },
  card: {
    width: 280,
    margin: '0px 10px'
  },
  cardAction: {
    float: 'right'
  }
}));

const TabList = [
  // {
  //   label: 'Home',
  //   path: 'home'
  // },
  {
    label: 'Search Provider',
    path: 'search-provider'
  }
  // ,
  // {
  //   label: 'Request list',
  //   path: 'request-list'
  // }
];

export default function HeaderComponent() {
  const classes = useStyles();
  const { pathname } = useLocation();
  const [state, setState] = React.useState({
    anchorElement: null,
    selectedTab: 0,
    showPanel: false
  });
  const open = Boolean(state.anchorElement);

  const id = open ? 'profile-options-id' : undefined;

  const paths = pathname.split('/');
  if (paths[1] === 'providers' && paths[2]) {
    const index = TabList.findIndex(({path}) => path === paths[2]);
    if (state.selectedTab !== index) {
      if (paths[2] === 'result-provider' && state.selectedTab !== 1) {
        setState({...state, selectedTab: 1});
      } else if (index !== -1) {
        setState({...state, selectedTab: index});
      }
    }
  }

  return (
    <div className={classes.root}>
      <AppBar position="static" color="default" className={classes.customAppBar}>
        <Toolbar>
          <Typography>Alert section coming soon........</Typography>
        </Toolbar>
            </AppBar>
          </div>
  );
}
