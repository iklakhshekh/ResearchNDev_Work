/* eslint-disable */
import React from 'react';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import UHC_LOGO from '../../assets/UHC_LOGO.png';
import { makeStyles } from '@material-ui/core/styles';
import '../../styles/custom.css';

const useStyles = makeStyles(() => ({
    modelview: {
      //backgroundColor:"gray",
      textAlign: "center",
      color: "red"
    },
    root: {
      flexGrow: 1,
    },
    customAppBar: {
      boxShadow: '0px 0px 0px 0px'
    },
    customButton: {
      color: '#FFFFFF',
      textTransform: 'none',
      fontWeight: 'bold',
      '&:hover': {
        color: '#3f51b5',
        backgroundColor: '#FFFFFF',
        borderRadius: 0
      }
    },
    toolBarDenseCustom: {
      minHeight: 0
    },
    activeLink: {
      color: '#196ECF',
      backgroundColor: '#FFFFFF',
      borderRadius: 0
    },
    gap: {
      flexGrow: 1
    }
  }));
const AuthorizationError = props => {
    const classes = useStyles();
    let { isLoading } = props;
    return (

        isLoading == false ? <React.Fragment><AppBar position="static" className={classes.customAppBar}>
            <Toolbar variant="dense" classes={{ dense: classes.toolBarDenseCustom }}>
                <div className={classes.gap} />
                <img src={UHC_LOGO} alt="UHC_LOGO" heigth="38" width="175" />
            </Toolbar>

        </AppBar><div className="authError"><br /><br /><br /><center>You are not authorized to use ABLE. Please  <a href="https://helpdesk.uhg.com/knowledge-center/personal-hardware-software/general-applications/able/222778" target="_blank">CLICK HERE</a>  to read access instructions</center></div></React.Fragment> : <div></div>
    );
}
// function AuthorizationError(isLoading){
//     debugger
// return (
//     isLoading==false?
//     <div>You are not authorized to proceed, Kindly contact your supervisor.</div>:<div></div>
// );
// }

export default AuthorizationError;