/* eslint-disable */
import React, { useContext } from 'react';
import { UserContext } from '../../UserContext';
import { Link, useLocation } from 'react-router-dom';

// import UHC_LOGO from '../../assets/UHC_LOGO.svg';
import { useHistory } from "react-router-dom";
import { makeStyles } from '@material-ui/core/styles';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import PersonIcon from '@material-ui/icons/Person';
import Typography from '@material-ui/core/Typography';
import IconButton from '@material-ui/core/IconButton';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import Menu from '@material-ui/core/Menu';
import MenuItem from '@material-ui/core/MenuItem';
import NotificationsNoneOutlinedIcon from '@material-ui/icons/NotificationsNoneOutlined';
import Badge from '@material-ui/core/Badge';
// import Tabs from '@material-ui/core/Tabs';
// import Tab from '@material-ui/core/Tab';
import Drawer from '@material-ui/core/Drawer';
import List from '@material-ui/core/List';
import Divider from '@material-ui/core/Divider';
import Card from '@material-ui/core/Card';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import ClearIcon from '@material-ui/icons/Clear';
const { getCookie, deleteCookie } = require('../../utils/helper');
import  initUrlFun   from '../../utils/initUrls'
const useStyles = makeStyles(() => ({
  root: {
    flexGrow: 1
  },
  customAppBar: {
    boxShadow: '0px 0px 0px 0px',
    backgroundColor: '#FFFFFF'
  },
  logo: {
    margin: '15px 0px 10px 25px',
    maxWidth: '180px'
  },
  profileHead: {
    display: 'inline-flex'
  },
  profileText: {
    marginTop: '1em',
    userSelect: 'none',
    color: '#757588',
    fontWeight: 'bold'
  },
  tabRoot: {
    textTransform: 'none'
  },
  panelBg: {
    backgroundColor: '#F9F9F9'
  },
  panel: {
    width: 300
  },
  card: {
    width: 280,
    margin: '0px 10px'
  },
  cardAction: {
    float: 'right'
  }
}));

const TabList = [
  // {
  //   label: 'Home',
  //   path: 'home'
  // },
  {
    label: 'Search Provider',
    path: 'search-provider'
  }
  // ,
  // {
  //   label: 'Request list',
  //   path: 'request-list'
  // }
];

export default function HeaderComponent() {

  // console.log('initUrl =========== ', initUrlFun())
  let history = useHistory();
  const classes = useStyles();
  const { pathname } = useLocation();
  const user = useContext(UserContext);
  const [state, setState] = React.useState({
    anchorElement: null,
    selectedTab: 0,
    showPanel: false,
    isloggedOut: false
  });

  const handleProfileOptionClick = event => setState({ ...state, anchorElement: event.currentTarget });

  const handleProfileOptionClose = () => setState({ ...state, anchorElement: null });

  const handleTabChange = (event, newTab) => setState({ ...state, selectedTab: newTab });
  const handlelogout = () => {
    setState({ ...state, anchorElement: null });
    user.setLogoutStatus(true);
    deleteCookie("oAuthAccessTokenInfo");
    deleteCookie("openIdInfo");
    history.push("/logout")
  };
  const toggleNotificationPanel = open => event => {
    if (event.type === 'keydown' && (event.key === 'Tab' || event.key === 'Shift')) {
      return;
    }
    setState({ ...state, showPanel: open });
  }
//'http://localhost:50911/'
  const open = Boolean(state.anchorElement);
  const userObj = JSON.parse(getCookie("openIdInfo"));
  let user_name;
  if (userObj == null) {
    window.location.href = initUrlFun();
    //  user_name=user_name_back;
  }
  else {
    user_name = userObj.name;
    //user_name_back=userObj.name;
  }


  const id = open ? 'profile-options-id' : undefined;

  const paths = pathname.split('/');
  if (paths[1] === 'providers' && paths[2]) {
    const index = TabList.findIndex(({ path }) => path === paths[2]);
    if (state.selectedTab !== index) {
      if (paths[2] === 'result-provider' && state.selectedTab !== 1) {
        setState({ ...state, selectedTab: 1 });
      } else if (index !== -1) {
        setState({ ...state, selectedTab: index });
      }
    }
  }

  return (
    <div className={classes.root}>
      <AppBar position="static" color="default" className={classes.customAppBar}>
        <Toolbar>
          {/* <div className={classes.logo}>
            <img src={UHC_LOGO} alt="UHC_LOGO" heigth="38" width="175" />
          </div> */}
          <div className={classes.root} />
          <div className={classes.profileHead}>
            <IconButton aria-label="profile-icon" >
              <PersonIcon />
            </IconButton>
            <Typography variant="body1" className={classes.profileText}>
              Welcome {user_name}
            </Typography>
            <IconButton aria-label="profile-options" aria-describedby={id} onClick={handleProfileOptionClick}>
              <ExpandMoreIcon />
            </IconButton>
            <IconButton aria-label="notifications" onClick={toggleNotificationPanel(true)}>
              {/* <Badge color="secondary" variant="dot" className={classes.margin}></Badge> */}
              <NotificationsNoneOutlinedIcon />
            </IconButton>
          </div>
        </Toolbar>
        {/* <Tabs
          variant="standard"
          indicatorColor="primary"
          value={state.selectedTab}
          onChange={handleTabChange}
          textColor="primary"
        >
          {
            TabList.map((tabItem, idx) => (
              <Tab key={idx} label={tabItem.label} component={Link}  classes={{root: classes.tabRoot}} to={`/providers/${tabItem.path}`} />
            ))
          }
        </Tabs> */}
      </AppBar>
      <Divider />
      <Menu
        id={id}
        anchorEl={state.anchorElement}
        keepMounted
        open={open}
        onClose={handleProfileOptionClose}
        aria-label="page tabs"
      >
        <MenuItem onClick={handleProfileOptionClose}>Profile</MenuItem>
        <MenuItem onClick={handleProfileOptionClose}>My account</MenuItem>
        <MenuItem onClick={handlelogout}>Logout</MenuItem>
      </Menu>
      <Drawer
        anchor="right"
        open={state.showPanel}
        onClose={toggleNotificationPanel(false)}
        classes={{ paper: classes.panelBg }}
      >
        <div
          className={classes.panel}
          role="presentation"
        >
          <List>
            <Card className={classes.card}>
              {/* 
              <CardActions className={classes.cardAction}>
                <IconButton aria-label="delete-notification">
                  <ClearIcon fontSize="small" />
                </IconButton>
              </CardActions>
*/}
              <CardContent>
                <Typography>
                  You have no new notification.
               </Typography>
              </CardContent>
            </Card>
          </List>
        </div>
      </Drawer>
    </div>
  );
}
