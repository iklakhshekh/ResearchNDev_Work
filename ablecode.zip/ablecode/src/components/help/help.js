/* eslint-disable */
import React from 'react';
import { Link, useLocation } from 'react-router-dom';

// import UHC_LOGO from '../../assets/UHC_LOGO.svg';

import { makeStyles } from '@material-ui/core/styles';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import PersonIcon from '@material-ui/icons/Person';
import PlayCircleFilledIcon from '@material-ui/icons/PlayCircleFilled';
import Typography from '@material-ui/core/Typography';
import IconButton from '@material-ui/core/IconButton';


const useStyles = makeStyles(() => ({
  root: {
    flexGrow: 1
  },
  customAppBar: {
    boxShadow: '0px 0px 0px 0px',
    backgroundColor: '#FFFFFF'
  },
  logo: {
    margin: '15px 0px 10px 25px',
    maxWidth: '180px'
  },
  profileHead: {
    display: 'inline-flex'
  },
  profileText: {
    marginTop: '1em',
    userSelect: 'none',
    color: '#757588',
    fontWeight: 'bold'
  },
  tabRoot: {
    textTransform: 'none'
  },
  panelBg: {
    backgroundColor: '#F9F9F9'
  },
  panel: {
    width: 300
  },
  card: {
    width: 280,
    margin: '0px 10px'
  },
  cardAction: {
    float: 'right'
  }
}));

const TabList = [
  // {
  //   label: 'Home',
  //   path: 'home'
  // },
  {
    label: 'Search Provider',
    path: 'search-provider'
  }
  // ,
  // {
  //   label: 'Request list',
  //   path: 'request-list'
  // }
];

export default function HeaderComponent() {
  const classes = useStyles();
  const { pathname } = useLocation();
  const [state, setState] = React.useState({
    anchorElement: null,
    selectedTab: 0,
    showPanel: false
  });
  const open = Boolean(state.anchorElement);

  const id = open ? 'profile-options-id' : undefined;

  const paths = pathname.split('/');
  if (paths[1] === 'providers' && paths[2]) {
    const index = TabList.findIndex(({path}) => path === paths[2]);
    if (state.selectedTab !== index) {
      if (paths[2] === 'result-provider' && state.selectedTab !== 1) {
        setState({...state, selectedTab: 1});
      } else if (index !== -1) {
        setState({...state, selectedTab: index});
      }
    }
  }

  return (
    <div className={classes.root}>
      <AppBar position="static" color="default" className={classes.customAppBar}>
      
           <br/>
          <p style={{fontSize:"22px",marginLeft:"37px"}}><b>Information about ABLE</b></p>
          {/* <p style={{marginLeft:"37px",marginTop:"1px",fontSize:"16px",color:"#4141d7"}}><b>Description:</b></p> */}
          <p style={{marginLeft:"37px",fontSize:"15px"}}>In ABLE v1.0 users can view provider demographic data associated with the UHN contracting org.  After future enhancements, ABLE will deliver a simplified user interface with abilities to perform demographic data maintenance for NDB.</p>
         
          <p style={{marginLeft:"37px",fontSize:"15px"}}>To learn more, <a href="https://learnsource.uhg.com/psp/lpspr1/EMPLOYEE/ELM/s/WEBLIB_UHC_LM.LM_ISCRIPT.FieldFormula.IScript_GoTo_Search?UHC_CAT=363660" target="_blank">Click here</a> to view the ABLE Introduction video in LearnSource</p>
          
          <p style={{marginLeft:"37px",marginTop:"10px",fontSize:"15px",color:"#4141d7"}}><a href="https://helpdesktools.uhg.com/tools/KnowledgeDetails/Contents?OKI=196061" target="_blank" >ABLE Knowledge Articles</a></p>
       
          <p style={{marginLeft:"37px",fontSize:"15px",marginTop:"9px"}}><a href="https://uhgazure.sharepoint.com/sites/ABLE/_layouts/15/listform.aspx?PageType=8&ListId=%7BDDD9E142-9E20-4D97-81D3-3CFE7BDCD651%7D&RootFolder=%2Fsites%2FABLE%2FLists%2FTicket_List&Source=https%3A%2F%2Fuhgazure.sharepoint.com%2Fsites%2FABLE%2FLists%2FTicket_List%2FAllItems.aspx%3Fviewpath%3D%252Fsites%252FABLE%252FLists%252FTicket_List%252FAllItems.aspx&ContentTypeId=0x0100531E01945C06FF4F9C229B6D3270403C" target="_blank"> Click here to submit a feedback</a></p>
       
          <p style={{marginLeft:"37px",fontSize:"15px",marginTop:"9px"}}><a href="https://uhgazure.sharepoint.com/:w:/r/sites/ABLE/Shared%20Documents/ABLE%20User%20Guide.docx " target="_blank">Click here for ABLE User Guide</a></p>

          {/* <p style={{marginLeft:"37px",fontSize:"15px",marginTop:"9px"}}><a href="https://helpdesk.uhg.com/knowledge-center/personal-hardware-software/general-applications/able/222777" target="_blank">Information about ABLE</a></p> */}

          <br/><br/><br/>  <br/>  <br/>  <br/>  <br/>  <br/>  <br/> <br/>  <br/> <br/>  <br/><br/>  <br/>
        </AppBar>
          </div>
  );
}
