/* eslint-disable */
import React from 'react';
import { clearAll } from '../../actions/action';

// import HeaderComponent from '../header/header.component';
import ProviderRouter from '../../routers/providerRouter';

export default function ProviderComponent() {
  React.useEffect(() => {
    clearAll();
  });
  return (
    <div>
      {/* <HeaderComponent /> */}
      <ProviderRouter />
    </div>
  );
}
