/* eslint-disable */
import React from 'react'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'
import { Container } from 'react-bootstrap';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
//import 'bootstrap/dist/css/bootstrap.min.css';
import Table from 'react-bootstrap/Table'
import Moment from 'moment';
export const NameSection = ({ isArrow, dummyData, Name, isHideNameSection }) => {
    // debugger
    let arr = dummyData.arr
    // console.log("isHideNameSection ===== ",isHideNameSection)

    return (
        <div className="App">
            {/* <h3> Name Section </h3> */}

            <Container fluid > { /* Stack the columns on mobile by making one full-width and the other half-width */}
                <Row style={
                    { color: "#b3b3b3", textAlign: "right", width: "100rm", border: "0px solid black" }
                } >
                    <Col style={
                        { fontFamily: "Calibri", fontSize: "1em", border: "0px solid black" }
                    }
                        md={4} > </Col>
                    <Col style={
                        { fontFamily: "Calibri", fontSize: "1em", paddingLeft: "1.4em", textAlign: "left", border: "0px solid black" }
                    }
                        md={2} > Level </Col>
                    <Col style={
                        { fontFamily: "Calibri", fontSize: "1em", textAlign: "left", paddingLeft: "1.4em", border: "0px solid black" }
                    }
                        md={2} > Tax ID / Type </Col>
                    <Col style={
                        { fontFamily: "Calibri", fontSize: "1em", textAlign: "left", paddingLeft: "1.4em", border: "0px solid black" }
                    }
                        md={2} > MAID / Type </Col>
                    <div style={{ display: isHideNameSection ? "" : "none" }}><Col style={
                        { fontFamily: "Calibri", fontSize: "1em", textAlign: "left", paddingLeft: "0.4em", border: "0px solid black" }
                    }

                        md={1} >AltN Type </Col></div>
                    <div style={{ display: isHideNameSection ? "" : "none" }}><Col style={
                        { fontFamily: "Calibri", fontSize: "1em", textAlign: "left", paddingLeft: "0.7em", border: "0px solid black" }
                    }
                        md={1} >Act Cd</Col></div>
                </Row >
                <Row style={{ textAlign: "left", border: "0px solid black" }
                } >
                    <Col style={
                        { fontFamily: "Calibri", fontSize: "1em", fontWeight: "bold", paddingRight: "2.2em", border: "0px solid black" }
                    }
                        md={1} > Name: </Col>
                    <Col style={
                        { fontFamily: "Calibri", fontSize: "1em", textAlign: "left", border: "0px solid black" }
                    }
                        md={3} > {Name.lst_nm} </Col>
                    <    Col style={
                        { fontFamily: "Calibri", fontSize: "1em", textAlign: "left", paddingLeft: "1.4em", border: "0px solid black" }
                    }
                        md={2} >  </Col>
                    <        Col style={
                        { fontFamily: "Calibri", fontSize: "1em", textAlign: "left", paddingLeft: "1.4em", border: "0px solid black" }
                    }
                        md={2} >  </Col>
                    <            Col style={
                        { fontFamily: "Calibri", fontSize: "1em", textAlign: "left", paddingLeft: "1.4em", border: "0px solid black" }
                    }
                        md={2} > </Col>

                    <div style={{ display: isHideNameSection ? "" : "none" }}><Col style={
                        { fontFamily: "Calibri", fontSize: "1em", textAlign: "left", paddingLeft: "0.4em", border: "0px solid black" }
                    }
                        md={1} >  </Col></div>
                    <div style={{ display: isHideNameSection ? "" : "none" }}><Col style={
                        { fontFamily: "Calibri", fontSize: "1em", textAlign: "left", paddingLeft: "0.7em", border: "0px solid black" }
                    }
                        md={1} >  </Col></div>
                </Row >
                {isHideNameSection ?
                    <Row style={
                        { textAlign: "right", border: "0px solid black", overflow: "auto" }
                    } >
                        <Col style={
                            { fontFamily: "Calibri", fontSize: "1em", fontWeight: "bold", textAlign: "left", border: "0px solid black" }
                        }

                            md={1} > Alt Name: </Col>
                        <Col md={11}
                            style={
                                { overflow: "auto", maxHeight: isArrow ? "23em" : !isArrow ? "3.9em" : "0em" }
                            }
                        > {
                                dummyData.map(obj =>
                                    <Row style={{ color: obj.alt_actv_cd == "A" ? 'black' : '#58cde8' }}>
                                        <Col style={
                                            { fontFamily: "Calibri", fontSize: "1em", textAlign: "left", border: "0px solid black", height: "2em" }
                                        }
                                            md={3} > {obj.alt_lst_nm}</Col>
                                        <Col style={{ fontFamily: "Calibri", fontSize: "1em", textAlign: "left", paddingLeft: "3.6em", border: "0px solid black" }
                                        }
                                            md={2}> {obj.alt_nm_lvl_cd} </Col>
                                        <Col style={{ fontSize: "15px", textAlign: "center", paddingLeft: "40px" }} md={2} >{obj.alt_tax_id_typ_cd}-{obj.alt_tax_id_nbr}</Col>
                                        <Col style={{ fontFamily: "Calibri", fontSize: "15px", textAlign: "right", paddingRight: "75px", border: "0px solid black" }} md={2} >{obj.alt_adr_typ_cd}</Col>
                                        <Col style={
                                            { fontFamily: "Calibri", fontSize: "15px", textAlign: "center", paddingRight: "0.6em", border: "0px solid black" }
                                        }
                                            md={2} > {obj.alt_nm_typ_cd} </Col>
                                        <Col style={
                                            { fontFamily: "Calibri", fontSize: "1em", textAlign: "left", paddingRight: "0em", border: "0px solid black" }
                                        }
                                            md={1} > {obj.alt_actv_cd} </Col>
                                    </Row>
                                )
                            }
                        </Col>
                    </Row >
                    : ""}
            </Container >

        </div >
    )
}

NameSection.propTypes = {
    props: PropTypes
}

const mapStateToProps = (state) => ({

})

const mapDispatchToProps = {

}

export default connect(mapStateToProps, mapDispatchToProps)(NameSection)