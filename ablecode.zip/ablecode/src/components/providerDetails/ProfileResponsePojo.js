/* eslint-disable */
const maskSSN = (ssn) => {
  if (ssn.length > 0) {
    let str = ssn.toString();
    return `###-##-${str.substring(5, 9)}`;
  }
};
const maskDOB = (dob) => {
  if (dob.length > 0) {
    let str = dob.toString();
    return `##-##-${str.split("-")[0]}`;
  }
};

const ProfileResponsePojo = (list) => {
  if (list != undefined && list.length > 0) {
    //debugger
    let Contract_Org_Spec_final = [];
    let ontract_Org_Overview_final = [];
    let Training_info_final = [];
    let Malpractice_info_final = [];
    let final = [];
    let _counter = 0;
    let profile_page_details = list;
    let providerprofileinformation = [];
    let providerprofileinforsingle_name = [];
    let Contract_Org_Spec = [];
    let NPIinfo = [];
    let DegreeInfo = [];
    let Training_info = [];
    let Malpractice_info = [];
    let Hospital_affiliation_info = [];
    let License_info = [];
    let Medicare_info = [];
    let Federal_DEA_info = [];
    let Contract_org_info = [];
    let Cds_info = [];

    providerprofileinformation =
      profile_page_details[0].providerprofileinformation;
    providerprofileinforsingle_name =
      profile_page_details[1].providerinformation;

    //--------Contract_Org_Spec------
    Contract_Org_Spec =
      profile_page_details[0].providerprofileinformation.spec_catgy_info;
    let Contract_Org_Specundefined;
    if (typeof Contract_Org_Spec === "undefined") {
      Contract_Org_Specundefined = [];
    } else {
      Contract_Org_Specundefined =
        profile_page_details[0].providerprofileinformation.spec_catgy_info;
    }


    Contract_Org_Specundefined.map((obj1, index) => {

      let contr_org_cd = obj1.contr_org_cd !== undefined ? obj1.contr_org_cd : "";
      let contr_org_cd_desc = obj1.contr_org_cd_desc !== undefined ? obj1.contr_org_cd_desc : "";;
      let contr_org_spcl_canc_dt = obj1.contr_org_spcl_canc_dt !== undefined ? obj1.contr_org_spcl_canc_dt : "";;
      let contr_org_spcl_eff_dt = obj1.contr_org_spcl_eff_dt !== undefined ? obj1.contr_org_spcl_eff_dt : "";;
      let cred_verf_org_ind = obj1.cred_verf_org_ind !== undefined ? obj1.cred_verf_org_ind : "";;
      let pcp_spcl_ovrd_ind = obj1.pcp_spcl_ovrd_ind !== undefined ? obj1.pcp_spcl_ovrd_ind : "";;
      let prac_spcl_ind = obj1.prac_spcl_ind !== undefined ? obj1.prac_spcl_ind : "";;
      let pri_cd = obj1.pri_cd !== undefined ? obj1.pri_cd : "";;
      let rcert_eff_dt = obj1.rcert_eff_dt !== undefined ? obj1.rcert_eff_dt : "";;
      let res_ind = obj1.res_ind !== undefined ? obj1.res_ind : "";;
      let spcl_bd_cert_cd = obj1.spcl_bd_cert_cd !== undefined ? obj1.spcl_bd_cert_cd : "";
      let spcl_bd_cert_dt = obj1.spcl_bd_cert_dt !== undefined ? obj1.spcl_bd_cert_dt : "";;
      let spcl_bd_exam_dt = obj1.spcl_bd_exam_dt !== undefined ? obj1.spcl_bd_exam_dt : "";;
      let spcl_bd_expir_dt = obj1.spcl_bd_expir_dt !== undefined ? obj1.spcl_bd_expir_dt : "";;
      let spcl_catgy_cd = obj1.spcl_catgy_cd !== undefined ? obj1.spcl_catgy_cd : "";;
      let spcl_src_cd = obj1.spcl_src_cd !== undefined ? obj1.spcl_src_cd : "";;
      let spcl_typ_cd = obj1.spcl_typ_cd !== undefined ? obj1.spcl_typ_cd : "";;
      let spcl_typ_full_desc = obj1.spcl_typ_full_desc !== undefined ? obj1.spcl_typ_full_desc : "";;
      let tricare_ind = obj1.tricare_ind !== undefined ? obj1.tricare_ind : "";;

      Contract_Org_Spec_final.push({
        contr_org_cd: contr_org_cd,
        contr_org_cd_desc: contr_org_cd_desc,
        contr_org_spcl_canc_dt: contr_org_spcl_canc_dt,
        contr_org_spcl_eff_dt: contr_org_spcl_eff_dt,
        cred_verf_org_ind: cred_verf_org_ind,
        pcp_spcl_ovrd_ind: pcp_spcl_ovrd_ind,
        prac_spcl_ind: prac_spcl_ind,
        pri_cd: pri_cd,
        rcert_eff_dt: rcert_eff_dt,
        res_ind: res_ind,
        spcl_bd_cert_cd: spcl_bd_cert_cd,
        spcl_bd_cert_dt: spcl_bd_cert_dt,
        spcl_bd_exam_dt: spcl_bd_exam_dt,
        spcl_bd_expir_dt: spcl_bd_expir_dt,
        spcl_catgy_cd: spcl_catgy_cd,
        spcl_src_cd: spcl_src_cd,
        spcl_typ_cd: spcl_typ_cd,
        spcl_typ_full_desc: spcl_typ_full_desc,
        tricare_ind: tricare_ind,

      })
    })

    //--------Contract_Org_Spec------
    //--------NPIinfo------
    NPIinfo = list[1].providerinformation[0].npiinfo;
    let NPIinfo_undefined;
    if (typeof NPIinfo === "undefined") {
      NPIinfo_undefined = [];
    } else {
      NPIinfo_undefined = list[1].providerinformation[0].npiinfo;
    }
    //--------NPIinfo------
    //--------DegreeInfo------
    DegreeInfo = profile_page_details[0].providerprofileinformation.degree_info;
    let DegreeInfo_undefined;
    if (typeof DegreeInfo === "undefined") {
      DegreeInfo_undefined = [];
    } else {
      DegreeInfo_undefined =
        profile_page_details[0].providerprofileinformation.degree_info;
    }
    //--------DegreeInfo------
    //--------Malpractice------
    Training_info =
      profile_page_details[0].providerprofileinformation.training_info;
    let Training_info_undefined;
    if (typeof Training_info === "undefined") {
      Training_info_undefined = [];
    } else {
      Training_info_undefined =
        profile_page_details[0].providerprofileinformation.training_info;
    }
    Training_info_undefined.map((obj1, index) => {
      let act_cd = obj1.act_cd !== undefined ? obj1.act_cd : "";
      let board_name = obj1.board_name !== undefined ? obj1.board_name : "";
      let education_desc = obj1.education_desc !== undefined ? obj1.education_desc : "";
      let education_type = obj1.education_type !== undefined ? obj1.education_type : "";
      let end_date = obj1.end_date !== undefined ? obj1.end_date : "";
      let institution_board_code = obj1.institution_board_code !== undefined ? obj1.institution_board_code : "";
      let institution_name = obj1.institution_name !== undefined ? obj1.institution_name : "";
      let inst_cd = obj1.inst_cd !== undefined ? obj1.inst_cd : "";
      let start_date = obj1.start_date !== undefined ? obj1.start_date : "";
      let training_type = obj1.training_type !== undefined ? obj1.training_type : "";

      Training_info_final.push({
        act_cd: act_cd,
        board_name: board_name,
        education_desc: education_desc,
        education_type: education_type,
        end_date: end_date,
        institution_board_code: institution_board_code,
        institution_name: institution_name,
        inst_cd: inst_cd,
        start_date: start_date,
        training_type: training_type








      })


    })
    //--------Malpractice------
    //--------Malpractice------
    Malpractice_info =
      profile_page_details[0].providerprofileinformation.malpractice_info;
    let Malpractice_info_undefined;
    if (typeof Malpractice_info === "undefined") {
      Malpractice_info_undefined = [];
    } else {
      Malpractice_info_undefined =
        profile_page_details[0].providerprofileinformation.malpractice_info;
    }
    Malpractice_info_undefined.map((obj1, index) => {
      let malpractice_active_status_code = obj1.malpractice_active_status_code !== undefined ? obj1.malpractice_active_status_code : "";
      let malpractice_amount_multiple = obj1.malpractice_amount_multiple !== undefined ? obj1.malpractice_amount_multiple : "";
      let malpractice_amount_single = obj1.malpractice_amount_single !== undefined ? obj1.malpractice_amount_single : "";
      let malpractice_carrier_code = obj1.malpractice_carrier_code !== undefined ? obj1.malpractice_carrier_code : "";
      let malpractice_carrier_name = obj1.malpractice_carrier_name !== undefined ? obj1.malpractice_carrier_name : "";
      let malpractice_effective_date = obj1.malpractice_effective_date !== undefined ? obj1.malpractice_effective_date : "";
      let malpractice_expiration_date = obj1.malpractice_expiration_date !== undefined ? obj1.malpractice_expiration_date : "";
      let malpractice_policy_number = obj1.malpractice_policy_number !== undefined ? obj1.malpractice_policy_number : "";


      Malpractice_info_final.push({
        malpractice_active_status_code: malpractice_active_status_code,
        malpractice_amount_multiple: malpractice_amount_multiple,
        malpractice_amount_single: malpractice_amount_single,
        malpractice_carrier_code: malpractice_carrier_code,
        malpractice_carrier_name: malpractice_carrier_name,
        malpractice_effective_date: malpractice_effective_date,
        malpractice_expiration_date: malpractice_expiration_date,
        malpractice_policy_number: malpractice_policy_number


      })

    })
    //--------Malpractice------
    //--------Hospital_affiliation------
    Hospital_affiliation_info =
      profile_page_details[1].providerinformation[0].hospital_affiliation_info;
    let Hospital_affiliation_info_undefined;
    if (typeof Hospital_affiliation_info === "undefined") {
      Hospital_affiliation_info_undefined = [];
    } else {
      Hospital_affiliation_info_undefined =
        profile_page_details[1].providerinformation[0]
          .hospital_affiliation_info;
    }
    //--------Hospital_affiliation------
    //--------License_info------
    License_info =
      profile_page_details[0].providerprofileinformation.license_info;
    let License_info_undefined;
    if (typeof License_info === "undefined") {
      License_info_undefined = [];
    } else {
      License_info_undefined =
        profile_page_details[0].providerprofileinformation.license_info;
    }
    //--------License_info------
    //-------Medicare_info--------
    Medicare_info =
      profile_page_details[0].providerprofileinformation.medicare_info;
    let Medicare_info_for_undefined;
    if (typeof Medicare_info === "undefined") {
      Medicare_info_for_undefined = [];
    } else {
      Medicare_info_for_undefined =
        profile_page_details[0].providerprofileinformation.medicare_info;
    }
    //-----------------------------
    //------------Federal_DEA_info-----
    Federal_DEA_info =
      profile_page_details[0].providerprofileinformation.dea_info;
    let Federal_DEA_info_undefined;
    if (typeof Federal_DEA_info === "undefined") {
      Federal_DEA_info_undefined = [];
    } else {
      Federal_DEA_info_undefined =
        profile_page_details[0].providerprofileinformation.dea_info;
    }
    //------------Federal_DEA_info-----
    //------------Contract_org_info-----
    Contract_org_info =
      profile_page_details[0].providerprofileinformation.contract_org_info;
    let Contract_org_infofor_undefined;
    if (typeof Contract_org_info === "undefined") {
      Contract_org_infofor_undefined = [];
    } else {
      Contract_org_infofor_undefined =
        profile_page_details[0].providerprofileinformation.contract_org_info;
    }

    Contract_org_infofor_undefined.map((obj1, index) => {
      let adr_flag = obj1.adr_flag !== undefined ? obj1.adr_flag : "";
      let contr_org_cd = obj1.contr_org_cd !== undefined ? obj1.contr_org_cd : "";
      let contr_org_cd_desc = obj1.contr_org_cd_desc !== undefined ? obj1.contr_org_cd_desc : "";
      let spec_flag = obj1.spec_flag !== undefined ? obj1.spec_flag : "";
      let tin_flag = obj1.tin_flag !== undefined ? obj1.tin_flag : "";
      ontract_Org_Overview_final.push({
        adr_flag: adr_flag,
        contr_org_cd: contr_org_cd,
        contr_org_cd_desc: contr_org_cd_desc,
        spec_flag: spec_flag,
        tin_flag: tin_flag
      })
    })
    //------------Contract_org_info-----
    //------------cdas-----

    Cds_info = profile_page_details[0].providerprofileinformation.cds_info;
    let Cds_info_for_undefined;
    if (typeof Cds_info === "undefined") {
      Cds_info_for_undefined = [];
    } else {
      Cds_info_for_undefined =
        profile_page_details[0].providerprofileinformation.cds_info;
    }
    //------------cdas-----
    //---------------------MPIN_section------------------------

    providerprofileinformation =
      profile_page_details[0].providerprofileinformation;
    providerprofileinforsingle_name =
      profile_page_details[1].providerinformation;


    //---------------------MPIN_section------------------------

    let Original_Effective_Date = providerprofileinformation.mpin_orig_eff_dt;
    let Current_Effective_Date =
      providerprofileinformation.mpin_current_effective_date;
    let Cancel_Date = providerprofileinformation.mpin_cancel_date;
    let Cancel_Reason = providerprofileinformation.mpin_cancel_reason;
    let Dup_Reason = providerprofileinformation.mpin_duplication_reason;
    let Create_Date = providerprofileinformation.mpin_create_date;
    let Deactivation_Date = providerprofileinformation.mpin_deactivation_date;
    let Claim_Run_Out_Date = providerprofileinformation.mpin_claim_run_out_date;
    let Deactivate_Reason = providerprofileinformation.mpin_deactivate_reason;
    let MPIN_Cancel_Date = providerprofileinformation.mpin_cancel_date;
    let Old_New_MPIN = providerprofileinformation.old_new_mpin;
    let Old_New_fst_nm = providerprofileinformation.old_new_fst_nm;
    let Old_New_mdl_nm = providerprofileinformation.old_new_mdl_nm;
    let Old_New_lst_nm = providerprofileinformation.old_new_lst_nm;
    let Old_New_nm_sufx_cd = providerprofileinformation.old_new_nm_sufx_cd;
    let Old_New_deg_cd = providerprofileinformation.old_new_deg_cd;
    let Old_New_deg_pri_cd = providerprofileinformation.old_new_deg_pri_cd;

    let User_Restrictions = "NA";
    let Criminal_Review = providerprofileinformation.sanction_criminal_review !== null && providerprofileinformation.sanction_criminal_review !== undefined && providerprofileinformation.sanction_criminal_review !== "" ? providerprofileinformation.sanction_criminal_review : "";
    let Sanction_ID =
      providerprofileinformation.sanction_number_code !== null &&
        providerprofileinformation.sanction_number_code !== undefined &&
        providerprofileinformation.sanction_number_code !== ""
        ? providerprofileinformation.sanction_number_code
        : "N/A"; //'N/A';
    let demoMPIN_M_E = providerprofileinformation.mpin_demographic_status;
    let demoBSAR = providerprofileinformation.bsar_demographic_status;
    let demoUHCID = providerprofileinformation.uhcid_demographic_status;
    let contractMPIN_M_E = providerprofileinformation.mpin_contract_status;
    let contractBSAR = providerprofileinformation.bsar_contract_status;
    let contractUHCID = providerprofileinformation.uhcid_contract_status;
    let Hold_section =
      profile_page_details[0].providerprofileinformation.hold_info;
    let miscellanious_info =
      profile_page_details[0].providerprofileinformation.miscellanious_info;
    let Hold_section_for_use;
    let miscellanious_for_use;

    if (typeof miscellanious_info === "undefined") {
      miscellanious_for_use = [];
    } else {
      miscellanious_for_use =
        profile_page_details[0].providerprofileinformation.miscellanious_info;
    }

    if (typeof Hold_section === "undefined") {
      Hold_section_for_use = [];
    } else {
      Hold_section_for_use =
        profile_page_details[0].providerprofileinformation.hold_info;
    }
    //-----------------miscellanious-section---------------------------
    let TOPS_PROVIDER_TYPE = miscellanious_info[0].tops_provider_type;
    let ATYPICAL_PROVIDER = miscellanious_info[0].atypical_provider;
    let NON_PROVIDER_IND = miscellanious_info[0].non_provider_indicator;
    let HCFA_UB = miscellanious_info[0].hcfa_ub_claim_form_type;
    let Gender = providerprofileinforsingle_name[0].prov_gdr_cd;
    let Date_of_Birth = maskDOB(providerprofileinforsingle_name[0].prov_bth_dt);
    let Social_Security_Number = maskSSN(
      providerprofileinforsingle_name[0].soc_secur_nbr
    );
    let Reserved_National_Guard = miscellanious_info[0].reserved_national_guard;
    let Ovations_Feed = miscellanious_info[0].ovations_feed;
    let ABMS_Bio_Number = miscellanious_info[0].abms_bio_number == undefined ?'00000000':miscellanious_info[0].abms_bio_number;
    let VRU = miscellanious_info[0].voice_response_unit;
    let UPIN = miscellanious_info[0].upin;
    let Group_type = miscellanious_info[0].group_facility_type;
    let group_facility_description =
      miscellanious_info[0].group_facility_description;
    let tops_prov_typ_desc = miscellanious_info[0].tops_prov_typ_desc;
    //-----------------miscellanious-section---------------------------
    let Name_section =
      profile_page_details[0].providerprofileinformation.alt_name_info;
    let Name_section_for_use;
    if (typeof Name_section === "undefined") {
      Name_section_for_use = [];
    } else {
      Name_section_for_use =
        profile_page_details[0].providerprofileinformation.alt_name_info;
    }
    // console.log("************************************")
    //   console.log(Name_section_for_use)
    // console.log("************************************")
    final.push({
      Group_type: Group_type,
      group_facility_description: group_facility_description,
      tops_prov_typ_desc: tops_prov_typ_desc,
      Original_Effective_Date: Original_Effective_Date,
      Current_Effective_Date: Current_Effective_Date,
      Cancel_Date: Cancel_Date,
      Cancel_Reason: Cancel_Reason,
      Dup_Reason: Dup_Reason,
      Create_Date: Create_Date,
      Deactivation_Date: Deactivation_Date,
      MPIN_Cancel_Date: MPIN_Cancel_Date,
      Claim_Run_Out_Date: Claim_Run_Out_Date,
      //Claim_Run_Out_Date:Claim_Run_Out_Date,
      Deactivate_Reason: Deactivate_Reason,
      Old_New_MPIN: Old_New_MPIN,
      Old_New_fst_nm: Old_New_fst_nm,
      Old_New_mdl_nm: Old_New_mdl_nm,
      Old_New_lst_nm: Old_New_lst_nm,
      Old_New_nm_sufx_cd: Old_New_nm_sufx_cd,
      Old_New_deg_cd: Old_New_deg_cd,
      Old_New_deg_pri_cd: Old_New_deg_pri_cd,
      User_Restrictions: User_Restrictions,
      Criminal_Review: Criminal_Review,
      Sanction_ID: Sanction_ID,
      demoMPIN_M_E: demoMPIN_M_E,
      demoBSAR: demoBSAR,
      demoUHCID: demoUHCID,
      contractMPIN_M_E: contractMPIN_M_E,
      contractBSAR: contractBSAR,
      contractUHCID: contractUHCID,
      Hold_section: Hold_section_for_use,
      miscellanious_info: miscellanious_for_use,
      TOPS_PROVIDER_TYPE: TOPS_PROVIDER_TYPE,
      ATYPICAL_PROVIDER: ATYPICAL_PROVIDER,
      NON_PROVIDER_IND: NON_PROVIDER_IND,
      HCFA_UB: HCFA_UB,
      Gender: Gender,
      Date_of_Birth: Date_of_Birth,
      Social_Security_Number: Social_Security_Number,
      Reserved_National_Guard: Reserved_National_Guard,
      Ovations_Feed: Ovations_Feed,
      ABMS_Bio_Number: ABMS_Bio_Number,
      VRU: VRU,
      UPIN: UPIN,
      Name_section: Name_section_for_use,
      providerprofileinforsingle_name: providerprofileinforsingle_name,
      Contract_Org_Spec: Contract_Org_Spec_final,
      NPIinfo: NPIinfo_undefined,
      DegreeInfo: DegreeInfo_undefined,
      Training_info: Training_info_final,
      Malpractice_info: Malpractice_info_final,
      Hospital_affiliation_info: Hospital_affiliation_info_undefined,
      License_info: License_info_undefined,
      Medicare_info: Medicare_info_for_undefined,
      Federal_DEA_info: Federal_DEA_info_undefined,
      Contract_org_info: ontract_Org_Overview_final,
      Cds_info: Cds_info_for_undefined,
    });

    //---------------------MPIN_section------------------------

    //    conts o= providerprofileinformation.map((obj, index) => {

    //     })
    return final;
  }
};

export default ProfileResponsePojo;
