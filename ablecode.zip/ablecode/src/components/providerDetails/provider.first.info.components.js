/* eslint-disable */
import React, { useState, useEffect } from "react";
import { useDispatch, useSelector, connect } from "react-redux";
import PropTypes from "prop-types";
// import { connect } from 'react-redux';
import { makeStyles } from "@material-ui/core/styles";
import Paper from "@material-ui/core/Paper";
import Typography from "@material-ui/core/Typography";
import Grid from "@material-ui/core/Grid";
import Divider from "@material-ui/core/Divider";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import Button from "@material-ui/core/Button";
import HeaderResultProviderComponent from "../resultProvider/header.resultProvider.component";
import Breadcrumbs from "@material-ui/core/Breadcrumbs";
import NavigateNextIcon from "@material-ui/icons/NavigateNext";
import Link from "@material-ui/core/Link";
import ArrowLeftIcon from "@material-ui/icons/ArrowLeft";
import ArrowRightIcon from "@material-ui/icons/ArrowRight";
import EllipsisToolTip from "ellipsis-tooltip-react-chan";
import Tooltip from "@material-ui/core/Tooltip";
import { Container } from "@material-ui/core";
import NameSection from "./NameSection";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import Image, { propTypes } from "react-bootstrap/Image";
//import 'bootstrap/dist/css/bootstrap.min.css';
import ArrowBackIcon from "@material-ui/icons/ArrowBack";
import ArrowForwardIcon from "@material-ui/icons/ArrowForward";
import "../../styles/tablecss.css";
import "../../../node_modules/react-grid-layout/css/styles.css";
import "../../../node_modules/react-resizable/css/styles.css";
import HeightIcon from "@material-ui/icons/Height";
import MultiSelect from "react-multi-select-component";
import downArrow from "../../assets/arrow-down.png";
import upArrow from "../../assets/up-arrow-icon.jpg";
import ProfileResponsePojo from "./ProfileResponsePojo";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import loder from "../../assets/loderdata.gif";
import { getAbleProfileData } from "../../actions/action";
import Moment from "moment";
import Error from "../resultProvider/error";
import { listenerCount } from "events";
import { getAddressType } from "../../utils/fields.constant";
const { getCookie, deleteCookie } = require("../../utils/helper");

let user_name;
let msid;
const useStyles = makeStyles(() => ({
  table: {
    minWidth: 650,
  },
  masterRoot: {
    flexGrow: 1,
  },
  root: {
    margin: "1.5em",
    padding: "1.5em",
  },
  nameRoot: {
    color: "#269AE6",
    fontSize: 15,
  },
  headerText: {
    fontSize: "12px",
    color: "#000000",
    fontWeight: "bold",
    marginBottom: "1.0em",
    marginTop: "1.0em",
  },
  Democon: {
    color: "#a6a6a6",
    fontWeight: "bold",
  },
  brokenWord: {
    width: "40px",

    wordBreak: "breakAll",
  },
  inputText: {
    color: "#000000",
    fontSize: "0.8em",
    lineHeight: "1",
    marginBottom: "0.25em",
    fontWeight: "bold",

    fontFamily: "arial",
  },
  inputText2: {
    fontWeight: "600",
  },
  blankInputText: {
    color: "#d3d3d34d",
    fontSize: "0.7em",
    lineHeight: "1",
    marginBottom: "0.25em",
    fontWeight: "bolder",
  },
  inputText2: {
    fontWeight: "500",
  },
  mpinInputText: {
    fontWeight: "500",
    fontSize: "12px",
    fontFamily: "Verdana",
  },
  line: {
    width: "0.1px",
    height: "8em",
    backgroundColor: "black",
    // marginLeft:'4px'
  },
  line2: {
    width: "29em",
    height: "1px",
    backgroundColor: "black",
  },
  line3: {
    width: "13.4em",
    height: "1px",
    backgroundColor: "black",
  },
  line4: {
    width: "0.1px",
    height: "5.5em",
    marginTop: "1.4em",
    backgroundColor: "black",
    // marginLeft:'4px'
  },
  icon: {
    color: "#757588",
    width: "0.6em",
    height: "0.6em",
    paddingLeft: "0.5em",
  },
  customInput: {
    padding: "10px 14px",
  },
  disabled: {
    backgroundColor: "rgba(0, 0, 0, 0.09)",
  },

  overFlowLeft: {
    width: "48%",
    height: "196px",
    overflow: "hidden",
  },

  overFlowRight: {
    width: "48%",
    height: "100px",

    overflow: "hidden",
    //marginLeft:'250px'
  },
  overFlowAll: {
    width: "100%",
    height: "100px",
    overflow: "scroll",
  },

  bgcolor: {
    backgroundColor: "#DADBDC",
    marginTop: "0.1px",
    borderTop: "0.1px solid black",
  },
  firstDiv: {
    width: "18.7em",
    paddingLeft: "1.5em",
  },
  secondDiv: {
    width: "18.7em",
    paddingLeft: "1em",
  },
  thirdDiv: {
    width: "30.7em",
    paddingLeft: "1em",
  },
  fourDiv: {
    width: "11em",
    paddingLeft: "10px",
  },
  fourSecondDiv: {
    width: "7em",
    paddingLeft: "10px",
  },
  fiveDive: {
    width: "173px",
    paddingLeft: "17px",
  },
  sixDive: {
    width: "150px",
    paddingLeft: "30px",
  },
  overscrll: {
    width: "612px",
    overflow: "scroll",
  },
  scrolldivcss: {
    width: "1694px",
  },
  TableCSS: {
    textAlign: "center",
  },
  Tableheadercss: {
    width: "100%",
    backgroundColor: "#d3d3d34d",
    fontWeight: "bold",
  },
  Tabletdcss: {
    fontSize: "13px",
  },
  Tabletdfirstcss: {
    backgroundColor: "#d3d3d34d",
    fontSize: "13px",
  },
  customButton: {
    float: "right",
  },
  tableContainer: {
    width: "100%",
    overflow: "auto",
    "max-height": "2.9em",
    // "border": "0.2px solid black",
  },
  tableContainerMax: {
    width: "100%",
    overflow: "auto",
    "max-height": "23.6em",
    // "border": "0.2px solid black",
  },
  table: {
    width: "100%",
    overflow: "auto",
    // paddingLeft:"300px",
    // "max-height": "60px",
    // "border": "1.2px solid black",
  },
  tableHeader: {
    color: "#b3b3b3",
    width: "210px",
    position: "sticky",
    top: 0,
    background: "white",
  },
  tableData: {
    color: "black",
    width: "210px",
    textAlign: "center",
    background: "white",
  },
  nameHeader: {
    color: "#b3b3b3",
    // textAlign: "center",
    fontSize: "12px",
    // width:"210px",
    // position: "sticky",
    // top: 0,
    background: "white",
  },
  lastNameHeader: {
    marginLeft: "136px",
    color: "#b3b3b3",
    // textAlign: "center",
    fontSize: "12px",
    // width:"210px",
    // position: "sticky",
    // top: 0,
    background: "white",
  },
  nameData: {
    // textAlign: "center",
    fontSize: "12px",
    color: "black",
    fontWeight: "460",
    background: "white",
  },
  nameDataCoHeader: {
    // textAlign: 'left',
    color: "#808080",
    paddingLeft: "1.0em",
    fontSize: "13px",
    fontWeight: "460",
    fontWeight: "bold",
    background: "white",
    fontFamily: "Verdana",
  },
  altNameDataCoHeader: {
    color: "#808080",
    paddingLeft: "1.0em",
    fontSize: "11px",
    fontWeight: "460",
    fontWeight: "bold",
    background: "white",
    fontFamily: "Verdana",
  },
  altNameData: {
    color: "black",
    width: "185px",
    height: "1.5em",
    // textAlign: 'center',
    background: "white",
    marginLeft: "100px",
    marginTop: "2em",
    // "border": "0.2px solid black",
    // fontSize:'13px',
    // fontWeight: "460",
    // background: "white"
  },
  altLastNameData: {
    marginLeft: "200px",
    color: "black",
    width: "285px",
    // textAlign: 'center',
    background: "white",
    // marginLeft: "10px",
    // "border": "1.2px solid black",
    fontSize: "12px",
    // fontWeight: "460",
    // background: "white"
  },
  altFirstNameData: {
    color: "black",
    // marginRight:"70px",
    // textAlign: 'center',
    // "border": "0.2px solid black",
  },
  altMiddleNameData: {
    width: "371px",
    color: "black",
    // marginRight:"2000px",
    // marginRight: '1.1em',
    textAlign: "left",
    // "border": "1.2px solid black",
  },
  altTypeNameData: {
    width: "137px",
    color: "black",
    // marginRight:"2000px",
    // marginRight: '1.1em',
    textAlign: "left",
    // "border": "1.2px solid black",
  },
  altActiveNameData: {
    // width: "380px",
    color: "black",
    width: "67px",
    // marginRight:"2000px",
    // marginRight: '1.1em',
    textAlign: "left",
    // "border": "1.2px solid black",
  },
  paginationIcons: {
    cursor: "pointer",
    backgroundColor: "#d3d3d34d",
    marginTop: "1.1em",
    fontSize: "1.0em",
  },
  sticky: {
    position: "-webkit-sticky",
    position: "sticky",
    top: "0",
    "background-color": "white",
    padding: "10px",
    "font-size": "12px",
    zIndex: 9999,
  },
  customLink: {
    color: "#269AE6",
    fontSize: 15,
  },
  customTooltip: {
    backgroundColor: "white !important",
    color: "black !important",
    borderStyle: "solid !important",
    borderColor: "#757588 !important",
    borderWidth: "5px 10px 5px 10px !important",
    borderRadius: "5px !important",
    padding: "5px !important",
    fontSize: 11,
    // maxWidth:200
  },
  customTooltip1: {
    backgroundColor: "white !important",
    color: "black !important",
    borderStyle: "solid !important",
    borderColor: "#757588 !important",
    // borderWidth:'5px 10px 5px 10px !important',
    borderRadius: "2px !important",
    padding: "5px !important",
    fontSize: 11,
    zIndex: 9999,
    // maxWidth:200
  },
  coll1: {
    zIndex: 1,
    paddingLeft: "19px !important",
  },
  coll2: {
    zIndex: 0,
    paddingRight: "20px !important",
    paddingLeft: "0px !important",
    marginLeft: "-1px !important",
  },
  customWidth: {
    maxWidth: 320,
  },
  customWidth_mpin: {
    maxWidth: 340,
  },
}));

function ProviderFirstInfocomponents(
  resultList,
  handleProviderFirstInfoChange,
  ProviderFirstInfo
) {
  const classes = useStyles();
  // let ableProfile = useSelector(state => state.result);
  const dispatch = useDispatch();
  let profile_data;

  const userObj = JSON.parse(getCookie("openIdInfo"));
  let user_name;
  if (userObj == null) {
    // window.location.href = initUrlFun();
    //  user_name=user_name_back;
  } else {
    user_name = userObj.name;
    msid = userObj.sub;
    //user_name_back=userObj.name;
  }

  // console.log("resultList  33333 ============= here check ", resultList)
  // console.log("profilePageFetchResults ============= here check ", profilePageFetchResults);

  let [isArrow, setIsArrow] = React.useState(false);
  let [loopOncePage3, setLoopOncePage3] = React.useState(false);
  const [open, setOpen] = React.useState(false);
  const [state, setState] = React.useState({
    right_col_zIndex:'1',
    left_col_zIndex:'',
    left_col_zIndex:'',
    loading: false,
    contractOrgDiv: false,
    contractViewDiv: false,
    NPIdiv: false,
    federealDiv: false,
    degreeDiv: false,
    trainingTypeDiv: false,
    licenseDiv: false,
    CDSdiv: false,
    malpracticeDiv: false,
    hospitalDiv: false,
    displayDDL: false,
    backEndError: false,
    MPINSection: true,
    NameSection: true,
    MISCSection: true,
    contractGrid: true,
    contractViewGrid: true,
    NPIGrid: true,
    federealGrid: true,
    degreeGrid: true,
    CDSGrid: true,
    trainingTypeGrid: true,
    licenseGrid: true,
    malpracticeGrid: true,
    medicareGrid: true,
    hospitalGrid: true,
    selectedAll: "",
    resizewidth: "",
    resizewidthNPI: "",
    resizewidthDegree: "",
    resizewidthTrainingType: "",
    resizewidthMalpractice: "",
    resizewidthHospital: "",
    resetmargin_overview: "",
    resetmargin_federal: "",
    resetmargin_cdschrt: "",
    resetmargin_license: "",
    resetmargin_medic: "",
    resetoverviewwidth: "",
    resetfederalwidth: "",
    resetcdswidth: "",
    resetlicensewidth: "",
    resetmedicarewidth: "",
    resemargionorgspec: "",
    resmarginonnpi: "",
    resmarginondegree: "",
    resmarginontrainingtype: "",
    resmarginonmalpractice: "",
    resmarginonhospital: "",
    resemargionorgspec_left: "",
    resemargionfederal_left: "",
    resemargioncds_left: "",
    resemargionlicense_left: "",
    resemargionmedicare_left: "",
    //-----------MpinKeyforprofile----------------------------
    orignal_eefctive_date: "",
    Current_Effective_Date: "",
    Cancel_Date: "",
    Cancel_Reason: "",
    Dup_Reason: "",
    Create_Date: "",
    Deactivation_Date: "",
    Claim_Run_Out_Date: "",
    Deactivate_Reason: "",
    MPIN_Cancel_Date: "",
    Old_New_MPIN: "",
    Old_New_fst_nm: "",
    Old_New_mdl_nm: "",
    Old_New_lst_nm: "",
    Old_New_nm_sufx_cd: "",
    Old_New_deg_cd: "",
    Old_New_deg_pri_cd: "",
    User_Restrictions: "",
    Criminal_Review: "",
    Sanction_ID: "",
    demoMPIN_M_E: "",
    demoBSAR: "",
    demoUHCID: "",
    contractMPIN_M_E: "",
    contractBSAR: "",
    contractUHCID: "",
    Hold_section: [],
    Name_section: [],

    //-----------MpinKeyforprofile----------------------------
    //----------miscellanious-------------
    TOPS_PROVIDER_TYPE: "",
    TOPS_PROVIDER_TYPE_DESCRIPTION: "",
    ATYPICAL_PROVIDER: "",
    NON_PROVIDER_IND: "",
    HCFA_UB: "",
    Gender: "",
    Date_of_Birth: "",
    Social_Security_Number: "",
    Reserved_National_Guard: "",
    Ovations_Feed: "",
    ABMS_Bio_Number: "",
    VRU: "",
    UPIN: "",
    Group_type: "",
    group_facility_description: "",
    providerprofileinforsingle_name: [],
    Contract_Org_Spec: [],
    NPIinfo: [],
    DegreeInfo: [],
    Training_info: [],
    Malpractice_info: [],
    Hospital_affiliation_info: [],
    License_info: [],
    Medicare_info: [],
    Federal_DEA_info: [],
    Contract_org_info: [],
    Cds_info: [],
  });

  // React.useEffect(() => {
  //   console.log("useEffect =========== useEffect useEffect useEffect useEffect");
  //   const params = {
  //     "prov_id": MPIN,
  //     "user": "aali1018",
  //     "action": "profile"
  //   };
  //   dispatch(getAbleProfileData(params));
  // }, []);

  useEffect(() => {
    if (state.contractGrid) {
      createResizableTable(document.getElementById("resizeContractOrg"));
    }
    if (state.contractViewGrid) {
      createResizableTable(document.getElementById("resizeContractView"));
    }
    if (state.federealGrid) {
      createResizableTable(document.getElementById("resizeFedereal"));
    }
    if (state.CDSGrid) {
      createResizableTable(document.getElementById("resizeCDS"));
    }

    if (state.NPIGrid) {
      createResizableTable(document.getElementById("resizeNPI"));
    }
    if (state.trainingTypeGrid) {
      createResizableTable(document.getElementById("resizeTrainingType"));
    }
    if (state.licenseGrid) {
      createResizableTable(document.getElementById("resizeLicense"));
    }
    if (state.malpracticeGrid) {
      createResizableTable(document.getElementById("resizeMalpractice"));
    }
    if (state.medicareGrid) {
      if (pType == "o") {
        createResizableTable(document.getElementById("resizeMedicare"));
      }
    }
    if (state.hospitalGrid) {
      createResizableTable(document.getElementById("resizeHospital"));
    }
    if (state.degreeGrid) {
      if (pType == "p") {
        createResizableTable(document.getElementById("resizeDegree"));
      }
    }
    if (state.displayDDL) {
      var event = document.createEvent("SVGEvents");
      event.initEvent("click", true, true);
      document
        .getElementsByClassName("dropdown-heading-dropdown-arrow gray")[0]
        .dispatchEvent(event);
    }
  });

  // let MPIN = resultList.resultList.selectedMpin;
  let MPINObj = resultList.resultList.selectedMpin;
  // console.log("ABLE data HERE11111 =========== ", resultList);
  let MPIN = MPINObj.providerId;
  let pType = MPINObj.mpinType == "PHY" ? "p" : "o";

  useEffect(() => {
    //debugger
    const params = {
      prov_id: MPIN,
      user: msid,
      action: "profile",
    };
    const loadSpots = async () => {
      // setIsLoading(true);
      // ableProfile.ableProfileData=[];
      await dispatch(getAbleProfileData(params));
      // setIsLoading(false);
    };
    loadSpots();
  }, []);

  useEffect(() => {
    if (
      resultList.resultList.ableProfileData.ProfilePageSummaryResponse !=
      undefined
    ) {
      display();
    }
  }, [resultList]);

  function display() {
    //alert("asas");
    //debugger
    profile_data = ProfileResponsePojo(
      resultList.resultList.ableProfileData.ProfilePageSummaryResponse
    );
    let tempObj = [
      { label: "MPIN Section", value: "MPIN Section" },
      { label: "Name Section", value: "Name Section" },
      { label: "MISC Section", value: "MISC Section" },
    ];
    setState({
      ...state,
      orignal_eefctive_date: profile_data[0].Original_Effective_Date,
      Current_Effective_Date: profile_data[0].Current_Effective_Date,
      Cancel_Date: profile_data[0].Cancel_Date,
      Cancel_Reason: profile_data[0].Cancel_Reason,
      Dup_Reason: profile_data[0].Dup_Reason,
      Create_Date: profile_data[0].Create_Date,
      Deactivation_Date: profile_data[0].Deactivation_Date,
      Claim_Run_Out_Date: profile_data[0].Claim_Run_Out_Date,
      Deactivate_Reason: profile_data[0].Deactivate_Reason,
      Old_New_MPIN: profile_data[0].Old_New_MPIN,
      Old_New_fst_nm: profile_data[0].Old_New_fst_nm,
      Old_New_mdl_nm: profile_data[0].Old_New_mdl_nm,
      Old_New_lst_nm: profile_data[0].Old_New_lst_nm,
      Old_New_nm_sufx_cd: profile_data[0].Old_New_nm_sufx_cd,
      Old_New_deg_cd: profile_data[0].Old_New_deg_cd,
      Old_New_deg_pri_cd: profile_data[0].Old_New_deg_pri_cd,

      User_Restrictions: profile_data[0].User_Restrictions,
      Criminal_Review: profile_data[0].Criminal_Review,
      Sanction_ID: profile_data[0].Sanction_ID,
      demoMPIN_M_E: profile_data[0].demoMPIN_M_E,
      demoBSAR: profile_data[0].demoBSAR,
      demoUHCID: profile_data[0].demoUHCID,
      contractMPIN_M_E: profile_data[0].contractMPIN_M_E,
      contractBSAR: profile_data[0].contractBSAR,
      contractUHCID: profile_data[0].contractUHCID,
      Hold_section: profile_data[0].Hold_section,
      TOPS_PROVIDER_TYPE: profile_data[0].TOPS_PROVIDER_TYPE,
      TOPS_PROVIDER_TYPE_DESCRIPTION: profile_data[0].tops_prov_typ_desc,
      ATYPICAL_PROVIDER: profile_data[0].ATYPICAL_PROVIDER,
      NON_PROVIDER_IND: profile_data[0].NON_PROVIDER_IND,
      HCFA_UB: profile_data[0].HCFA_UB,
      Gender: profile_data[0].Gender,
      Date_of_Birth: profile_data[0].Date_of_Birth,
      Social_Security_Number: profile_data[0].Social_Security_Number,
      Reserved_National_Guard: profile_data[0].Reserved_National_Guard,
      Ovations_Feed: profile_data[0].Ovations_Feed,
      ABMS_Bio_Number: profile_data[0].ABMS_Bio_Number,
      VRU: profile_data[0].VRU,
      UPIN: profile_data[0].UPIN,
      Group_type: profile_data[0].Group_type,
      group_facility_description: profile_data[0].group_facility_description,
      Name_section: profile_data[0].Name_section,
      providerprofileinforsingle_name:
        profile_data[0].providerprofileinforsingle_name[0],
      Contract_Org_Spec: profile_data[0].Contract_Org_Spec,
      NPIinfo: profile_data[0].NPIinfo,
      DegreeInfo: profile_data[0].DegreeInfo,
      Training_info: profile_data[0].Training_info,
      Malpractice_info: profile_data[0].Malpractice_info,
      Hospital_affiliation_info: profile_data[0].Hospital_affiliation_info,
      License_info: profile_data[0].License_info,
      Medicare_info: profile_data[0].Medicare_info,
      Federal_DEA_info: profile_data[0].Federal_DEA_info,
      Contract_org_info: profile_data[0].Contract_org_info,
      Cds_info: profile_data[0].Cds_info,
      degreeGrid: profile_data[0].DegreeInfo.length > 0 ? true : false,
      trainingTypeGrid: profile_data[0].Training_info.length > 0 ? true : false,
      contractViewGrid:
        profile_data[0].Contract_org_info.length > 0 ? true : false,
      hospitalGrid:
        profile_data[0].Hospital_affiliation_info.length > 0 ? true : false,
      licenseGrid: profile_data[0].License_info.length > 0 ? true : false,
      medicareGrid: profile_data[0].Medicare_info.length > 0 ? true : false,
      federealGrid: profile_data[0].Federal_DEA_info.length > 0 ? true : false,
      contractGrid: profile_data[0].Contract_Org_Spec.length > 0 ? true : false,
      NPIGrid: profile_data[0].NPIinfo.length > 0 ? true : false,
      malpracticeGrid:
        profile_data[0].Malpractice_info.length > 0 ? true : false,
      CDSGrid: profile_data[0].Cds_info.length > 0 ? true : false,
    });
    profile_data[0].Contract_org_info.length > 0
      ? tempObj.push({
        label: "Contract Org(Overview)",
        value: "Contract Org(Overview)",
      })
      : "";
    profile_data[0].Contract_Org_Spec.length > 0
      ? tempObj.push({
        label: "Contract Org(Speciality)",
        value: "Contract Org(Speciality)",
      })
      : "";
    profile_data[0].NPIinfo.length
      ? tempObj.push({ label: "NPI", value: "NPI" })
      : "";
    profile_data[0].Federal_DEA_info.length > 0
      ? tempObj.push({ label: "DEA", value: "DEA" })
      : "";
    profile_data[0].DegreeInfo.length > 0
      ? tempObj.push({ label: "Degree", value: "Degree" })
      : "";
    profile_data[0].Cds_info.length > 0
      ? tempObj.push({ label: "CDS", value: "CDS" })
      : "";
    profile_data[0].Training_info.length > 0
      ? tempObj.push({ label: "Training", value: "Training" })
      : "";
    profile_data[0].License_info.length > 0
      ? tempObj.push({ label: "License", value: "License" })
      : "";
    profile_data[0].Malpractice_info.length > 0
      ? tempObj.push({ label: "Malpractice", value: "Malpractice" })
      : "";
    profile_data[0].Medicare_info.length > 0
      ? tempObj.push({ label: "Medicare", value: "Medicare" })
      : "";
    profile_data[0].Hospital_affiliation_info.length > 0
      ? tempObj.push({
        label: "Hospital Affiliation",
        value: "Hospital Affiliation",
      })
      : "";
    setSelected(tempObj);
  }

  // let profileData = useSelector(state => state.results);
  // console.log("profileData ============= here check ", profileData,)

  const [selected, setSelected] = useState([]);
  const Options = {
    effect: "solid",
    place: "top",
    multiline: true,
    className: classes.customTooltip1,
  };
  const optionRight = {
    effect: "solid",
    place: "right",
    multiline: true,
    className: classes.customTooltip1,
  };
  const resetState = {
    contractOrgDiv: false,
    contractViewDiv: false,
    NPIdiv: false,
    federealDiv: false,
    degreeDiv: false,
    trainingTypeDiv: false,
    licenseDiv: false,
    CDSdiv: false,
    malpracticeDiv: false,
    hospitalDiv: false,
    displayDDL: false,
    resizewidth: "",
    resizewidthNPI: "",
    resizewidthDegree: "",
    resizewidthTrainingType: "",
    resizewidthMalpractice: "",
    resizewidthHospital: "",
    resetmargin_overview: "",
    resetmargin_federal: "",
    resetmargin_cdschrt: "",
    resetmargin_license: "",
    resetmargin_medic: "",
    resetoverviewwidth: "",
    resetfederalwidth: "",
    resetcdswidth: "",
    resetlicensewidth: "",
    resetmedicarewidth: "",
    resemargionorgspec: "",
    resmarginonnpi: "",
    resmarginondegree: "",
    resmarginontrainingtype: "",
    resmarginonmalpractice: "",
    resmarginonhospital: "",
    resemargionorgspec_left: "",
    resemargionfederal_left: "",
    resemargioncds_left: "",
    resemargionlicense_left: "",
    resemargionmedicare_left: "",
  };
  const makeGridLargeforContractOrg = () => {
    if (state.contractOrgDiv) {
      let width = "",
        mar = "",
        fmar = "",
        cmar = "",
        linmar = "",
        medicmar = "";
      setState({
        ...state,
        contractOrgDiv: false,
        resizewidth: width,
        resetmargin_overview: mar,
        resetmargin_federal: fmar,
        resetmargin_cdschrt: cmar,
        resetmargin_license: linmar,
        resetmargin_medic: medicmar,
      });
    } else {
      let child1 = document.getElementById("contractGrid");
      let position = Array.from(child1.parentNode.children).indexOf(child1);
      let elements = document.getElementById("div2").children;
      if (elements.item(position) !== null) {
        let grid = elements.item(position).id;
        let width = "203%",
          mar = "176px";
        if (grid == "contractViewGrid") {
          const { resetmargin_overview, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            contractOrgDiv: true,
            resizewidth: width,
            resetmargin_overview: mar,
          });
        } else if (grid == "federealGrid") {
          const { resetmargin_federal, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            contractOrgDiv: true,
            resizewidth: width,
            resetmargin_federal: mar,
          });
        } else if (grid == "CDSGrid") {
          const { resetmargin_cdschrt, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            contractOrgDiv: true,
            resizewidth: width,
            resetmargin_cdschrt: mar,
          });
        } else if (grid == "licenseGrid") {
          const { resetmargin_license, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            contractOrgDiv: true,
            resizewidth: width,
            resetmargin_license: mar,
          });
        } else if (grid == "medicareGrid") {
          const { resetmargin_medic, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            contractOrgDiv: true,
            resizewidth: width,
            resetmargin_medic: mar,
          });
        }
      } else {
        const { ...updatedObject } = resetState;
        setState({
          ...state,
          ...updatedObject,
          contractOrgDiv: true,
          resizewidth: "203%",
        });
      }
    }
  };
  const makeGridLargeforNPI = () => {
    if (state.NPIdiv) {
      let width = "",
        mar = "",
        fmar = "",
        cmar = "",
        linmar = "",
        medicmar = "";
      setState({
        ...state,
        NPIdiv: false,
        resizewidthNPI: width,
        resetmargin_overview: mar,
        resetmargin_federal: fmar,
        resetmargin_cdschrt: cmar,
        resetmargin_license: linmar,
        resetmargin_medic: medicmar,
      });
    } else {
      let child1 = document.getElementById("NPIGrid");
      let position = Array.from(child1.parentNode.children).indexOf(child1);
      let elements = document.getElementById("div2").children;
      if (elements.item(position) !== null) {
        let grid = elements.item(position).id;
        let width = "203%",
          mar = "176px";
        if (grid == "contractViewGrid") {
          const { resetmargin_overview, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            NPIdiv: true,
            resizewidthNPI: width,
            resetmargin_overview: mar,
          });
        } else if (grid == "federealGrid") {
          const { resetmargin_federal, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            NPIdiv: true,
            resizewidthNPI: width,
            resetmargin_federal: mar,
            right_col_zIndex:"1",
          });
        } else if (grid == "CDSGrid") {
          const { resetmargin_cdschrt, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            NPIdiv: true,
            resizewidthNPI: width,
            resetmargin_cdschrt: mar,
          });
        } else if (grid == "licenseGrid") {
          const { resetmargin_license, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            NPIdiv: true,
            resizewidthNPI: width,
            resetmargin_license: mar,
          });
        } else if (grid == "medicareGrid") {
          const { resetmargin_medic, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            NPIdiv: true,
            resizewidthNPI: width,
            resetmargin_medic: mar,
          });
        }
      } else {
        const { ...updatedObject } = resetState;
        setState({
          ...state,
          ...updatedObject,
          NPIdiv: true,
          resizewidthNPI: "203%",
        });
      }
    }
  };

  const makeGridLargeforDegree = () => {
    if (state.degreeDiv) {
      let width = "",
        mar = "",
        fmar = "",
        cmar = "",
        linmar = "",
        medicmar = "";
      setState({
        ...state,
        degreeDiv: false,
        resizewidthDegree: width,
        resetmargin_overview: mar,
        resetmargin_federal: fmar,
        resetmargin_cdschrt: cmar,
        resetmargin_license: linmar,
        resetmargin_medic: medicmar,
        right_col_zIndex:"1",
      });
    } else {
      let child1 = document.getElementById("degreeGrid");
      let position = Array.from(child1.parentNode.children).indexOf(child1);
      let elements = document.getElementById("div2").children;
      if (elements.item(position) !== null) {
        let grid = elements.item(position).id;
        let width = "203%",
          mar = "176px";
        if (grid == "contractViewGrid") {
          const { resetmargin_overview, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            degreeDiv: true,
            resizewidthDegree: width,
            resetmargin_overview: mar,
          });
        } else if (grid == "federealGrid") {
          const { resetmargin_federal, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            degreeDiv: true,
            resizewidthDegree: width,
            resetmargin_federal: mar,
          });
        } else if (grid == "CDSGrid") {
          const { resetmargin_cdschrt, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            degreeDiv: true,
            resizewidthDegree: width,
            resetmargin_cdschrt: mar,
          });
        } else if (grid == "licenseGrid") {
          const { resetmargin_license, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            degreeDiv: true,
            resizewidthDegree: width,
            resetmargin_license: mar,
          });
        } else if (grid == "medicareGrid") {
          const { resetmargin_medic, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            degreeDiv: true,
            resizewidthDegree: width,
            resetmargin_medic: mar,
          });
        }
      } else {
        const { ...updatedObject } = resetState;
        setState({
          ...state,
          ...updatedObject,
          degreeDiv: true,
          resizewidthDegree: "203%",
        });
      }
    }
  };
  const makeGridLargeforTrainingType = () => {
    if (state.trainingTypeDiv) {
      let width = "",
        mar = "",
        fmar = "",
        cmar = "",
        linmar = "",
        medicmar = "";
      setState({
        ...state,
        trainingTypeDiv: false,
        resizewidthTrainingType: width,
        resetmargin_overview: mar,
        resetmargin_federal: fmar,
        resetmargin_cdschrt: cmar,
        resetmargin_license: linmar,
        resetmargin_medic: medicmar,
      });
    } else {
      let child1 = document.getElementById("trainingTypeGrid");
      let position = Array.from(child1.parentNode.children).indexOf(child1);
      let elements = document.getElementById("div2").children;
      if (elements.item(position) !== null) {
        let grid = elements.item(position).id;
        let width = "203%",
          mar = "176px";
        if (grid == "contractViewGrid") {
          const { resetmargin_overview, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            trainingTypeDiv: true,
            resizewidthTrainingType: width,
            resetmargin_overview: mar,
          });
        } else if (grid == "federealGrid") {
          const { resetmargin_federal, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            trainingTypeDiv: true,
            resizewidthTrainingType: width,
            resetmargin_federal: mar,
          });
        } else if (grid == "CDSGrid") {
          const { resetmargin_cdschrt, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            trainingTypeDiv: true,
            resizewidthTrainingType: width,
            resetmargin_cdschrt: mar,
          });
        } else if (grid == "licenseGrid") {
          const { resetmargin_license, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            trainingTypeDiv: true,
            resizewidthTrainingType: width,
            resetmargin_license: mar,
          });
        } else if (grid == "medicareGrid") {
          const { resetmargin_medic, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            trainingTypeDiv: true,
            resizewidthTrainingType: width,
            resetmargin_medic: mar,
          });
        }
      } else {
        const { ...updatedObject } = resetState;
        setState({
          ...state,
          ...updatedObject,
          trainingTypeDiv: true,
          resizewidthTrainingType: "203%",
        });
      }
    }
  };

  const makeGridLargeforMalpractice = () => {
    if (state.malpracticeDiv) {
      let width = "",
        mar = "",
        fmar = "",
        cmar = "",
        linmar = "",
        medicmar = "";
      setState({
        ...state,
        malpracticeDiv: false,
        resizewidthMalpractice: width,
        resetmargin_overview: mar,
        resetmargin_federal: fmar,
        resetmargin_cdschrt: cmar,
        resetmargin_license: linmar,
        resetmargin_medic: medicmar,
      });
    } else {
      let child1 = document.getElementById("malpracticeGrid");
      let position = Array.from(child1.parentNode.children).indexOf(child1);
      let elements = document.getElementById("div2").children;
      if (elements.item(position) !== null) {
        let grid = elements.item(position).id;
        let width = "203%",
          mar = "176px";
        if (grid == "contractViewGrid") {
          const { resetmargin_overview, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            malpracticeDiv: true,
            resizewidthMalpractice: width,
            resetmargin_overview: mar,
          });
        } else if (grid == "federealGrid") {
          const { resetmargin_federal, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            malpracticeDiv: true,
            resizewidthMalpractice: width,
            resetmargin_federal: mar,
          });
        } else if (grid == "CDSGrid") {
          const { resetmargin_cdschrt, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            malpracticeDiv: true,
            resizewidthMalpractice: width,
            resetmargin_cdschrt: mar,
          });
        } else if (grid == "licenseGrid") {
          const { resetmargin_license, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            malpracticeDiv: true,
            resizewidthMalpractice: width,
            resetmargin_license: mar,
          });
        } else if (grid == "medicareGrid") {
          const { resetmargin_medic, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            malpracticeDiv: true,
            resizewidthMalpractice: width,
            resetmargin_medic: mar,
          });
        }
      } else {
        const { ...updatedObject } = resetState;
        setState({
          ...state,
          ...updatedObject,
          malpracticeDiv: true,
          resizewidthMalpractice: "203%",
        });
      }
    }
  };

  const makeGridLargeforHospital = () => {
    if (state.hospitalDiv) {
      let width = "",
        mar = "",
        fmar = "",
        cmar = "",
        linmar = "",
        medicmar = "";
      setState({
        ...state,
        hospitalDiv: false,
        resizewidthHospital: width,
        resetmargin_overview: mar,
        resetmargin_federal: fmar,
        resetmargin_cdschrt: cmar,
        resetmargin_license: linmar,
        resetmargin_medic: medicmar,
        right_col_zIndex:"1",
      });
    } else {
      let child1 = document.getElementById("hospitalGrid");
      let position = Array.from(child1.parentNode.children).indexOf(child1);
      let elements = document.getElementById("div2").children;
      if (elements.item(position) !== null) {
        let grid = elements.item(position).id;
        let width = "203%",
          mar = "176px";
        if (grid == "contractViewGrid") {
          const { resetmargin_overview, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            hospitalDiv: true,
            resizewidthHospital: width,
            resetmargin_overview: mar,
          });
        } else if (grid == "federealGrid") {
          const { resetmargin_federal, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            hospitalDiv: true,
            resizewidthHospital: width,
            resetmargin_federal: mar,
          });
        } else if (grid == "CDSGrid") {
          const { resetmargin_cdschrt, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            hospitalDiv: true,
            resizewidthHospital: width,
            resetmargin_cdschrt: mar,
          });
        } else if (grid == "licenseGrid") {
          const { resetmargin_license, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            hospitalDiv: true,
            resizewidthHospital: width,
            resetmargin_license: mar,
          });
        } else if (grid == "medicareGrid") {
          const { resetmargin_medic, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            hospitalDiv: true,
            resizewidthHospital: width,
            resetmargin_medic: mar,
          });
        }
      } else {
        const { ...updatedObject } = resetState;
        setState({
          ...state,
          ...updatedObject,
          hospitalDiv: true,
          resizewidthHospital: "203%",
        });
      }
    }
  };
  const makeGridLargeforContractOverview = () => {
    if (state.contractViewDiv) {
      let width = "",
        omar = "",
        margionleft = "",
        nmar = "",
        dmar = "",
        tmar = "",
        mmar = "",
        hmar = "";
      setState({
        ...state,
        contractViewDiv: false,
        resetoverviewwidth: width,
        resemargionorgspec: omar,
        resmarginonnpi: nmar,
        resmarginontrainingtype: tmar,
        resmarginonmalpractice: mmar,
        resmarginonhospital: hmar,
        resmarginondegree: mmar,
        resemargionorgspec_left: margionleft,
        right_col_zIndex:"1",
      });
    } else {
      let child1 = document.getElementById("contractViewGrid");
      let position = Array.from(child1.parentNode.children).indexOf(child1);
      let elements = document.getElementById("div1").children;
      if (elements.item(position) !== null) {
        let grid = elements.item(position).id;
        let width = "200%",
          margionleft = "-100%",
          mar = "176px";
        if (grid == "contractGrid") {
          const { resemargionorgspec, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            contractViewDiv: true,
            resetoverviewwidth: width,
            resemargionorgspec_left: margionleft,
            resemargionorgspec: mar,
            right_col_zIndex:"0",
          });
        } else if (grid == "NPIGrid") {
          const { resmarginonnpi, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            contractViewDiv: true,
            resetoverviewwidth: width,
            resemargionorgspec_left: margionleft,
            resmarginonnpi: mar,
          });
        } else if (grid == "degreeGrid") {
          const { resmarginondegree, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            contractViewDiv: true,
            resetoverviewwidth: width,
            resemargionorgspec_left: margionleft,
            resmarginondegree: mar,
          });
        } else if (grid == "trainingTypeGrid") {
          const { resmarginontrainingtype, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            contractViewDiv: true,
            resetoverviewwidth: width,
            resemargionorgspec_left: margionleft,
            resmarginontrainingtype: mar,
          });
        } else if (grid == "malpracticeGrid") {
          const { resmarginonmalpractice, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            contractViewDiv: true,
            resetoverviewwidth: width,
            resemargionorgspec_left: margionleft,
            resmarginonmalpractice: mar,
          });
        } else if (grid == "hospitalGrid") {
          const { resmarginonhospital, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            contractViewDiv: true,
            resetoverviewwidth: width,
            resemargionorgspec_left: margionleft,
            resmarginonhospital: mar,
          });
        }
      } else {
        const { ...updatedObject } = resetState;
        setState({
          ...state,
          ...updatedObject,
          contractViewDiv: true,
          resetoverviewwidth: "200%",
          resemargionorgspec_left: "-100%",
        });
      }
    }
  };

  const makeGridLargeforFedereal = () => {
    if (state.federealDiv) {
      let width = "",
        omar = "",
        margionleft = "",
        nmar = "",
        dmar = "",
        tmar = "",
        mmar = "",
        hmar = "";
      setState({
        ...state,
        federealDiv: false,
        resetfederalwidth: width,
        resemargionorgspec: omar,
        resmarginonnpi: nmar,
        resmarginontrainingtype: tmar,
        resmarginonmalpractice: mmar,
        resmarginonhospital: hmar,
        resmarginondegree: mmar,
        resemargionfederal_left: margionleft,
        right_col_zIndex:"1",
      });
    } else {
      let child1 = document.getElementById("federealGrid");
      let position = Array.from(child1.parentNode.children).indexOf(child1);
      let elements = document.getElementById("div1").children;
      if (elements.item(position) !== null) {
        let grid = elements.item(position).id;
        let width = "200%",
          margionleft = "-100%",
          mar = "176px";
        if (grid == "contractGrid") {
          const { resemargionorgspec, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            federealDiv: true,
            resetfederalwidth: width,
            resemargionfederal_left: margionleft,
            resemargionorgspec: mar,
          });
        } else if (grid == "NPIGrid") {
          const { resmarginonnpi, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            federealDiv: true,
            resetfederalwidth: width,
            resemargionfederal_left: margionleft,
            resmarginonnpi: mar,
            right_col_zIndex:"0",
          });
        } else if (grid == "degreeGrid") {
          const { resmarginondegree, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            federealDiv: true,
            resetfederalwidth: width,
            resemargionfederal_left: margionleft,
            resmarginondegree: mar,
          });
        } else if (grid == "trainingTypeGrid") {
          const { resmarginontrainingtype, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            federealDiv: true,
            resetfederalwidth: width,
            resemargionfederal_left: margionleft,
            resmarginontrainingtype: mar,
          });
        } else if (grid == "malpracticeGrid") {
          const { resmarginonmalpractice, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            federealDiv: true,
            resetfederalwidth: width,
            resemargionfederal_left: margionleft,
            resmarginonmalpractice: mar,
          });
        } else if (grid == "hospitalGrid") {
          const { resmarginonhospital, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            federealDiv: true,
            resetfederalwidth: width,
            resemargionfederal_left: margionleft,
            resmarginonhospital: mar,
          });
        }
      } else {
        const { ...updatedObject } = resetState;
        setState({
          ...state,
          ...updatedObject,
          federealDiv: true,
          resetfederalwidth: "200%",
          resemargionfederal_left: "-100%",
        });
      }
    }
  };

  const makeGridLargeforCDS = () => {
    if (state.CDSdiv) {
      let width = "",
        omar = "",
        margionleft = "",
        nmar = "",
        dmar = "",
        tmar = "",
        mmar = "",
        hmar = "";
      setState({
        ...state,
        CDSdiv: false,
        resetcdswidth: width,
        resemargionorgspec: omar,
        resmarginonnpi: nmar,
        resmarginontrainingtype: tmar,
        resmarginonmalpractice: mmar,
        resmarginonhospital: hmar,
        resmarginondegree: mmar,
        resemargioncds_left: margionleft,
        right_col_zIndex:"1",
      });
    } else {
      let child1 = document.getElementById("CDSGrid");
      let position = Array.from(child1.parentNode.children).indexOf(child1);
      let elements = document.getElementById("div1").children;
      if (elements.item(position) !== null) {
        let grid = elements.item(position).id;
        let width = "200%",
          margionleft = "-100%",
          mar = "176px";
        if (grid == "contractGrid") {
          const { resemargionorgspec, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            CDSdiv: true,
            resetcdswidth: width,
            resemargioncds_left: margionleft,
            resemargionorgspec: mar,
          });
        } else if (grid == "NPIGrid") {
          const { resmarginonnpi, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            CDSdiv: true,
            resetcdswidth: width,
            resemargioncds_left: margionleft,
            resmarginonnpi: mar,
          });
        } else if (grid == "degreeGrid") {
          const { resmarginondegree, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            CDSdiv: true,
            resetcdswidth: width,
            resemargioncds_left: margionleft,
            resmarginondegree: mar,
          });
        } else if (grid == "trainingTypeGrid") {
          const { resmarginontrainingtype, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            CDSdiv: true,
            resetcdswidth: width,
            resemargioncds_left: margionleft,
            resmarginontrainingtype: mar,
          });
        } else if (grid == "malpracticeGrid") {
          const { resmarginonmalpractice, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            CDSdiv: true,
            resetcdswidth: width,
            resemargioncds_left: margionleft,
            resmarginonmalpractice: mar,
          });
        } else if (grid == "hospitalGrid") {
          const { resmarginonhospital, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            CDSdiv: true,
            resetcdswidth: width,
            resemargioncds_left: margionleft,
            resmarginonhospital: mar,
          });
        }
      } else {
        const { ...updatedObject } = resetState;
        setState({
          ...state,
          ...updatedObject,
          CDSdiv: true,
          resetcdswidth: "200%",
          resemargioncds_left: "-100%",
        });
      }
    }
  };

  const makeGridLargeforLicense = () => {
    if (state.licenseDiv) {
      let width = "",
        omar = "",
        margionleft = "",
        nmar = "",
        dmar = "",
        tmar = "",
        mmar = "",
        hmar = "";
      setState({
        ...state,
        licenseDiv: false,
        resetlicensewidth: width,
        resemargionorgspec: omar,
        resmarginonnpi: nmar,
        resmarginontrainingtype: tmar,
        resmarginonmalpractice: mmar,
        resmarginonhospital: hmar,
        resmarginondegree: mmar,
        resemargionlicense_left: margionleft,
        right_col_zIndex:"1",
      });
    } else {
      let child1 = document.getElementById("licenseGrid");
      let position = Array.from(child1.parentNode.children).indexOf(child1);
      let elements = document.getElementById("div1").children;
      if (elements.item(position) !== null) {
        let grid = elements.item(position).id;
        let width = "200%",
          margionleft = "-100%",
          mar = "176px";
        if (grid == "contractGrid") {
          const { resemargionorgspec, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            licenseDiv: true,
            resetlicensewidth: width,
            resemargionlicense_left: margionleft,
            resemargionorgspec: mar,
          });
        } else if (grid == "NPIGrid") {
          const { resmarginonnpi, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            licenseDiv: true,
            resetlicensewidth: width,
            resemargionlicense_left: margionleft,
            resmarginonnpi: mar,
          });
        } else if (grid == "degreeGrid") {
          const { resmarginondegree, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            licenseDiv: true,
            resetlicensewidth: width,
            resemargionlicense_left: margionleft,
            resmarginondegree: mar,
            right_col_zIndex:"0",
          });
        } else if (grid == "trainingTypeGrid") {
          const { resmarginontrainingtype, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            licenseDiv: true,
            resetlicensewidth: width,
            resemargionlicense_left: margionleft,
            resmarginontrainingtype: mar,
          });
        } else if (grid == "malpracticeGrid") {
          const { resmarginonmalpractice, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            licenseDiv: true,
            resetlicensewidth: width,
            resemargionlicense_left: margionleft,
            resmarginonmalpractice: mar,
          });
        } else if (grid == "hospitalGrid") {
          const { resmarginonhospital, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            licenseDiv: true,
            resetlicensewidth: width,
            resemargionlicense_left: margionleft,
            resmarginonhospital: mar,
          });
        }
      } else {
        const { ...updatedObject } = resetState;
        setState({
          ...state,
          ...updatedObject,
          licenseDiv: true,
          resetlicensewidth: "200%",
          resemargionlicense_left: "-100%",
        });
      }
    }
  };
  const makeGridLargeforMedicare = () => {
    if (state.medicareDiv) {
      let width = "",
        omar = "",
        margionleft = "",
        nmar = "",
        dmar = "",
        tmar = "",
        mmar = "",
        hmar = "";
      setState({
        ...state,
        medicareDiv: false,
        resetmedicarewidth: width,
        resemargionorgspec: omar,
        resmarginonnpi: nmar,
        resmarginontrainingtype: tmar,
        resmarginonmalpractice: mmar,
        resmarginonhospital: hmar,
        resmarginondegree: mmar,
        resemargionmedicare_left: margionleft,
        right_col_zIndex:"1",
      });
    } else {
      let child1 = document.getElementById("medicareGrid");
      let position = Array.from(child1.parentNode.children).indexOf(child1);
      let elements = document.getElementById("div1").children;
      if (elements.item(position) !== null) {
        let grid = elements.item(position).id;
        let width = "200%",
          margionleft = "-100%",
          mar = "176px";
        if (grid == "contractGrid") {
          const { resemargionorgspec, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            medicareDiv: true,
            resetmedicarewidth: width,
            resemargionmedicare_left: margionleft,
            resemargionorgspec: mar,
          });
        } else if (grid == "NPIGrid") {
          const { resmarginonnpi, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            medicareDiv: true,
            resetmedicarewidth: width,
            resemargionmedicare_left: margionleft,
            resmarginonnpi: mar,
          });
        } else if (grid == "degreeGrid") {
          const { resmarginondegree, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            medicareDiv: true,
            resetmedicarewidth: width,
            resemargionmedicare_left: margionleft,
            resmarginondegree: mar,
          });
        } else if (grid == "trainingTypeGrid") {
          const { resmarginontrainingtype, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            medicareDiv: true,
            resetmedicarewidth: width,
            resemargionmedicare_left: margionleft,
            resmarginontrainingtype: mar,
            right_col_zIndex:"0",
          });
        } else if (grid == "malpracticeGrid") {
          const { resmarginonmalpractice, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            medicareDiv: true,
            resetmedicarewidth: width,
            resemargionmedicare_left: margionleft,
            resmarginonmalpractice: mar,
          });
        } else if (grid == "hospitalGrid") {
          const { resmarginonhospital, ...updatedObject } = resetState;
          setState({
            ...state,
            ...updatedObject,
            medicareDiv: true,
            resetmedicarewidth: width,
            resemargionmedicare_left: margionleft,
            resmarginonhospital: mar,
          });
        }
      } else {
        const { ...updatedObject } = resetState;
        setState({
          ...state,
          ...updatedObject,
          medicareDiv: true,
          resetmedicarewidth: "200%",
          resemargionmedicare_left: "-100%",
        });
      }
    }
  };

  const options = [
    { label: "CDS", value: "CDS" },
    { label: "Contract Org(Overview)", value: "Contract Org(Overview)" },
    { label: "Contract Org(Speciality)", value: "Contract Org(Speciality)" },
    { label: "DEA", value: "DEA" },
    { label: "Degree", value: "Degree" },
    { label: "Hospital Affiliation", value: "Hospital Affiliation" },
    { label: "License", value: "License" },
    { label: "Malpractice", value: "Malpractice" },
    { label: "Medicare", value: "Medicare" },
    { label: "MISC Section", value: "MISC Section" },
    { label: "MPIN Section", value: "MPIN Section" },
    { label: "Name Section", value: "Name Section" },
    { label: "NPI", value: "NPI" },
    { label: "Training", value: "Training" },
    { label: "Include Blank Sections", value: "Include Blank Sections" },
  ];

  const handleClick = () => {
    let dcontractGrid = false;
    let dcontractViewGrid = false;
    let dNPIGrid = false;
    let ddegreeGrid = false;
    let dfederealGrid = false;
    let dCDSGrid = false;
    let dlicenseGrid = false;
    let dmalpracticeGrid = false;
    let dmedicareGrid = false;
    let dhospitalGrid = false;
    let dtrainingTypeGrid = false;
    let MPINSection = false;
    let NameSection = false;
    let MISCSection = false;
    let BlankSection = false;
    selected.map((el) => {
      if (el.label == "Contract Org(Overview)") {
        dcontractViewGrid = true;
      }
      if (el.label == "Contract Org(Speciality)") {
        dcontractGrid = true;
      }
      if (el.label == "NPI") {
        dNPIGrid = true;
      }
      if (el.label == "Degree") {
        ddegreeGrid = true;
      }
      if (el.label == "DEA") {
        dfederealGrid = true;
      }
      if (el.label == "CDS") {
        dCDSGrid = true;
      }
      if (el.label == "Training") {
        dtrainingTypeGrid = true;
      }
      if (el.label == "License") {
        dlicenseGrid = true;
      }
      if (el.label == "Malpractice") {
        dmalpracticeGrid = true;
      }
      if (el.label == "Medicare") {
        dmedicareGrid = true;
      }
      if (el.label == "Hospital Affiliation") {
        dhospitalGrid = true;
      }
      if (el.label == "MPIN Section") {
        MPINSection = true;
      }
      if (el.label == "Name Section") {
        NameSection = true;
      }
      if (el.label == "MISC Section") {
        MISCSection = true;
      }
      if (el.label == "Include Blank Sections") {
        dcontractGrid = true;
        dcontractViewGrid = true;
        dNPIGrid = true;
        ddegreeGrid = true;
        dfederealGrid = true;
        dCDSGrid = true;
        dlicenseGrid = true;
        dmalpracticeGrid = true;
        dmedicareGrid = true;
        dhospitalGrid = true;
        dtrainingTypeGrid = true;
        MPINSection = true;
        NameSection = true;
        MISCSection = true;
        setSelected(options);
      }
    });
    setState({
      ...state,
      contractGrid: dcontractGrid,
      contractViewGrid: dcontractViewGrid,
      NPIGrid: dNPIGrid,
      degreeGrid: ddegreeGrid,
      federealGrid: dfederealGrid,
      CDSGrid: dCDSGrid,
      trainingTypeGrid: dtrainingTypeGrid,
      licenseGrid: dlicenseGrid,
      malpracticeGrid: dmalpracticeGrid,
      medicareGrid: dmedicareGrid,
      hospitalGrid: dhospitalGrid,
      MPINSection: MPINSection,
      NameSection: NameSection,
      MISCSection: MISCSection,
    });
    // if (selected.length == 15 && pType == 'p' || selected.length == 14 && pType == 'o') {
    //   setState({
    //     ...state, contractGrid: true, contractViewGrid: true, NPIGrid: true, degreeGrid: true, federealGrid: true
    //     , CDSGrid: true, trainingTypeGrid: true, licenseGrid: true, malpracticeGrid: true, medicareGrid: true, hospitalGrid: true,
    //     MPINSection: true, NameSection: true, MISCSection: true
    //   })
    //   if (pType == 'p') {
    //     setSelected(options)
    //   }
    //   else {
    //     setSelected(options.filter((f) => f.label != "Degree"))
    //   }
    // }
    setOpen(false);
  };

  const gridDisplay = () => {
    if (pType == "p") {
      return (
        <div id="degreeGrid">
          <div
            style={{
              overflow: "scroll",
              height: "170px",
              width: state.resizewidthDegree,
              marginTop: state.resmarginondegree,
            }}
          >
            <table id="resizeDegree" style={{ width: "100%" }} class="table">
              <thead>
                <tr>
                  <th class="resizeTH stickyThTd">
                    <Tooltip
                      title={
                        <div
                          style={{
                            backgroundColor: "white",
                            color: "black",

                            width: "290px",
                            paddingLeft: "3px",
                            paddingRight: "5px",
                            paddingTop: "5px",
                          }}
                        >
                          <b>NDB Screen Name/Mapping</b> <b>(</b>Category-Area-F
                          Key<b>):</b>PROVIDER EDUCATION INFORMATION (D-Z)
                          <br />
                          <br />
                          Degree code indicates the education the provider has
                          attained (e.g. MD for Medical Doctor or PHD for Doctor
                          of Philosopy.
                        </div>
                      }
                    >
                      {
                        <b className={classes.inputText2}>
                          <b> Degree</b>{" "}
                        </b>
                      }
                    </Tooltip>
                  </th>
                  <th class="resizeTH">Description</th>
                  <th class="resizeTH">Complete Date</th>
                  <th class="resizeTH">
                    School <br /> Code
                  </th>
                  <th class="resizeTH">
                    School <br /> Name
                  </th>
                  <th class="resizeTH defaultThWidth50">
                    Act <br /> Cd
                  </th>
                  <th class="resizeTH">P/S</th>
                </tr>
              </thead>
              <tbody>
                {state.DegreeInfo.map((DegreeInfoata) => (
                  <tr
                    style={{
                      color: DegreeInfoata.actv_cd == "I" ? "#58cde8" : "",
                      lineHeight: "18px",
                    }}
                  >
                    <td>{DegreeInfoata.deg_cd}</td>
                    <td>
                      <EllipsisToolTip options={Options}>
                        {DegreeInfoata.deg_desc}
                      </EllipsisToolTip>
                    </td>
                    <td>{changeDateFormat(DegreeInfoata.cmplt_dt)}</td>
                    <td>{DegreeInfoata.schl_cd}</td>
                    <td>
                      <EllipsisToolTip options={Options}>
                        {DegreeInfoata.schl_desc}
                      </EllipsisToolTip>
                    </td>
                    <td>{DegreeInfoata.actv_cd}</td>
                    <td>{DegreeInfoata.pri_cd}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div
            style={{
              position: "absolute",
              marginTop: "-3%",
              marginLeft: state.degreeDiv ? "191.5%" : "93%",
            }}
          >
            <HeightIcon
              onClick={makeGridLargeforDegree}
              style={{ cursor: "pointer", transform: "rotate(90deg)" }}
            />
          </div>
        </div>
      );
    } else {
      return null;
    }
  };

  const resetHandler = () => {
    setIsArrow(false); //alt name reset
    // const resetSelected = optionsReset.filter(({ label, value }) =>
    //   !selected.some(exclude => exclude.label === label && exclude.value === value)
    // );
    let tempObj = [
      { label: "MPIN Section", value: "MPIN Section" },
      { label: "Name Section", value: "Name Section" },
      { label: "MISC Section", value: "MISC Section" },
    ];
    state.Contract_Org_Spec.length > 0
      ? tempObj.push({
        label: "Contract Org(Overview)",
        value: "Contract Org(Overview)",
      })
      : "";
    state.Contract_org_info.length > 0
      ? tempObj.push({
        label: "Contract Org(Speciality)",
        value: "Contract Org(Speciality)",
      })
      : "";
    state.NPIinfo.length > 0
      ? tempObj.push({ label: "NPI", value: "NPI" })
      : "";
    state.Federal_DEA_info.length > 0
      ? tempObj.push({ label: "DEA", value: "DEA" })
      : "";
    pType == "p"
      ? state.DegreeInfo.length > 0
        ? tempObj.push({ label: "Degree", value: "Degree" })
        : ""
      : "";
    state.Cds_info.length > 0
      ? tempObj.push({ label: "CDS", value: "CDS" })
      : "";
    state.Training_info.length > 0
      ? tempObj.push({ label: "Training", value: "Training" })
      : "";
    state.License_info.length > 0
      ? tempObj.push({ label: "License", value: "License" })
      : "";
    state.Malpractice_info.length > 0
      ? tempObj.push({ label: "Malpractice", value: "Malpractice" })
      : "";
    state.Medicare_info.length > 0
      ? tempObj.push({ label: "Medicare", value: "Medicare" })
      : "";
    state.Hospital_affiliation_info.length > 0
      ? tempObj.push({
        label: "Hospital Affiliation",
        value: "Hospital Affiliation",
      })
      : "";
    setSelected(tempObj);
    setState({
      ...state,
      contractGrid: state.Contract_org_info.length > 0 ? true : false,
      contractViewGrid: state.Contract_Org_Spec.length > 0 ? true : false,
      NPIGrid: state.NPIinfo.length > 0 ? true : false,
      federealGrid: state.Federal_DEA_info.length > 0 ? true : false,
      CDSGrid: state.Cds_info.length > 0 ? true : false,
      trainingTypeGrid: state.Training_info.length > 0 ? true : false,
      licenseGrid: state.License_info.length > 0 ? true : false,
      malpracticeGrid: state.Malpractice_info.length > 0 ? true : false,
      medicareGrid: state.Medicare_info.length > 0 ? true : false,
      hospitalGrid: state.Hospital_affiliation_info.length > 0 ? true : false,
      degreeGrid:
        pType == "p" ? (state.DegreeInfo.length > 0 ? true : false) : false,
      MPINSection: true,
      NameSection: true,
      MISCSection: true,
      ...resetState,
    });
    // setSelected([{ label: "Contract Org(Overview)", value: "Contract Org(Overview)" }, { label: "Contract Org(Speciality)", value: "Contract Org(Speciality)" }, { label: "NPI", value: "NPI" }, { label: "DEA", value: "DEA" }, { label: "Degree", value: "Degree" },
    // { label: "CDS", value: "CDS" }, { label: "Training", value: "Training" }, { label: "License", value: "License" }, { label: "Malpractice", value: "Malpractice" }, { label: "Medicare", value: "Medicare" },
    // { label: "Hospital Affiliation", value: "Hospital Affiliation" }, { label: "MPIN Section", value: "MPIN Section" }, { label: "Name Section", value: "Name Section" }, { label: "MISC Section", value: "MISC Section" }])
    // selected = selected.concat(resetSelected);
    // console.log("resetSelectedresetSelectedresetSelected======", resetSelected, selected)
    // optionsReset.map(item1 => {
    //   let resetSelected = [];
    //   selected.map(item2 => {
    //     if (item1.label == item2.label && item1.value == item2.value) { }
    //     else resetSelected.push(item1)
    //   })
    // })

    //Reset the Resize functionality of contract Org
    // if (state.contractGrid) {
    //   for (var i = 0; i < document.getElementById("resizeContractOrg").getElementsByTagName("th").length; i++) {
    //     document.getElementById("resizeContractOrg").getElementsByTagName("th")[i].style.width = "auto";
    //     document.getElementById("resizeContractOrg").getElementsByTagName("th")[i].style.left = "auto";
    //   }

    //   for (var i = 0; i < document.getElementById("resizeContractOrg").getElementsByTagName("td").length; i++) {
    //     document.getElementById("resizeContractOrg").getElementsByTagName("td")[i].style.left = "auto";
    //   }
    // }

    // //Reset the Resize functionality of contract View
    // if (state.contractViewGrid) {
    //   for (var i = 0; i < document.getElementById("resizeContractView").getElementsByTagName("th").length; i++) {
    //     document.getElementById("resizeContractView").getElementsByTagName("th")[i].style.width = "auto";
    //     document.getElementById("resizeContractView").getElementsByTagName("th")[i].style.left = "auto";
    //   }

    //   for (var i = 0; i < document.getElementById("resizeContractView").getElementsByTagName("td").length; i++) {
    //     document.getElementById("resizeContractView").getElementsByTagName("td")[i].style.left = "auto";
    //   }
    // }

    // //Reset the Resize functionality of NPI
    // if (state.NPIGrid) {
    //   for (var i = 0; i < document.getElementById("resizeNPI").getElementsByTagName("th").length; i++) {
    //     document.getElementById("resizeNPI").getElementsByTagName("th")[i].style.width = "auto";
    //     document.getElementById("resizeNPI").getElementsByTagName("th")[i].style.left = "auto";
    //   }

    //   for (var i = 0; i < document.getElementById("resizeNPI").getElementsByTagName("td").length; i++) {
    //     document.getElementById("resizeNPI").getElementsByTagName("td")[i].style.left = "auto";
    //   }
    // }

    // //Reset the Resize functionality of Federal
    // if (state.federealGrid) {
    //   for (var i = 0; i < document.getElementById("resizeFedereal").getElementsByTagName("th").length; i++) {
    //     document.getElementById("resizeFedereal").getElementsByTagName("th")[i].style.width = "auto";
    //     document.getElementById("resizeFedereal").getElementsByTagName("th")[i].style.left = "auto";
    //   }

    //   for (var i = 0; i < document.getElementById("resizeFedereal").getElementsByTagName("td").length; i++) {
    //     document.getElementById("resizeFedereal").getElementsByTagName("td")[i].style.left = "auto";
    //   }
    // }

    // //Reset the Resize functionality of Degree
    // if (state.degreeGrid) {
    //   if (pType == 'p') {
    //     for (var i = 0; i < document.getElementById("resizeDegree").getElementsByTagName("th").length; i++) {
    //       document.getElementById("resizeDegree").getElementsByTagName("th")[i].style.width = "auto";
    //       document.getElementById("resizeDegree").getElementsByTagName("th")[i].style.left = "auto";
    //     }

    //     for (var i = 0; i < document.getElementById("resizeDegree").getElementsByTagName("td").length; i++) {
    //       document.getElementById("resizeDegree").getElementsByTagName("td")[i].style.left = "auto";
    //     }
    //   }
    // }

    // //Reset the Resize functionality of CDS
    // if (state.CDSGrid) {
    //   for (var i = 0; i < document.getElementById("resizeCDS").getElementsByTagName("th").length; i++) {
    //     document.getElementById("resizeCDS").getElementsByTagName("th")[i].style.width = "auto";
    //     document.getElementById("resizeCDS").getElementsByTagName("th")[i].style.left = "auto";
    //   }

    //   for (var i = 0; i < document.getElementById("resizeCDS").getElementsByTagName("td").length; i++) {
    //     document.getElementById("resizeCDS").getElementsByTagName("td")[i].style.left = "auto";
    //   }
    // }

    // //Reset the Resize functionality of Traning type
    // if (state.trainingTypeGrid) {
    //   for (var i = 0; i < document.getElementById("resizeTrainingType").getElementsByTagName("th").length; i++) {
    //     document.getElementById("resizeTrainingType").getElementsByTagName("th")[i].style.width = "auto";
    //     document.getElementById("resizeTrainingType").getElementsByTagName("th")[i].style.left = "auto";
    //   }

    //   for (var i = 0; i < document.getElementById("resizeTrainingType").getElementsByTagName("td").length; i++) {
    //     document.getElementById("resizeTrainingType").getElementsByTagName("td")[i].style.left = "auto";
    //   }
    // }

    // //Reset the Resize functionality of License
    // if (state.licenseGrid) {
    //   for (var i = 0; i < document.getElementById("resizeLicense").getElementsByTagName("th").length; i++) {
    //     document.getElementById("resizeLicense").getElementsByTagName("th")[i].style.width = "auto";
    //     document.getElementById("resizeLicense").getElementsByTagName("th")[i].style.left = "auto";
    //   }

    //   for (var i = 0; i < document.getElementById("resizeLicense").getElementsByTagName("td").length; i++) {
    //     document.getElementById("resizeLicense").getElementsByTagName("td")[i].style.left = "auto";
    //   }
    // }

    // //Reset the Resize functionality of Malpractice
    // if (state.malpracticeGrid) {
    //   for (var i = 0; i < document.getElementById("resizeMalpractice").getElementsByTagName("th").length; i++) {
    //     document.getElementById("resizeMalpractice").getElementsByTagName("th")[i].style.width = "auto";
    //     document.getElementById("resizeMalpractice").getElementsByTagName("th")[i].style.left = "auto";
    //   }

    //   for (var i = 0; i < document.getElementById("resizeMalpractice").getElementsByTagName("td").length; i++) {
    //     document.getElementById("resizeMalpractice").getElementsByTagName("td")[i].style.left = "auto";
    //   }
    // }

    // //Reset the Resize functionality of Medicare
    // if (state.medicareGrid) {
    //   for (var i = 0; i < document.getElementById("resizeMedicare").getElementsByTagName("th").length; i++) {
    //     document.getElementById("resizeMedicare").getElementsByTagName("th")[i].style.width = "auto";
    //     document.getElementById("resizeMedicare").getElementsByTagName("th")[i].style.left = "auto";
    //   }

    //   for (var i = 0; i < document.getElementById("resizeMedicare").getElementsByTagName("td").length; i++) {
    //     document.getElementById("resizeMedicare").getElementsByTagName("td")[i].style.left = "auto";
    //   }
    // }

    // //Reset the Resize functionality of Hospital
    // if (state.hospitalGrid) {
    //   for (var i = 0; i < document.getElementById("resizeHospital").getElementsByTagName("th").length; i++) {
    //     document.getElementById("resizeHospital").getElementsByTagName("th")[i].style.width = "auto";
    //     document.getElementById("resizeHospital").getElementsByTagName("th")[i].style.left = "auto";
    //   }

    //   for (var i = 0; i < document.getElementById("resizeHospital").getElementsByTagName("td").length; i++) {
    //     document.getElementById("resizeHospital").getElementsByTagName("td")[i].style.left = "auto";
    //   }
    // }
    setOpen(false);
  };
  const handleClose = () => {
    setOpen(false);
  };
  const handleClickOpen = () => {
    setOpen(true);
    setTimeout(() => {
      var event = document.createEvent("SVGEvents");
      event.initEvent("click", true, true);
      document
        .getElementsByClassName("dropdown-heading-dropdown-arrow gray")[0]
        .dispatchEvent(event);
    }, 500);
  };
  const prependZerosForBoard = (value) => {
    if (value.length !== 0 && typeof value !== "undefined") {
      for (let i = value.length; i < 9; i++) {
        value = "0" + value;
      }
      return value;
    }
  };
  const changeDateFormat = (date) => {
    if (typeof date !== "undefined") {
      if (date.length > 0) {
        let dt = date.toString();
        dt = dt.split("-");
        return `${dt[1]}-${dt[2]}-${dt[0]}`;
      }
    }
  };
  const compareDate = (date) => {
    let dt = Moment(date, "YYYY-MM-DD");
    let now = Moment("YYYY-MM-DD");
    // console.log("dt,now", dt, now);
    if (now > dt) {
      return true;
    } else {
      return false;
    }
  };

  const prependZerosForMaidType = (val, val2) => {
    if (val2.length !== 0) {
      for (let i = val2.length; i < 9; i++) {
        val2 = "0" + val2;
      }
      // return value;
    }

    switch (val) {
      case "H":
        return "BILL" + "- " + val2;
      case "L":
        return "PLSV" + "- " + val2;
      case "D":
        return "COMB" + "- " + val2;
      case "P":
        return "CRED" + "- " + val2;
      case "T":
        return "MAIL" + "- " + val2;
      default:
    }
    return val + val2;
  };
  //console.log("state.ABMS_Bio_Number =========>",state.ABMS_Bio_Number == undefined)

  return (
    // <div style={{overflowY:"scroll",overflowX:"hidden"}}>
    <Paper style={{ borderRadius: 3 }}>
      <div className={classes.sticky}>
        <Grid container spacing={1}>
          <Grid item xs={4}>
            <Typography
              variant="body1"
              component="div"
              className={classes.headerText}
              style={{ marginBottom: 0 }}
            >
              Profile
            </Typography>
          </Grid>
          <Grid item xs={4}>
            <center>
              <Button
                variant="contained"
                color="primary"
                size="small"
                style={{ marginTop: "-5px" }}
                onClick={handleClickOpen}
              >
                VIEW OPTIONS
              </Button>
            </center>
          </Grid>
          <Grid item xs={4}>
            <Breadcrumbs
              separator={
                <NavigateNextIcon classes={{ root: classes.customLink }} />
              }
              style={{ display: "flex", float: "right" }}
              aria-label="link-levels"
            >
              {/* <Link classes={{ root: classes.customLink }} href="/providers/search-provider">
                Menu
              </Link> */}
              <Link
                classes={{ root: classes.customLink }}
                href="/providers/search-provider"
              >
                Search
              </Link>
              <Link
                classes={{ root: classes.customLink }}
                href="/providers/result-provider"
              >
                Results
              </Link>
              <Link
                classes={{ root: classes.customLink }}
                href="/providers/provider-Details"
              >
                Profile
              </Link>
            </Breadcrumbs>
          </Grid>
        </Grid>
        <Divider />
        <Grid container spacing={1} style={{ height: 25 }}>
          <Grid item xs={6}>
            <Typography
              variant="body1"
              component="div"
              className={classes.headerText}
              style={{ marginBottom: 0 }}
            >
              <Tooltip
                classes={{ tooltip: classes.customWidth }}
                title={
                  <div
                    style={{
                      backgroundColor: "white",
                      color: "black",
                      paddingLeft: "5px",
                      paddingRight: "5px",
                      paddingTop: "5px",
                      width: "300px",
                    }}
                  >
                    NDB Screen Name/Mapping (Category-Area-F Key): MAIN (M-Z)
                    <br />
                    <br />
                    Medical Provider Identification Number (MPIN) is a nine
                    digit NDB provider number leveraged to uniquely identify
                    individual physicians, allied health professionals, group
                    entities, ancillary providers, hospitals, or subparts of
                    them to reference associated details such as (but not
                    limited to):
                    <br />
                    • Profile/Credentialing
                    <br />
                    • Contracts/Rates
                    <br />
                    • Claims/Directory
                    <br />
                    • Affiliations (Hospital, Corporate Owner, PTI Group, etc.)
                    <br />
                    • Care Coordination
                    <br />
                    NOTE: MPIN can also be leveraged to identify providers in
                    other legacy/claims platforms (e.g. NICE, Pulse, CSP,
                    COSMOS, & UNET/TOPS).
                  </div>
                }
              >
                {
                  <b className={classes.inputText2}>
                    <b> MPIN:</b>{" "}
                  </b>
                }
              </Tooltip>
              <Tooltip
                title={
                  <div
                    style={{
                      backgroundColor: "white",
                      color: "black",
                      paddingLeft: "5px",
                      paddingRight: "5px",
                      paddingTop: "3px",
                      paddingBottom: "3px",
                    }}
                  >
                    <table border="0" cellSpacing="0" cellPadding="0">
                      <tbody>
                        <tr>
                          <td
                            style={{
                              color:
                                new Date(state.Deactivation_Date).getTime() >=
                                  new Date().getTime()
                                  ? "black"
                                  : "#58cde8",
                            }}
                          >
                            {state.providerprofileinforsingle_name.fst_nm !==
                              "" &&
                              state.providerprofileinforsingle_name.fst_nm !==
                              undefined
                              ? state.providerprofileinforsingle_name.fst_nm
                              : ""}
                            {state.providerprofileinforsingle_name.mdl_nm !==
                              "" &&
                              state.providerprofileinforsingle_name.mdl_nm !==
                              undefined
                              ? " " +
                              state.providerprofileinforsingle_name.mdl_nm
                              : ""}
                            {state.providerprofileinforsingle_name.lst_nm !==
                              "" &&
                              state.providerprofileinforsingle_name.lst_nm !==
                              undefined
                              ? " " +
                              state.providerprofileinforsingle_name.lst_nm
                              : ""}
                            {state.providerprofileinforsingle_name
                              .nm_sufx_cd !== "" &&
                              state.providerprofileinforsingle_name.nm_sufx_cd !==
                              undefined
                              ? " " +
                              state.providerprofileinforsingle_name.nm_sufx_cd
                              : ""}
                            {state.providerprofileinforsingle_name.deg_cd !==
                              "" &&
                              state.providerprofileinforsingle_name.deg_cd !==
                              undefined
                              ? ", " +
                              state.providerprofileinforsingle_name.deg_cd
                              : ""}
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                }
              >
                {
                  <b
                    style={{
                      color:
                        state.Deactivation_Date == ""
                          ? "black"
                          : new Date(state.Deactivation_Date).getTime() >=
                            new Date().getTime()
                            ? "black"
                            : "#58cde8",
                    }}
                    className={classes.inputText2}
                  >
                    {MPIN}
                  </b>
                }
              </Tooltip>
            </Typography>
          </Grid>
          <Grid item xs={6}>
            {/* <div style={{ display: 'flex', float: 'right' }}>
              <Typography variant="body1" component="div" className={classes.headerText} style={{ marginBottom: 0 }}>
                PAGE <span className={classes.inputText2}>0001</span> OF <span className={classes.inputText2}>0002</span></Typography>
              <ArrowLeftIcon fontSize="medium" onClick={() => alert('previous page ')} className={classes.paginationIcons} />
              <ArrowRightIcon fontSize="medium" onClick={() => alert('Next page')} className={classes.paginationIcons} /></div> */}
          </Grid>
        </Grid>
      </div>
      {/* { state.loading ?
      <div
      style={{
        width: "100%",
        height: "100",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        color: "#48ce1c"
      }}
    >
      <br /> <br /> <br /> <br />
      <img src={loder} alt="loder" height="50" width="50" />
    </div>: */}
      {state.backEndError ? (
        <Error />
      ) : (
          <div>
            <Dialog
              open={open}
              onClose={handleClose}
              aria-labelledby="form-dialog-title"
              maxWidth="md"
              style={{ zIndex: 9999 }}
            >
              {/* <DialogTitle id="form-dialog-title">Subscribe</DialogTitle> */}
              <DialogContent style={{ width: "300px", height: "375px" }}>
                <MultiSelect
                  options={
                    pType == "p"
                      ? options
                      : options.filter((f) => f.label != "Degree")
                  }
                  value={selected}
                  onChange={setSelected}
                  overrideStrings={{ selectSomeItems: "VIEW OPTIONS" }}
                />
              </DialogContent>
              <DialogActions>
                <Button onClick={handleClick} color="primary">
                  Update
              </Button>
                <Button onClick={handleClose} color="primary">
                  Cancel
              </Button>
                <Button onClick={resetHandler} color="primary">
                  Reset
              </Button>
              </DialogActions>
            </Dialog>
            <Divider />
            {state.MPINSection ? (
              <div className={classes.masterRoot}>
                <Grid
                  container
                  spacing={1}
                  className={classes.bgcolor}
                  style={{ paddingLeft: "15px", paddingTop: "0px" }}
                >
                  <Grid item xs={3}>
                    <div
                      style={{ borderRight: "1px solid black", display: "grid" }}
                    >
                      <Typography
                        variant="body1"
                        component="span"
                        className={classes.inputText}
                      >


                        <Tooltip
                          classes={{ tooltip: classes.customWidth }}
                          title={
                            <div
                              style={{
                                backgroundColor: "white",
                                color: "black",
                                paddingLeft: "5px",
                                paddingRight: "5px",
                                paddingTop: "5px",
                                width: "300px",
                              }}
                            >
                              NDB Screen Name/Mapping (Category-Area-F Key):  MAIN (M-Z)<br /><br />

                        The MPIN's original effective date.  This field is not updateable once entered.
                        </div>
                          }
                        >
                          {
                            <span>  Original Effective Date:{" "}</span>


                          }
                        </Tooltip>
                        <span
                          style={{
                            fontWeight: "500",
                            color:
                              new Date(state.Deactivation_Date).getTime() >=
                                new Date().getTime()
                                ? "black"
                                : "#58cde8",
                          }}
                        >
                          {changeDateFormat(state.orignal_eefctive_date)}
                        </span>
                      </Typography>
                      <Typography
                        variant="body1"
                        component="span"
                        className={classes.inputText}
                      >
                        <Tooltip
                          classes={{ tooltip: classes.customWidth }}
                          title={
                            <div
                              style={{
                                backgroundColor: "white",
                                color: "black",
                                paddingLeft: "5px",
                                paddingRight: "5px",
                                paddingTop: "5px",
                                width: "300px",
                              }}
                            >
                              NDB Screen Name/Mapping (Category-Area-F Key):  MAIN (M-Z)<br /><br />

                      The effective date of the newly added MPIN or subsequent timelined data.
                      </div>
                          }
                        >
                          {
                            <span> Current Effective Date:{" "}</span>


                          }
                        </Tooltip>

                        <span
                          style={{
                            paddingLeft: "2px",
                            fontWeight: "500",
                            color:
                              new Date(state.Deactivation_Date).getTime() >=
                                new Date().getTime()
                                ? "black"
                                : "#58cde8",
                          }}
                        >
                          {changeDateFormat(state.Current_Effective_Date)}
                        </span>
                      </Typography>
                      <Typography
                        variant="body1"
                        component="span"
                        className={classes.inputText}
                      >
                        <Tooltip
                          classes={{ tooltip: classes.customWidth }}
                          title={
                            <div
                              style={{
                                backgroundColor: "white",
                                color: "black",
                                paddingLeft: "5px",
                                paddingRight: "5px",
                                paddingTop: "5px",
                                width: "300px",
                              }}
                            >
                              NDB Screen Name/Mapping (Category-Area-F Key):  MAIN (M-Z)<br /><br />

                      The MPIN's cancellation date is leveraged to discontinue use of timelined data. If the MPIN is active the cancellation date field will be populated with 12/31/9999 on most current timelined data.

                      </div>
                          }
                        >
                          {
                            <span> Cancel Date:{" "}</span>


                          }
                        </Tooltip>


                        <span
                          style={{
                            paddingLeft: "64px",
                            fontWeight: "500",
                            color:
                              new Date(state.Deactivation_Date).getTime() >=
                                new Date().getTime()
                                ? "black"
                                : "#58cde8",
                          }}
                        >
                          {changeDateFormat(state.Cancel_Date)}
                        </span>
                      </Typography>
                      <Typography
                        variant="body1"
                        component="span"
                        className={classes.inputText}
                        style={{ display: "flex" }}
                      >
                        <Tooltip
                          classes={{ tooltip: classes.customWidth }}
                          title={
                            <div
                              style={{
                                backgroundColor: "white",
                                color: "black",
                                paddingLeft: "5px",
                                paddingRight: "5px",
                                paddingTop: "5px",
                                width: "300px",
                              }}
                            >
                              NDB Screen Name/Mapping (Category-Area-F Key):  MAIN (M-Z)<br /><br />
                      The MPIN's cancellation reason code is leveraged to identify purpose of discontinued use of timelined data.        </div>
                          }
                        >
                          {
                            <span>    Cancel Reason:{" "}</span>


                          }
                        </Tooltip>

                        <span
                          style={{
                            marginLeft: "10px",
                            maxWidth: "63%",
                            fontWeight: "500",
                            color:
                              new Date(state.Deactivation_Date).getTime() >=
                                new Date().getTime()
                                ? "black"
                                : "#58cde8",
                          }}
                        >
                          
                          <EllipsisToolTip
                            options={Options}
                            style={{ width: "255px" }}
                          >
                            {state.Cancel_Reason}&nbsp;&nbsp;{""}
                          </EllipsisToolTip>
                        </span>
                      </Typography>
                      <Typography
                        variant="body1"
                        component="span"
                        className={classes.inputText}
                        style={{ display: "flex" }}
                      >

                        <Tooltip
                          classes={{ tooltip: classes.customWidth }}
                          title={
                            <div
                              style={{
                                backgroundColor: "white",
                                color: "black",
                                paddingLeft: "5px",
                                paddingRight: "5px",
                                paddingTop: "5px",
                                width: "300px",
                              }}
                            >
                              <b>NDB Screen Name/Mapping (</b>Category-Area-F Key<b>):</b>  MAIN (M-Z)<br /><br />

Duplicate reason code identifies why more than one MPIN was created for a single provider.
<br /><br />
                              <b>03=</b> Greater than 120 Contract Lines
<br />
                              <b>04=</b> Benefit differs and requires additional provider type
<br />
                              <b>05=</b> Directory vs. Claim name
<br />
                              <b>06=</b> Fee schedule vs. Facility Rates for same provider
<br />
                              <b>07=</b> Not an existing provider
<br />




                            </div>
                          }
                        >
                          {
                            <span> Dup Reason:{" "}</span>


                          }
                        </Tooltip>


                        <span
                          style={{
                            marginLeft: "28px",
                            maxWidth: "63%",
                            fontWeight: "500",
                            color:
                              new Date(state.Deactivation_Date).getTime() >=
                                new Date().getTime()
                                ? "black"
                                : "#58cde8",
                          }}
                        >
                          <EllipsisToolTip
                            options={Options}
                            style={{ width: "260px" }}
                          >
                            {state.Dup_Reason}&nbsp;&nbsp;{""}
                          </EllipsisToolTip>
                        </span>
                      </Typography>
                    </div>
                  </Grid>
                  {/* <div className={classes.line}></div> */}
                  <Grid item xs={3} style={{ paddingLeft: "0px" }}>
                    <div
                      style={{ borderRight: "1px solid black", display: "grid" }}
                    >
                      <Typography
                        variant="body1"
                        component="span"
                        className={classes.inputText}
                      >

                        <Tooltip
                          classes={{ tooltip: classes.customWidth }}
                          title={
                            <div
                              style={{
                                backgroundColor: "white",
                                color: "black",
                                paddingLeft: "5px",
                                paddingRight: "5px",
                                paddingTop: "5px",
                                width: "300px",
                              }}
                            >
                              <b>NDB Screen Name/Mapping (</b>Category-Area-F Key<b>):</b>  MAIN (M-Z)<br /><br />

                      The date the MPIN was first created/system generated.




                      </div>
                          }
                        >
                          {
                            <span>  Create Date:{" "}</span>


                          }
                        </Tooltip>

                        <span
                          style={{
                            paddingLeft: "51px",
                            fontWeight: "500",
                            color:
                              new Date(state.Deactivation_Date).getTime() >=
                                new Date().getTime()
                                ? "black"
                                : "#58cde8",
                          }}
                        >
                          {changeDateFormat(state.Create_Date)}
                        </span>
                      </Typography>
                      <Typography
                        variant="body1"
                        component="span"
                        className={classes.inputText}
                      >
                        <Tooltip
                          classes={{ tooltip: classes.customWidth }}
                          title={
                            <div
                              style={{
                                backgroundColor: "white",
                                color: "black",
                                paddingLeft: "5px",
                                paddingRight: "5px",
                                paddingTop: "5px",
                                width: "300px",
                              }}
                            >
                              <b>NDB Screen Name/Mapping (</b>Category-Area-F Key<b>):</b>  MAIN (M-Z)<br /><br />



                      The MPIN's deactivation date is leveraged to discontinue use of MPIN. If the MPIN is active the deactivation date field will be populated with 12/31/9999 on most current timelined data.




                      </div>
                          }
                        >
                          {
                            <span>    Deactivation Date:{" "}</span>


                          }
                        </Tooltip>

                        <span
                          style={{
                            paddingLeft: "13px",
                            fontWeight: "500",
                            color:
                              new Date(state.Deactivation_Date).getTime() >=
                                new Date().getTime()
                                ? "black"
                                : "#58cde8",
                          }}
                        >
                          {changeDateFormat(state.Deactivation_Date)}
                        </span>
                      </Typography>
                      <Typography
                        variant="body1"
                        component="span"
                        className={classes.inputText}
                      >
                        <Tooltip
                          classes={{ tooltip: classes.customWidth }}
                          title={
                            <div
                              style={{
                                backgroundColor: "white",
                                color: "black",
                                paddingLeft: "5px",
                                paddingRight: "5px",
                                paddingTop: "5px",
                                width: "300px",
                              }}
                            >

                              <b> NDB Screen Name/Mapping (</b>Category-Area-F Key<b>):</b>  MAIN (M-Z)<br /><br />

                      The MPIN's Claims Run Out Date provides a limit for claims processing.  User may leverage system default or key up to 10 years in the future.



                      </div>
                          }
                        >
                          {
                            <span>    Claim Run Out Date:{" "}</span>


                          }
                        </Tooltip>


                        <span
                          style={{
                            paddingLeft: "0px",
                            fontWeight: "500",
                            color:
                              new Date(state.Deactivation_Date).getTime() >=
                                new Date().getTime()
                                ? "black"
                                : "#58cde8",
                          }}
                        >
                          {changeDateFormat(state.Claim_Run_Out_Date)}
                        </span>
                      </Typography>
                      <Typography
                        variant="body1"
                        component="span"
                        className={classes.inputText}
                        style={{ display: "flex" }}
                      >

                        <Tooltip
                          classes={{ tooltip: classes.customWidth }}
                          title={
                            <div
                              style={{
                                backgroundColor: "white",
                                color: "black",
                                paddingLeft: "5px",
                                paddingRight: "5px",
                                paddingTop: "5px",
                                width: "300px",
                              }}
                            >

                              <b> NDB Screen Name/Mapping (</b>Category-Area-F Key<b>):</b>  MAIN (M-Z)<br /><br />

                     The MPIN's deactivation reason code is leveraged to identify purpose of discontinued use of MPIN.


                      </div>
                          }
                        >
                          {
                            <span>            Deactivate Reason:{" "}</span>


                          }
                        </Tooltip>

                        <span
                          style={{
                            paddingLeft: "10px",
                            maxWidth: "52%",
                            fontWeight: "500",
                            color:
                              new Date(state.Deactivation_Date).getTime() >=
                                new Date().getTime()
                                ? "black"
                                : "#58cde8",
                          }}
                        >
                          <EllipsisToolTip
                            options={Options}
                            style={{ width: "245px" }}
                          >
                            {state.Deactivate_Reason}&nbsp;{""}
                          </EllipsisToolTip>
                        </span>
                      </Typography>
                      <Typography
                        variant="body1"
                        component="span"
                        className={classes.inputText}
                      >

                        <Tooltip
                          classes={{ tooltip: classes.customWidth }}
                          title={
                            <div
                              style={{
                                backgroundColor: "white",
                                color: "black",
                                paddingLeft: "5px",
                                paddingRight: "5px",
                                paddingTop: "5px",
                                width: "300px",
                              }}
                            >

                              <b> NDB Screen Name/Mapping (</b>Category-Area-F Key<b>):</b>  MAIN (M-Z)<br /><br />


                     This field identifies MPIN that has been linked as a duplicate.  Old MPIN desginates deactivated MPIN and New MPIN designates appropriate active MPIN.
                     <br /><br />
                              <b>NOTE:</b>  PSM (Provider System Management Intake) intake required to change this field.

                      </div>
                          }
                        >
                          {
                            <span>   Old/New MPIN:{" "}</span>


                          }
                        </Tooltip>

                        <Tooltip
                          title={
                            <div
                              style={{
                                display:
                                  state.Old_New_MPIN !== "" &&
                                    state.Old_New_MPIN !== undefined
                                    ? ""
                                    : "none",
                                backgroundColor: "white",
                                color: "black",
                                paddingLeft: "5px",
                                paddingRight: "5px",
                                paddingTop: "3px",
                                paddingBottom: "3px",
                              }}
                            >
                              <table border="0" cellSpacing="0" cellPadding="0">
                                <tbody>
                                  <tr>
                                    <td>
                                      {state.Old_New_fst_nm !== "" &&
                                        state.Old_New_fst_nm !== undefined
                                        ? state.Old_New_fst_nm
                                        : ""}
                                      {state.Old_New_mdl_nm !== "" &&
                                        state.Old_New_mdl_nm !== undefined
                                        ? " " + state.Old_New_mdl_nm
                                        : ""}
                                      {state.Old_New_lst_nm !== "" &&
                                        state.Old_New_lst_nm !== undefined
                                        ? " " + state.Old_New_lst_nm
                                        : ""}
                                      {state.Old_New_nm_sufx_cd !== "" &&
                                        state.Old_New_nm_sufx_cd !== undefined
                                        ? " " + state.Old_New_nm_sufx_cd
                                        : ""}
                                      {state.Old_New_deg_cd !== "" &&
                                        state.Old_New_deg_cd !== undefined
                                        ? ", " + state.Old_New_deg_cd
                                        : ""}
                                    </td>
                                  </tr>
                                </tbody>
                              </table>
                            </div>
                          }
                        >
                          {
                            <b
                              style={{
                                paddingLeft: "38px",
                                display:
                                  state.Old_New_fst_nm == "" &&
                                    state.Old_New_fst_nm == undefined &&
                                    state.Old_New_mdl_nm == "" &&
                                    state.Old_New_mdl_nm == undefined &&
                                    state.Old_New_lst_nm == "" &&
                                    state.Old_New_lst_nm == undefined
                                    ? "none"
                                    : "",
                              }}
                              className={classes.inputText2}
                            >
                              {state.Old_New_MPIN}
                            </b>
                          }
                        </Tooltip>
                      </Typography>
                    </div>
                  </Grid>
                  {/* <div className={classes.line}></div> */}
                  <Grid item xs={4}>
                    <div
                      style={{
                        height: state.Hold_section.length < 2 ? "85px" : "",
                        borderRight: "1px solid black",
                      }}
                    >
                      <Typography
                        variant="body1"
                        component="span"
                        className={classes.inputText}
                      >



                        <Tooltip
                          classes={{ tooltip: classes.customWidth }}
                          title={
                            <div
                              style={{
                                backgroundColor: "white",
                                color: "black",
                                paddingLeft: "5px",
                                paddingRight: "5px",
                                paddingTop: "5px",
                                width: "300px",
                              }}
                            >

                              <b> NDB Screen Name/Mapping (</b>Category-Area-F Key<b>):</b>  MAIN (M-Z)<br /><br />



Hold indicator identifies restrictions for provider demographic or contract maintenance and/or claims processing.  Health Plan or Fraud & Abuse teams are usually the departments that request hold code maintenance.  Hold reasons include (but are not limited to) provider sanactions, license restrictions, or suspected fraud and abuse cases.

                      </div>
                          }
                        >
                          {
                            <span>  Hold Cd:{" "}</span>


                          }
                        </Tooltip>
                      </Typography>
                      <Typography
                        variant="body1"
                        component="span"
                        className={classes.inputText}
                        style={{ paddingLeft: "60px" }}
                      >
                        <Tooltip
                          classes={{ tooltip: classes.customWidth }}
                          title={
                            <div
                              style={{
                                backgroundColor: "white",
                                color: "black",
                                paddingLeft: "5px",
                                paddingRight: "5px",
                                paddingTop: "5px",
                                width: "300px",
                              }}
                            >



                              <b> NDB Screen Name/Mapping (</b>Category-Area-F Key<b>):</b>  FRAUD/ABUSE/SANC. CODES (D-F, V)<br /><br />

                     NDB Hold Code description.
                      </div>
                          }
                        >
                          {
                            <span>      Description:{" "}</span>


                          }
                        </Tooltip>

                      </Typography>
                      <Typography
                        variant="body1"
                        component="span"
                        className={classes.inputText}
                        style={{ paddingLeft: "60px" }}
                      >
                        <Tooltip
                          classes={{ tooltip: classes.customWidth }}
                          title={
                            <div
                              style={{
                                backgroundColor: "white",
                                color: "black",
                                paddingLeft: "5px",
                                paddingRight: "5px",
                                paddingTop: "5px",
                                width: "300px",
                              }}
                            >

                              <b>The NDB Screen Name/Mapping</b> (Category-Area-F Key):  MAIN (M-Z)<br /><br />

                      date the provider hold is effective on NDB.
                      </div>
                          }
                        >
                          {
                            <span>  Effective DT:{" "}</span>


                          }
                        </Tooltip>

                      </Typography>
                      <Typography
                        variant="body1"
                        component="span"
                        className={classes.inputText}
                        style={{ paddingLeft: "60px" }}
                      >
                        <Tooltip
                          classes={{ tooltip: classes.customWidth }}
                          title={
                            <div
                              style={{
                                backgroundColor: "white",
                                color: "black",
                                paddingLeft: "5px",
                                paddingRight: "5px",
                                paddingTop: "5px",
                                width: "300px",
                              }}
                            >

                              <b>NDB Screen Name/Mapping</b> (Category-Area-F Key):  MAIN (M-Z)<br /><br />

The date the provider hold has been cancelled on NDB.  Open ended 12/31/9999 date is used to identify hold code is active.
                      </div>
                          }
                        >
                          {
                            <span> Cancel DT:{" "}</span>


                          }
                        </Tooltip>

                      </Typography>
                      <div className={classes.line2}></div>
                      {state.Hold_section.map((holdObj) => (
                        <div>
                          <Typography
                            variant="body1"
                            component="span"
                            className={classes.inputText}
                          >
                            <span
                              className={classes.mpinInputText}
                              style={{
                                paddingLeft: "1px",
                                color:
                                  new Date(holdObj.hold_canc_dt).getTime() >=
                                    new Date().getTime()
                                    ? "black"
                                    : "#58cde8",
                              }}
                            >
                              {holdObj.hold_code}
                            </span>
                          </Typography>
                          <Typography
                            variant="body1"
                            component="span"
                            className={classes.inputText}
                          >
                            <span
                              className={classes.mpinInputText}
                              style={{
                                color:
                                  new Date(holdObj.hold_canc_dt).getTime() >=
                                    new Date().getTime()
                                    ? "black"
                                    : "#58cde8",
                                paddingLeft: "92px",
                              }}
                            >
                              <EllipsisToolTip
                                style={{ width: "129px" }}
                                options={Options}
                              >
                                {" "}
                                {holdObj.hold_description}
                              </EllipsisToolTip>
                            </span>
                          </Typography>
                          <Typography
                            variant="body1"
                            component="span"
                            className={classes.inputText}
                          >
                            <span
                              className={classes.mpinInputText}
                              style={{
                                color:
                                  new Date(holdObj.hold_canc_dt).getTime() >=
                                    new Date().getTime()
                                    ? "black"
                                    : "#58cde8",
                                paddingLeft: "11px",
                              }}
                            >
                              {changeDateFormat(holdObj.hold_eff_dt)}
                            </span>
                          </Typography>
                          <Typography
                            variant="body1"
                            component="span"
                            className={classes.inputText}
                          >
                            <span
                              className={classes.mpinInputText}
                              style={{
                                color:
                                  new Date(holdObj.hold_canc_dt).getTime() >=
                                    new Date().getTime()
                                    ? "black"
                                    : "#58cde8",
                                paddingLeft: "71px",
                              }}
                            >
                              {changeDateFormat(holdObj.hold_canc_dt)}
                            </span>
                          </Typography>
                        </div>
                      ))}
                      <Typography
                        variant="body1"
                        component="span"
                        className={classes.inputText}
                      >
                        <span className={classes.mpinInputText}></span>
                      </Typography>
                      <Typography
                        variant="body1"
                        component="span"
                        className={classes.inputText}
                      >
                        <span className={classes.mpinInputText}></span>
                      </Typography>
                      {/* <Typography variant="body1" component="span" className={classes.inputText}>
          <Tooltip title="User Restrictions DESCRIPTION" arrow>
            <span>User Restrictions:</span>
          </Tooltip> <span className={classes.mpinInputText}>D,O,T</span>
        </Typography><br /> */}
                      <Typography
                        variant="body1"
                        component="span"
                        className={classes.inputText}
                      >
                        <Tooltip
                          title={
                            <div
                              style={{
                                backgroundColor: "white",
                                color: "black",

                                width: "290px",
                                paddingLeft: "3px",
                                paddingRight: "5px",
                                paddingTop: "5px",
                              }}
                            >
                              <b>NDB Screen Name/Mapping</b> <b>(</b>
                            Category-Area-F Key<b>):</b> SANCTIONS (S-C)
                            <br />
                              <br />
                            Credentialing criminal review indicator identifies
                            that status of sanction review:
                            <br />
                              <br />
                              <b>P-</b> PASS
                            <br />
                              <b>F-</b> FAIL
                            <br />
                              <b>E-</b> EXCLUDE
                            <br />- IN PROGRESS (for blank value)
                          </div>
                          }
                        >
                          {

                            <b className={classes.inputText2}>
                              <b> Cred Crim Review:</b>{" "}
                            </b>


                          }
                        </Tooltip>
                        <span
                          style={{
                            fontWeight: "500",
                            color:
                              new Date(state.Deactivation_Date).getTime() >=
                                new Date().getTime()
                                ? "black"
                                : "#58cde8",
                          }}
                          className={classes.mpinInputText}
                        >
                          {state.Criminal_Review}
                        </span>
                      </Typography>
                      <Typography
                        variant="body1"
                        component="span"
                        className={classes.inputText}
                      >
                        <span
                          style={{
                            marginLeft:
                              state.Criminal_Review !== "" ? "122px" : "128px",
                          }}
                        >
                          <Tooltip
                            classes={{ tooltip: classes.customWidth }}
                            title={
                              <div
                                style={{
                                  backgroundColor: "white",
                                  color: "black",
                                  paddingLeft: "5px",
                                  paddingRight: "5px",
                                  paddingTop: "5px",
                                  width: "300px",
                                }}
                              >

                                <b>NDB Screen Name/Mapping (</b>Category-Area-F Key<b>):</b>  SANCTIONS (S-C)<br /><br />

                        Sanction identification number.                         </div>
                            }
                          >
                            {
                              <span style={{ marginLeft: state.Criminal_Review !== "" ? "8px" : "8px" }}>Sanction ID: </span>


                            }
                          </Tooltip>

                        </span>
                        <span
                          style={{
                            fontWeight: "500",
                            color:
                              new Date(state.Deactivation_Date).getTime() >=
                                new Date().getTime()
                                ? "black"
                                : "#58cde8",
                          }}
                          className={classes.mpinInputText}
                        >
                          {state.Sanction_ID}
                        </span>
                      </Typography>
                    </div>
                  </Grid>
                  <Grid item xs={2} style={{ paddingLeft: "20px" }}>
                    <div style={{ display: "grid" }}>
                      <Typography
                        variant="body1"
                        component="span"
                        className={classes.inputText}
                      >
                        Demo/Contract Status:
                    </Typography>
                      <div
                        className={classes.line3}
                        style={{ marginBottom: 10 }}
                      ></div>
                      <Typography
                        variant="body1"
                        component="span"
                        className={classes.inputText}
                      >
                        <Tooltip
                          classes={{ tooltip: classes.customWidth_mpin }}
                          title={
                            <div
                              style={{
                                backgroundColor: "white",
                                color: "black",

                                width: "325px",
                                paddingLeft: "5px",
                                paddingRight: "5px",
                                paddingTop: "5px",
                              }}
                            >
                              <b>NDB Screen Name/Mapping</b> (Category-Area-F
                            Key): MAIN (M-Z) CONTRACT (E-Z)
                            <br />
                              <b>
                                MPIN Status Field identifies whether or not select
                                MPIN has (core) NDB Demographic/Contract details
                                on the following NDB Screens:
                            </b>
                              <br />
                              <b>(M):</b> Demographic Status
                            <br />
                              <b>(E):</b> Contract Status
                            <br />
                              <b>Valid values include:</b>
                              <br />
                              <b>A:</b> Active
                            <br />
                              <b>I:</b> Inactive
                            <br />
                              <b>N:</b> N/A (No active/termed data exists)
                            <br />
                              <b>NOTE:</b> Active is defined as Cancel
                            Date≥Today’s Date <b>and</b> Cancel Date ≠Effective
                            Date.
                          </div>
                          }
                        >
                          {
                            <b className={classes.inputText2}>
                              <b> MPIN (M/E):</b>{" "}
                            </b>
                          }
                        </Tooltip>
                        <span
                          className={classes.inputText2}
                          style={{ paddingLeft: "11px" }}
                        >
                          <span
                            style={{
                              color:
                                state.demoMPIN_M_E == "A" ? "black" : "#58cde8",
                            }}
                          >
                            {state.demoMPIN_M_E}
                          </span>
                        /
                        <span
                            style={{
                              color:
                                state.contractMPIN_M_E == "A"
                                  ? "black"
                                  : "#58cde8",
                            }}
                          >
                            {state.contractMPIN_M_E}
                          </span>
                        </span>
                      </Typography>
                      <Typography
                        variant="body1"
                        component="span"
                        className={classes.inputText}
                      >
                        <Tooltip
                          classes={{ tooltip: classes.customWidth_mpin }}
                          title={
                            <div
                              style={{
                                backgroundColor: "white",
                                color: "black",

                                width: "325px",
                                paddingLeft: "3px",
                                paddingRight: "5px",
                                paddingTop: "5px",
                              }}
                            >
                              <b>NDB Screen Name/Mapping</b> (Category-Area-F
                            Key): BSAR Demographic (7-Z) BSAR Contract (4-Z)
                            <br />
                              <b>
                                BSAR Status Field identifies whether or not select
                                MPIN has CSP Demographic/Contract details on the
                                following NDB Screens:
                            </b>
                              <br />
                              <b>(7):</b> Demographic Status
                            <br />
                              <b>(4):</b> Contract Status
                            <br />
                              <b>Valid values include:</b>
                              <br />
                              <b>A:</b> Active <br />
                              <b>I:</b> Inactive <br />
                              <b>N:</b> N/A (No active/termed data exists)
                            <br />
                              <b>NOTE:</b> Active is defined as Cancel
                            Date≥Today’s Date <b>and</b> Cancel Date ≠Effective
                            Date.
                          </div>
                          }
                        >
                          {
                            <b className={classes.inputText2}>
                              <b> BSAR (7/4):</b>{" "}
                            </b>
                          }
                        </Tooltip>
                        <span
                          className={classes.inputText2}
                          style={{ paddingLeft: "11px" }}
                        >
                          <span
                            style={{
                              color: state.demoBSAR == "A" ? "black" : "#58cde8",
                            }}
                          >
                            {state.demoBSAR}
                          </span>
                        /
                        <span
                            style={{
                              color:
                                state.contractBSAR == "A" ? "black" : "#58cde8",
                            }}
                          >
                            {state.contractBSAR}
                          </span>
                        </span>
                      </Typography>
                      <Typography
                        variant="body1"
                        component="span"
                        className={classes.inputText}
                      >
                        <Tooltip
                          classes={{ tooltip: classes.customWidth_mpin }}
                          title={
                            <div
                              style={{
                                backgroundColor: "white",
                                color: "black",

                                width: "325px",
                                paddingLeft: "3px",
                                paddingRight: "5px",
                                paddingTop: "5px",
                              }}
                            >
                              <b>NDB Screen Name/Mapping</b> (Category-Area-F
                            Key): UHCID Demographic (U-Z) UHCID Contract (W-Z)
                            <br />
                              <b>
                                UHCID Status Field identifies whether or not
                                select MPIN has COSMOS Demographic/Contract
                                details on the following NDB Screens:
                            </b>
                              <br />
                              <b>(U):</b> Demographic Status
                            <br />
                              <b>(W):</b> Contract Status
                            <br />
                              <b>Valid values include:</b>
                              <br />
                              <b>A:</b> Active <br />
                              <b>I:</b> Inactive <br />
                              <b>N:</b> N/A (No active/termed data exists)
                            <br />
                              <b>NOTE:</b> Active is defined as Cancel
                            Date≥Today’s Date <b>and</b> Cancel Date ≠Effective
                            Date.
                          </div>
                          }
                        >
                          {
                            <b className={classes.inputText2}>
                              <b> UHCID (U/W):</b>{" "}
                            </b>
                          }
                        </Tooltip>
                        <span className={classes.inputText2}>
                          <span
                            style={{
                              color: state.demoUHCID == "A" ? "black" : "#58cde8",
                            }}
                          >
                            {state.demoUHCID}
                          </span>
                        /
                        <span
                            style={{
                              color:
                                state.contractUHCID == "A" ? "black" : "#58cde8",
                            }}
                          >
                            {state.contractUHCID}
                          </span>
                        </span>
                      </Typography>
                    </div>
                  </Grid>
                </Grid>
              </div>
            ) : (
                ""
              )}
            {pType === "p" ? (
              <div className={classes.nameRoot}>
                <Grid container spacing={1}>
                  <Grid item xs={2}>
                    <Typography className={classes.lastNameHeader}>
                      <Tooltip
                        classes={{ tooltip: classes.customWidth }}
                        title={
                          <div
                            style={{
                              backgroundColor: "white",
                              color: "black",
                              paddingLeft: "5px",
                              paddingRight: "5px",
                              paddingTop: "5px",
                              width: "300px",
                            }}
                          >

                            <b>NDB Screen Name/Mapping</b> (Category-Area-F Key): MAIN (M-Z)<br /><br />


Last/Group Name field stores credentialed and/or licensed Last Name of
(P)ractitioner type MPIN's and Group/Facility Name of (O)rganization type MPIN's.
<br /><br />
                            <b>NOTE:</b>  If no alternate name exists, this name will also apply for claims and directory.



                    </div>
                        }
                      >
                        {
                          <span> Last</span>


                        }
                      </Tooltip>

                    </Typography>
                  </Grid>
                  <Grid item xs={3}>
                    <Typography
                      style={{ marginLeft: "170px" }}
                      className={classes.nameHeader}
                    >
                      <Tooltip
                        classes={{ tooltip: classes.customWidth }}
                        title={
                          <div
                            style={{
                              backgroundColor: "white",
                              color: "black",
                              paddingLeft: "5px",
                              paddingRight: "5px",
                              paddingTop: "5px",
                              width: "300px",
                            }}
                          >

                            <b>NDB Screen Name/Mapping</b> (Category-Area-F Key): PHYS - MAIN (M-Z)<br /><br />


Practitioner/Physician licensed and/or credentialed First Name.
<br /><br />
                            <b>NOTE:</b>  If no alternate name exists, this name will also apply for claims and directory.


                    </div>
                        }
                      >
                        {
                          <span>First</span>


                        }
                      </Tooltip>

                    </Typography>
                  </Grid>
                  <Grid item xs={3}>
                    <Typography
                      style={{ marginLeft: "158px" }}
                      className={classes.nameHeader}
                    >
                      <Tooltip
                        classes={{ tooltip: classes.customWidth }}
                        title={
                          <div
                            style={{
                              backgroundColor: "white",
                              color: "black",
                              paddingLeft: "5px",
                              paddingRight: "5px",
                              paddingTop: "5px",
                              width: "300px",
                            }}
                          >

                            <b>NDB Screen Name/Mapping</b> (Category-Area-F Key): PHYS - MAIN (M-Z)<br /><br />
                    NDB Screen Name/Mapping (Category-Area-F Key):

Practitioner/Physician licensed and/or credentialed Middle Name.
<br /><br />
                            <b>NOTE:</b>  If no alternate name exists, this name will also apply for claims and directory.





                    </div>
                        }
                      >
                        {
                          <span>Middle</span>


                        }
                      </Tooltip>

                    </Typography>
                  </Grid>
                  <Grid item xs={2}>
                    <Typography
                      style={{ marginLeft: "101px" }}
                      className={classes.nameHeader}
                    >
                      <Tooltip
                        classes={{ tooltip: classes.customWidth }}
                        title={
                          <div
                            style={{
                              backgroundColor: "white",
                              color: "black",
                              paddingLeft: "5px",
                              paddingRight: "5px",
                              paddingTop: "5px",
                              width: "300px",
                            }}
                          >

                            <b>NDB Screen Name/Mapping</b> (Category-Area-F Key):   ALTERNATE NAME (M-Z-F9)<br /><br />


Alternate Name Suffix used by the practitioner which differs from the practioner's licensed name.  This can include nicknames or abbreviations that a practitioner might use on claims or prefer to appear in directories.


                    </div>
                        }
                      >
                        {
                          <span>Suffix</span>


                        }
                      </Tooltip>

                    </Typography>
                  </Grid>
                  <Grid item xs={1}>
                    <div style={{ display: state.NameSection ? "" : "none" }}>
                      <Typography
                        style={{ marginLeft: "25px" }}
                        className={classes.nameHeader}
                      >
                        <Tooltip
                          classes={{ tooltip: classes.customWidth }}
                          title={
                            <div
                              style={{
                                backgroundColor: "white",
                                color: "black",
                                paddingLeft: "5px",
                                paddingRight: "5px",
                                paddingTop: "5px",
                                width: "300px",
                              }}
                            >

                              <b>NDB Screen Name/Mapping</b> (Category-Area-F Key):  ALTERNATE NAME (M-Z-F9)<br /><br />


Alternate Name Type indicates what alternate name is used for:<br />

                              <b>B:</b> Claims Name and Directory Name<br />
                              <b>C:</b> Claims Submission Name<br />
                              <b>D:</b> Directory Name<br />
                              <b>L:</b> License Name<br />
                              <b>M:</b> License and Claims Name<br />
                              <b>N:</b> NPI Name<br />
                              <b>P:</b> Pacificare/NICE Name<br />
                              <b>S:</b> Consumer Standardization Name<br />
                              <b>T:</b> National System<br />
                              <b>Y:</b> License Name and Directory Name<br />


                            </div>
                          }
                        >
                          {
                            <span>  Alt N Type</span>


                          }
                        </Tooltip>

                      </Typography>
                    </div>
                  </Grid>
                  <Grid item xs={1}>
                    <div style={{ display: state.NameSection ? "" : "none" }}>
                      <Typography
                        style={{ marginLeft: "34px" }}
                        className={classes.nameHeader}
                      >

                        <Tooltip
                          classes={{ tooltip: classes.customWidth }}
                          title={
                            <div
                              style={{
                                backgroundColor: "white",
                                color: "black",
                                paddingLeft: "5px",
                                paddingRight: "5px",
                                paddingTop: "5px",
                                width: "300px",
                              }}
                            >

                              <b>NDB Screen Name/Mapping</b> (Category-Area-F Key):  ALTERNATE NAME (M-Z-F9)<br /><br />


The ACT Code designates if the Alt Name is (A)ctive or (I)nactive.



                        </div>
                          }
                        >
                          {
                            <span>Act Cd</span>


                          }
                        </Tooltip>
                      </Typography>
                    </div>
                  </Grid>
                </Grid>
                <Grid container spacing={1}>
                  <Grid item xs={2}>
                    <Typography
                      style={{ width: "340px" }}
                      className={classes.nameDataCoHeader}
                    >
                      <div style={{ display: "flex" }}>
                        <div style={{ width: "120px" }}>Name:</div>
                        <div
                          style={{
                            paddingLeft: "0px",
                            width: "200px",
                            fontSize: "12px",
                            color:
                              new Date(state.Deactivation_Date).getTime() >=
                                new Date().getTime()
                                ? "black"
                                : "#58cde8",
                          }}
                          className={classes.nameData}
                        >
                          {state.providerprofileinforsingle_name.lst_nm}
                        </div>
                      </div>
                      {/* Name:
                    <span>
                      {state.providerprofileinforsingle_name.lst_nm}
                    </span>{" "} */}
                    </Typography>
                  </Grid>
                  <Grid item xs={3}>
                    <Typography
                      style={{
                        fontSize: "12px",
                        fontWeight: "460",
                        paddingLeft: "168px",
                        color:
                          new Date(state.Deactivation_Date).getTime() >=
                            new Date().getTime()
                            ? "black"
                            : "#58cde8",
                      }}
                    >
                      {state.providerprofileinforsingle_name.fst_nm}
                    </Typography>
                  </Grid>
                  <Grid item xs={3}>
                    <Typography
                      style={{
                        fontSize: "12px",
                        fontWeight: "460",
                        paddingLeft: "158px",
                        color:
                          new Date(state.Deactivation_Date).getTime() >=
                            new Date().getTime()
                            ? "black"
                            : "#58cde8",
                      }}
                    >
                      {state.providerprofileinforsingle_name.mdl_nm}
                    </Typography>
                  </Grid>
                  <Grid item xs={2}>
                    <Typography
                      style={{
                        fontSize: "12px",
                        fontWeight: "460",
                        paddingLeft: "103px",
                        color:
                          new Date(state.Deactivation_Date).getTime() >=
                            new Date().getTime()
                            ? "black"
                            : "#58cde8",
                      }}
                    >
                      {state.providerprofileinforsingle_name.nm_sufx_cd}
                    </Typography>
                  </Grid>
                  <Grid item xs={1}>
                    <div>
                      <Typography
                        style={{
                          fontSize: "12px",
                          color: "black",
                          fontWeight: "460",
                          paddingLeft: "24px",
                        }}
                      >
                        {state.providerprofileinforsingle_name.alt_nm_typ_cd !==
                          undefined
                          ? state.providerprofileinforsingle_name.alt_nm_typ_cd
                          : ""}
                      </Typography>
                    </div>
                  </Grid>
                  <Grid item xs={1}>
                    <div>
                      <Typography
                        style={{
                          fontSize: "12px",
                          color: "black",
                          fontWeight: "460",
                          paddingLeft: "34px",
                        }}
                      >
                        {state.providerprofileinforsingle_name.alt_actv_cd !==
                          undefined
                          ? state.providerprofileinforsingle_name.alt_actv_cd
                          : ""}
                      </Typography>
                    </div>
                  </Grid>
                </Grid>
                {state.NameSection ? (
                  <Grid container spacing={1}>
                    <Grid item xs={1}>
                      <Typography className={classes.altNameDataCoHeader}>
                        Alt Name:
                    </Typography>
                    </Grid>
                    <Grid item xs={11}>
                      <div
                        className={
                          isArrow
                            ? classes.tableContainerMax
                            : classes.tableContainer
                        }
                      >
                        <table
                          style={{
                            tableLayout: "fixed",
                            width:
                              state.Name_section.length < 3 ||
                                (isArrow && state.Name_section.length <= 15)
                                ? "99%"
                                : "100%",
                            fontSize: "12px",
                            border: "0px solid black",
                          }}
                          className='table'
                        >
                          <tbody>
                            {state.Name_section.map((empObj) => (
                              <tr>
                                <td
                                  className={classes.altLastNameData}
                                  style={{
                                    paddingLeft: "5px",
                                    width: "19%",
                                    color:
                                      empObj.alt_actv_cd == "A"
                                        ? "black"
                                        : "#58cde8",
                                    border: "0px solid black",
                                  }}
                                >
                                  {empObj.alt_lst_nm}
                                </td>
                                <td
                                  className={classes.altFirstNameData}
                                  style={{
                                    paddingLeft: "10px",
                                    width: "24%",
                                    color:
                                      empObj.alt_actv_cd == "A"
                                        ? "black"
                                        : "#58cde8",
                                    border: "0px solid black",
                                  }}
                                >
                                  <span>{empObj.alt_fst_nm}</span>{" "}
                                </td>
                                <td
                                  className={classes.altMiddleNameData}
                                  style={{
                                    paddingLeft: "22px",
                                    width: "21%",
                                    color:
                                      empObj.alt_actv_cd == "A"
                                        ? "black"
                                        : "#58cde8",
                                    border: "0px solid black",
                                  }}
                                >
                                  <span>{empObj.alt_mdl_nm}</span>{" "}
                                </td>
                                <td
                                  style={{
                                    paddingLeft: "28px",
                                    width: "13%",
                                    color:
                                      empObj.alt_actv_cd == "A"
                                        ? "black"
                                        : "#58cde8",
                                    border: "0px solid black",
                                  }}
                                  className={classes.altNameData}
                                >
                                  &nbsp;&nbsp;
                                <span>{empObj.alt_nm_sufx_cd}</span>
                                </td>
                                <td
                                  style={{
                                    paddingLeft: "18px",
                                    width: "9%",
                                    color:
                                      empObj.alt_actv_cd == "A"
                                        ? "black"
                                        : "#58cde8",
                                    border: "0px solid black",
                                    display: !state.NameSection ? "none" : "",
                                  }}
                                  className={classes.altTypeNameData}
                                >
                                  <span>
                                    {empObj.alt_nm_typ_cd !== "undefined"
                                      ? empObj.alt_nm_typ_cd
                                      : ""}
                                  </span>
                                </td>
                                <td
                                  style={{
                                    paddingLeft: "19px",
                                    width: "6%",
                                    color:
                                      empObj.alt_actv_cd == "A"
                                        ? "black"
                                        : "#58cde8",
                                    border: "0px solid black",
                                    display: !state.NameSection ? "none" : "",
                                  }}
                                  className={classes.altActiveNameData}
                                >
                                  {empObj.alt_actv_cd !== undefined
                                    ? empObj.alt_actv_cd
                                    : ""}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </Grid>
                  </Grid>
                ) : (
                    ""
                  )}
              </div>
            ) : pType === "o" ? (
              <div className={classes.nameRoot}>
                <Grid container spacing={1}>
                  <Grid item xs={4}>
                    <Typography className={classes.lastNameHeader}></Typography>
                  </Grid>

                  <Grid item xs={2}>
                    <Typography className={classes.nameHeader}>
                    <Tooltip
                    classes={{ tooltip: classes.customWidth }}
                    title={
                      <div
                        style={{
                          backgroundColor: "white",
                          color: "black",
                          paddingLeft: "5px",
                          paddingRight: "5px",
                          paddingTop: "5px",
                          width: "300px",
                        }}
                      >
                      
                      <b>NDB Screen Name/Mapping</b> (Category-Area-F Key):  ALTERNATE NAME (M-Z-F9)<br/><br/>
                      
                   
  
                      Identifies if Organization Alternate Name Level applies to the entire <b>M</b>PIN, <b>T</b>ax ID, <b>A</b>ddress.  <b>P</b>ractitioner Alternate Names always applies to the entire MPIN.
  
  
  
                      </div>
                    }
                  >
                    {
                     <span>Level</span>
                    
                      
                    }
                  </Tooltip>
                    </Typography>
                  </Grid>

                  <Grid item xs={2}>
                    <Typography className={classes.nameHeader}>
                    
                    <Tooltip
                    classes={{ tooltip: classes.customWidth }}
                    title={
                      <div
                        style={{
                          backgroundColor: "white",
                          color: "black",
                          paddingLeft: "5px",
                          paddingRight: "5px",
                          paddingTop: "5px",
                          width: "300px",
                        }}
                      >
                      
                      <b>NDB Screen Name/Mapping</b> (Category-Area-F Key):  ALTERNATE NAME (M-Z-F9)<br/><br/>
                  
                      Populated when Organization Alternate Name Level applies to a specific <b>T</b>ax ID and/or <b>A</b>ddress.  
  
  
                      </div>
                    }
                  >
                    {
                     <span>Tax ID / Type</span>
                    
                      
                    }
                  </Tooltip>
                  </Typography>
                  </Grid>

                  <Grid item xs={2}>
                    <Typography className={classes.nameHeader}>
                    <Tooltip
                    classes={{ tooltip: classes.customWidth }}
                    title={
                      <div
                        style={{
                          backgroundColor: "white",
                          color: "black",
                          paddingLeft: "5px",
                          paddingRight: "5px",
                          paddingTop: "5px",
                          width: "300px",
                        }}
                      >
                      
                      <b>NDB Screen Name/Mapping</b> (Category-Area-F Key):  ALTERNATE NAME (M-Z-F9)<br/><br/>
                      
  
                      Populated when Organization Alternate Name Level applies to a specific <b>A</b>ddress-<b>T</b>ax ID combination.  
  
                      </div>
                    }
                  >
                    {
                     <span>MAID / Type</span>
                    
                      
                    }
                  </Tooltip>
                  </Typography>
                  </Grid>

                  <Grid item xs={1}>
                    <div style={{ display: state.NameSection ? "" : "none" }}>
                      <Typography className={classes.nameHeader}>
                      <Tooltip
                      classes={{ tooltip: classes.customWidth }}
                      title={
                        <div
                          style={{
                            backgroundColor: "white",
                            color: "black",
                            paddingLeft: "5px",
                            paddingRight: "5px",
                            paddingTop: "5px",
                            width: "300px",
                          }}
                        >
                        
                        <b>NDB Screen Name/Mapping</b> (Category-Area-F Key):  ALTERNATE NAME (M-Z-F9)<br/><br/>
                        
                      

                        Alternate Name Type indicates what alternate name is used for:<br/>
                        
                        <b>B:</b> Claims Name and Directory Name<br/>
                        <b>C:</b> Claims Submission Name<br/>
                        <b>D:</b> Directory Name<br/>
                        <b>L:</b> License Name<br/>
                        <b>M:</b> License and Claims Name<br/>
                        <b>N:</b> NPI Name<br/>
                        <b>P:</b> Pacificare/NICE Name<br/>
                        <b>S:</b> Consumer Standardization Name<br/>
                        <b>T:</b> National System<br/>
                        <b>Y:</b> License Name and Directory Name<br/>
                        
                        
                        </div>
                      }
                    >
                      {
                       <span>Alt-N Type</span>
                      
                        
                      }
                    </Tooltip>
                    </Typography>
                    </div>
                  </Grid>

                  <Grid item xs={1}>
                    <div style={{ display: state.NameSection ? "" : "none" }}>
                      <Typography className={classes.nameHeader}>
                      <Tooltip
                      classes={{ tooltip: classes.customWidth }}
                      title={
                        <div
                          style={{
                            backgroundColor: "white",
                            color: "black",
                            paddingLeft: "5px",
                            paddingRight: "5px",
                            paddingTop: "5px",
                            width: "300px",
                          }}
                        >
                        
                        <b>NDB Screen Name/Mapping (</b>Category-Area-F Key<b>):</b>  ALTERNATE NAME (M-Z-F9)

                        The ACT Code designates if the Alt Name is (A)ctive or (I)nactive.
                        
                        
                        
                        </div>
                      }
                    >
                      {
                       <span>Act Cd</span>
                      
                        
                      }
                    </Tooltip>
                    </Typography>
                    </div>
                  </Grid>
                </Grid>
                <Grid container spacing={1}>
                  <Grid item xs={4}>
                    <Typography className={classes.nameDataCoHeader}>
                      <div style={{ display: "flex" }}>
                        <div style={{ width: "120px" }}>Name:</div>
                        <div
                          style={{
                            paddingLeft: "0px",
                            width: "345px",
                            fontSize: "12px",
                            color:
                              new Date(state.Deactivation_Date).getTime() >=
                                new Date().getTime()
                                ? "black"
                                : "#58cde8",
                          }}
                          className={classes.nameData}
                        >
                          {state.providerprofileinforsingle_name.lst_nm}
                        </div>
                      </div>
                    </Typography>
                  </Grid>
                  <Grid item xs={1}>
                    <Typography
                      style={{ fontSize: "12px" }}
                      className={classes.nameData}
                    >
                      {""}
                    </Typography>
                  </Grid>
                  <Grid item xs={3}>
                    <Typography
                      className={classes.nameData}
                      style={{ marginLeft: "126px", fontSize: "12px" }}
                    >
                      {""}
                    </Typography>
                  </Grid>
                  <Grid item xs={2}>
                    <Typography className={classes.nameData}>{""}</Typography>
                  </Grid>
                  <Grid item xs={1}>
                    <div style={{ display: state.NameSection ? "" : "none" }}>
                      <Typography
                        style={{ fontSize: "12px" }}
                        className={classes.nameData}
                      >
                        {state.providerprofileinforsingle_name.alt_nm_typ_cd !==
                          undefined
                          ? state.providerprofileinforsingle_name.alt_nm_typ_cd
                          : ""}
                      </Typography>
                    </div>
                  </Grid>
                  <Grid item xs={1}>
                    <div style={{ display: state.NameSection ? "" : "none" }}>
                      <Typography
                        style={{ fontSize: "12px" }}
                        className={classes.nameData}
                      >
                        {state.providerprofileinforsingle_name.alt_actv_cd !==
                          undefined
                          ? state.providerprofileinforsingle_name.alt_actv_cd
                          : ""}
                      </Typography>
                    </div>
                  </Grid>
                </Grid>
                {state.NameSection ? (
                  <Grid container spacing={1}>
                    <Grid item xs={1}>
                      <Typography className={classes.altNameDataCoHeader}>
                        Alt Name:
                    </Typography>
                    </Grid>
                    <Grid item xs={11}>
                      <div
                        className={
                          isArrow
                            ? classes.tableContainerMax
                            : classes.tableContainer
                        }
                      >
                        <table
                          style={{
                            tableLayout: "fixed",
                            width:
                              state.Name_section.length < 3 ||
                                (isArrow && state.Name_section.length <= 15)
                                ? "99%"
                                : "100%",
                            fontSize: "12px",
                            border: "0px solid black",
                          }}
                          className={classes.table}
                        >
                          <tbody>
                            {state.Name_section.map((altInfoObj) => (
                              <tr
                                style={{
                                  color:
                                    altInfoObj.alt_actv_cd == "A"
                                      ? "black"
                                      : "#58cde8",
                                }}
                              >
                                <td
                                  style={{
                                    width: "308px",
                                    paddingLeft: "5px",
                                    border: "0px solid black",
                                  }}
                                >
                                  {/* <div></div> */}
                                  {/* <pre style={{fontSize:'14px'}}>{altInfoObj.alt_lst_nm}</pre> */}
                                  {/* <span>{"rohit singh  suresh    singh"}</span> */}
                                  {altInfoObj.alt_lst_nm}
                                </td>
                                <td
                                  style={{
                                    width: "208px",
                                    border: "0px solid black",
                                  }}
                                >
                                  {altInfoObj.alt_nm_lvl_cd}
                                </td>
                                <td
                                  style={{
                                    width: "193px",
                                    paddingLeft: "2px",
                                    border: "0px solid black",
                                  }}
                                >
                                  {altInfoObj.alt_tax_id_nbr !== "" &&
                                    altInfoObj.alt_tax_id_nbr !== "0"
                                    ? altInfoObj.alt_tax_id_typ_cd +
                                    "- " +
                                    altInfoObj.alt_tax_id_nbr
                                    : ""}
                                </td>
                                <td
                                  style={{
                                    width: "195px",
                                    paddingLeft: "21px",
                                    border: "0px solid black",
                                  }}
                                >
                                  {altInfoObj.alt_adr_id !== "" ||
                                    altInfoObj.alt_adr_id !== undefined
                                    ? prependZerosForMaidType(
                                      altInfoObj.alt_adr_typ_cd,
                                      altInfoObj.alt_adr_id
                                    )
                                    : ""}
                                </td>
                                <td
                                  style={{
                                    width: "137px",
                                    paddingLeft: "39px",
                                    border: "0px solid black",
                                    display: state.NameSection ? "" : "none",
                                  }}
                                >
                                  {altInfoObj.alt_nm_typ_cd}
                                </td>
                                <td
                                  style={{
                                    width: "83px",
                                    paddingLeft: "0px",
                                    border: "0px solid black",
                                    display: state.NameSection ? "" : "none",
                                  }}
                                >
                                  {altInfoObj.alt_actv_cd}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </Grid>
                  </Grid>
                ) : (
                    ""
                  )}
              </div>
            ) : (
                  // <NameSection isArrow={isArrow} dummyData={state.Name_section} Name={state.providerprofileinforsingle_name} isHideNameSection={state.NameSection}></NameSection>
                  ""
                )}
            {state.NameSection && state.Name_section.length > 2 ? (
              <Row style={{ border: "0px solid black" }}>
                <Col
                  style={{ textAlign: "right", border: "0px solid black" }}
                  md={12}
                >
                  <Image
                    onClick={() => setIsArrow(isArrow ? false : true)}
                    style={{
                      backgroundColor: "#f5f2ef",
                      width: "22px",
                      cursor: "pointer",
                    }}
                    src={isArrow ? upArrow : downArrow}
                    thumbnail
                  />
                </Col>
              </Row>
            ) : (
                ""
              )}
            {state.MISCSection ? (
              <Grid container spacing={1}>
                <Grid item xs={5} style={{ paddingLeft: 15 }}>
                  <div style={{ display: "grid" }}>
                    <Typography
                      variant="body1"
                      component="span"
                      className={classes.inputText}
                    >

                      <Tooltip
                        classes={{ tooltip: classes.customWidth }}
                        title={
                          <div
                            style={{
                              backgroundColor: "white",
                              color: "black",
                              paddingLeft: "5px",
                              paddingRight: "5px",
                              paddingTop: "5px",
                              width: "300px",
                            }}
                          >

                            <b>NDB Screen Name/Mapping (</b>Category-Area-F Key<b>):</b>  MAIN (M-Z)

                      Tops Provider Type is auto-populated through the MPIN creation auto-flow.  It is derived from the NDB record type, facility code, specialty code, and degree code fields.  Please refer to the NDB Taxonomy Grid J4056 for more detail.
                      </div>
                        }
                      >
                        {
                          <span> TOPS PROVIDER TYPE:&nbsp;</span>


                        }
                      </Tooltip>

                      <Tooltip
                        title={
                          <div
                            style={{
                              backgroundColor: "white",
                              color: "black",
                              paddingLeft: "5px",
                              paddingRight: "5px",
                              paddingTop: "3px",
                              paddingBottom: "3px",
                            }}
                          >
                            <table border="0" cellSpacing="0" cellPadding="0">
                              <tbody>
                                <tr>
                                  <td
                                    style={{
                                      fontWeight: "500",
                                      color:
                                        new Date(
                                          state.Deactivation_Date
                                        ).getTime() >= new Date().getTime()
                                          ? "black"
                                          : "#58cde8",
                                    }}
                                  >
                                    {state.TOPS_PROVIDER_TYPE_DESCRIPTION}
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                          </div>
                        }
                      >
                        {
                          <b
                            style={{
                              fontWeight: "500",
                              color:
                                new Date(state.Deactivation_Date).getTime() >=
                                  new Date().getTime()
                                  ? "black"
                                  : "#58cde8",
                            }}
                          >
                            {state.TOPS_PROVIDER_TYPE}
                          </b>
                        }
                      </Tooltip>
                    </Typography>
                    <Typography
                      variant="body1"
                      component="span"
                      className={classes.inputText}
                    >
                      <Tooltip
                        classes={{ tooltip: classes.customWidth }}
                        title={
                          <div
                            style={{
                              backgroundColor: "white",
                              color: "black",
                              paddingLeft: "5px",
                              paddingRight: "5px",
                              paddingTop: "5px",
                              width: "300px",
                            }}
                          >

                            <b>NDB Screen Name/Mapping (</b>Category-Area-F Key<b>):</b>  NPI INFORMATION (5-Z)<br /><br />

                    Atypical Provider Y/N indicator identifies whether or not MPIN is a medical provider:
                    <br /><br />
                            <b>Y:</b>   Provider is not a typical medical provider (e.g. wig maker for cancer patient)<br />
                            <b>N:</b> Provider is a medical provider (e.g. pediatrician or urgent care facility)
                    <br /><br />
                    Atypical (non-medical) providers provide a covered service under the member's managed medical benefit plan.
                    </div>
                        }
                      >
                        {
                          <span>ATYPICAL PROVIDER:&nbsp;&nbsp;{" "}</span>


                        }
                      </Tooltip>

                      <span
                        style={{
                          fontWeight: "500",
                          color:
                            new Date(state.Deactivation_Date).getTime() >=
                              new Date().getTime()
                              ? "black"
                              : "#58cde8",
                        }}
                      >
                        &nbsp;{state.ATYPICAL_PROVIDER}
                      </span>
                    </Typography>
                    <Typography
                      variant="body1"
                      component="span"
                      className={classes.inputText}
                    >
                      <Tooltip
                        classes={{ tooltip: classes.customWidth }}
                        title={
                          <div
                            style={{
                              backgroundColor: "white",
                              color: "black",
                              paddingLeft: "5px",
                              paddingRight: "5px",
                              paddingTop: "5px",
                              width: "300px",
                            }}
                          >

                            <b>NDB Screen Name/Mapping (</b>Category-Area-F Key<b>):</b>  MAIN (M-Z)<br /><br />

                    Non-Provider Indicator identifies whether or not MPIN is a medical provider:
                    <br /><br />
                            <b>Y:</b>   Provider is not a typical medical provider (e.g. Bill type MPIN for claims payment 1099 purposes)<br />
                            <b>N:</b>  Provider is a medical provider (e.g. pediatrician or urgent care facility)<br /><br />

                    Unlike Atypical (non-medical) providers, Non-Provider MPIN's do not provide covered service under the member's managed medical benefit plan.
                    </div>
                        }
                      >
                        {
                          <span>  NON-PROVIDER IND:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{" "}</span>


                        }
                      </Tooltip>

                      <span
                        style={{
                          fontWeight: "500",
                          color:
                            new Date(state.Deactivation_Date).getTime() >=
                              new Date().getTime()
                              ? "black"
                              : "#58cde8",
                        }}
                      >
                        {state.NON_PROVIDER_IND}
                      </span>
                    </Typography>
                    <Typography
                      variant="body1"
                      component="span"
                      className={classes.inputText}
                    >
                      <Tooltip
                        classes={{ tooltip: classes.customWidth }}
                        title={
                          <div
                            style={{
                              backgroundColor: "white",
                              color: "black",
                              paddingLeft: "5px",
                              paddingRight: "5px",
                              paddingTop: "5px",
                              width: "300px",
                            }}
                          >

                            <b>NDB Screen Name/Mapping (</b>Category-Area-F Key<b>):</b>  MAIN (M-Z)<br /><br />

                    The HCFA/UB attribute indicates type of claim form(s) provider bills with:<br />
                            <b>H:</b> HCFA<br />
                            <b>U:</b> UB92<br />
                            <b>B:</b> BOTH HCFA & UB92 (TREAT LIKE UB92)     - <br />
                            <b>X:</b> UNKNOWN<br /><br />

                    This restricted field requires NDM Tier 1 contact if update is needed.
                    </div>
                        }
                      >
                        {
                          <span>   HCFA/UB:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{" "}</span>


                        }
                      </Tooltip>

                      <span
                        style={{
                          fontWeight: "500",
                          color:
                            new Date(state.Deactivation_Date).getTime() >=
                              new Date().getTime()
                              ? "black"
                              : "#58cde8",
                        }}
                      >
                        {state.HCFA_UB}
                      </span>
                    </Typography>
                  </div>
                </Grid>
                {pType == "o" ? (
                  <Grid item xs={5} style={{ display: "grid" }}>
                    <Typography
                      variant="body1"
                      component="span"
                      className={classes.inputText}
                    >
                      <Tooltip
                        classes={{ tooltip: classes.customWidth }}
                        title={
                          <div
                            style={{
                              backgroundColor: "white",
                              color: "black",
                              paddingLeft: "5px",
                              paddingRight: "5px",
                              paddingTop: "5px",
                              width: "300px",
                            }}
                          >

                            <b>NDB Screen Name/Mapping</b> (Category-Area-F Key):  GRP/FAC - MAIN (M-Z)<br /><br />


The Group/Facility Type (Org) code indicates the type of healthcare services the provider organization delivers or specializes in (such as Acute Care Hospital or Dialysis Center).  Refer to NDB Taxonomy Grid for more details.


                    </div>
                        }
                      >
                        {
                          <span>  Group/Facility Type:&nbsp;</span>


                        }
                      </Tooltip>

                      <span
                        style={{
                          fontWeight: "500",
                          color:
                            new Date(state.Deactivation_Date).getTime() >=
                              new Date().getTime()
                              ? "black"
                              : "#58cde8",
                        }}
                      >
                        {state.Group_type}
                      </span>
                    </Typography>
                    <Typography
                      variant="body1"
                      component="span"
                      className={classes.inputText}
                      style={{ marginTop: "-24px", display: "flex" }}
                    >
                      <Tooltip
                        classes={{ tooltip: classes.customWidth }}
                        title={
                          <div
                            style={{
                              backgroundColor: "white",
                              color: "black",
                              paddingLeft: "5px",
                              paddingRight: "5px",
                              paddingTop: "5px",
                              width: "300px",
                            }}
                          >

                            <b>NDB Screen Name/Mapping</b> (Category-Area-F Key):  GRP/FAC - MAIN (M-Z)<br /><br />


                    NDB Group/Facility (Org) code description.

                    </div>
                        }
                      >
                        {
                          <span>    Desc:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{" "}</span>


                        }
                      </Tooltip>

                      <span
                        style={{
                          paddingLeft: "2px",
                          fontWeight: "500",
                          maxWidth: "90%",
                          color:
                            new Date(state.Deactivation_Date).getTime() >=
                              new Date().getTime()
                              ? "black"
                              : "#58cde8",
                        }}
                      >
                        <EllipsisToolTip options={Options}>
                          {state.group_facility_description}
                        </EllipsisToolTip>
                      </span>
                    </Typography>
                  </Grid>
                ) : (
                    <Grid item xs={5} style={{ display: "grid" }}>
                      <Typography
                        variant="body1"
                        component="span"
                        className={classes.inputText}
                      >
                        <Tooltip
                          classes={{ tooltip: classes.customWidth }}
                          title={
                            <div
                              style={{
                                backgroundColor: "white",
                                color: "black",
                                paddingLeft: "5px",
                                paddingRight: "5px",
                                paddingTop: "5px",
                                width: "300px",
                              }}
                            >

                              <b> NDB Screen Name/Mapping (</b>Category-Area-F Key<b>):</b>  PHYS - MAIN (M-Z)<br /><br />

Providers Gender code: <br />
                              <b>M:</b> Male<br />
                              <b>F:</b>   Female<br />
                              <b>U:</b> Unknown

                    </div>
                          }
                        >
                          {
                            <span>
                              Gender:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{" "}
                            </span>


                          }
                        </Tooltip>

                        <span
                          style={{
                            fontWeight: "500",
                            color:
                              new Date(state.Deactivation_Date).getTime() >=
                                new Date().getTime()
                                ? "black"
                                : "#58cde8",
                          }}
                        >
                          {state.Gender}
                        </span>
                      </Typography>
                      <Typography
                        variant="body1"
                        component="span"
                        className={classes.inputText}
                      >
                        <Tooltip
                          classes={{ tooltip: classes.customWidth }}
                          title={
                            <div
                              style={{
                                backgroundColor: "white",
                                color: "black",
                                paddingLeft: "5px",
                                paddingRight: "5px",
                                paddingTop: "5px",
                                width: "300px",
                              }}
                            >

                              <b>NDB Screen Name/Mapping</b> (Category-Area-F Key):   PHYS - MAIN (M-Z)<br /><br />


                    The date of the providers birth.

                    </div>
                          }
                        >
                          {
                            <span>
                              Date of
                              Birth:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{" "}
                            </span>
                          }
                        </Tooltip>

                        <span
                          style={{
                            fontWeight: "500",
                            color:
                              new Date(state.Deactivation_Date).getTime() >=
                                new Date().getTime()
                                ? "black"
                                : "#58cde8",
                          }}
                        >
                          {state.Date_of_Birth}
                        </span>
                      </Typography>
                      <Typography
                        variant="body1"
                        component="span"
                        className={classes.inputText}
                      >
                        <Tooltip
                          classes={{ tooltip: classes.customWidth }}
                          title={
                            <div
                              style={{
                                backgroundColor: "white",
                                color: "black",
                                paddingLeft: "5px",
                                paddingRight: "5px",
                                paddingTop: "5px",
                                width: "300px",
                              }}
                            >

                              <b>NDB Screen Name/Mapping</b> (Category-Area-F Key):  PHYS - MAIN (M-Z)<br /><br />



9 digit Tax Identification Number assigned by IRS as an identifier for claims payment.  Provider may also bill their SSN as a TaxID.
<br />
9 digit Social Security Number assigned by IRS as an identifier for personal earnings.  Provider may also submit claims with their SSN as a TaxID.


                    </div>
                          }
                        >
                          {
                            <span>  Social Security Number:&nbsp;&nbsp;&nbsp;</span>


                          }
                        </Tooltip>

                        <span
                          style={{
                            fontWeight: "500",
                            color:
                              new Date(state.Deactivation_Date).getTime() >=
                                new Date().getTime()
                                ? "black"
                                : "#58cde8",
                          }}
                        >
                          {state.Social_Security_Number}
                        </span>
                      </Typography>
                      <Typography
                        variant="body1"
                        component="span"
                        className={classes.inputText}
                      >
                        <Tooltip
                          classes={{ tooltip: classes.customWidth }}
                          title={
                            <div
                              style={{
                                backgroundColor: "white",
                                color: "black",
                                paddingLeft: "5px",
                                paddingRight: "5px",
                                paddingTop: "5px",
                                width: "300px",
                              }}
                            >

                              <b>NDB Screen Name/Mapping</b> (Category-Area-F Key):  MAIN (M-Z)<br /><br />


Reserve/Nationial Guard Indicator identifies if the practitioner is in the Reserve or National Guard.  This indicator does not  apply to group/facility MPIN's.


                    </div>
                          }
                        >
                          {
                            <span>   Reserved/National Guard:&nbsp;</span>


                          }
                        </Tooltip>

                        <span
                          style={{
                            fontWeight: "500",
                            color:
                              new Date(state.Deactivation_Date).getTime() >=
                                new Date().getTime()
                                ? "black"
                                : "#58cde8",
                          }}
                        >
                          {state.Reserved_National_Guard}
                        </span>
                      </Typography>
                    </Grid>
                  )}
                <Grid item xs={2} style={{ display: "grid" }}>
                  <Typography
                    variant="body1"
                    component="span"
                    className={classes.inputText}
                  >
                    <Tooltip
                      classes={{ tooltip: classes.customWidth }}
                      title={
                        <div
                          style={{
                            backgroundColor: "white",
                            color: "black",
                            paddingLeft: "5px",
                            paddingRight: "5px",
                            paddingTop: "5px",
                            width: "300px",
                          }}
                        >

                          <b>NDB Screen Name/Mapping</b> (Category-Area-F Key):  MAIN (M-Z)<br /><br />



                  Ovations feed field will be populated with an 'O' when feed applies and no value (blank) when it does not.
                  </div>
                      }
                    >
                      {
                        <span>    Ovations Feed:</span>
                      }
                    </Tooltip>

                    <span
                      style={{
                        marginLeft: pType == 'p' ? '28px' : '2px',
                        fontWeight: "500",
                        color:
                          new Date(state.Deactivation_Date).getTime() >=
                            new Date().getTime()
                            ? "black"
                            : "#58cde8",
                      }}
                    >
                      {state.Ovations_Feed}
                    </span>
                  </Typography>
                  <div
                    style={{
                      lineHeight: "0",
                      display: pType == "p" ? "block" : "none",
                    }}
                  >
                    <Typography
                      variant="body1"
                      component="span"
                      className={classes.inputText}
                    >
                      <Tooltip
                        classes={{ tooltip: classes.customWidth }}
                        title={
                          <div
                            style={{
                              backgroundColor: "white",
                              color: "black",
                              paddingLeft: "5px",
                              paddingRight: "5px",
                              paddingTop: "5px",
                              width: "300px",
                            }}
                          >

                            <b>NDB Screen Name/Mapping</b> (Category-Area-F Key):   ABMS LINK (A-C)<br /><br />



           American Board of Medical Specialists (ABMS) Control number assigned to an individual biographee in the AMBS Directory Database electronically.  The Bio# can only be retained in NDB by achieving the “link” through PMW and cannot be changed by NDM.

                    </div>
                        }
                      >
                        {
                          <span>     ABMS Bio Number:</span>


                        }
                      </Tooltip>

                      <span
                        style={{
                          marginLeft: pType == 'p' ? '2px' : '1px',
                          fontWeight: "500",
                          color:
                            new Date(state.Deactivation_Date).getTime() >=
                              new Date().getTime()
                              ? "black"
                              : "#58cde8",
                        }}
                      >
                        {state.ABMS_Bio_Number}
                      </span>
                    </Typography>
                  </div>
                  <Typography
                    variant="body1"
                    component="span"
                    className={classes.inputText}
                  >
                    <Tooltip
                      classes={{ tooltip: classes.customWidth }}
                      title={
                        <div
                          style={{
                            backgroundColor: "white",
                            color: "black",
                            paddingLeft: "5px",
                            paddingRight: "5px",
                            paddingTop: "5px",
                            width: "300px",
                          }}
                        >

                          <b>NDB Screen Name/Mapping</b> (Category-Area-F Key):  MAIN (M-Z)<br /><br />


Voice Response Unit (VRU) field is 1 digit systematically assigned number leveraged as a call center flag.


                  </div>
                      }
                    >
                      {
                        <span>
                          VRU:
                 </span>


                      }
                    </Tooltip>

                    <span
                      style={{
                        marginLeft: pType == 'p' ? '91px' : '64px',
                        fontWeight: "500",
                        color:
                          new Date(state.Deactivation_Date).getTime() >=
                            new Date().getTime()
                            ? "black"
                            : "#58cde8",
                      }}
                    >
                      {state.VRU}
                    </span>
                  </Typography>
                  <Typography
                    variant="body1"
                    component="span"
                    className={classes.inputText}
                  >
                    <Tooltip
                      classes={{ tooltip: classes.customWidth }}
                      title={
                        <div
                          style={{
                            backgroundColor: "white",
                            color: "black",
                            paddingLeft: "5px",
                            paddingRight: "5px",
                            paddingTop: "5px",
                            width: "300px",
                          }}
                        >

                          <b>NDB Screen Name/Mapping</b> (Category-Area-F Key):  MAIN (M-Z)<br /><br />


The Universal Provider Identification (UPIN) is a unique alpha-numeric identifier assigned to individual  physicians and allied health professionals that participate in the Federal Medicare Program.  UPIN  is used to comply with medicare claim filing.


                  </div>
                      }
                    >
                      {
                        <span>
                          UPIN:
                 </span>


                      }
                    </Tooltip>

                    <span
                      style={{
                        marginLeft: pType == 'p' ? '87px' : '60px',
                        fontWeight: "500",
                        color:
                          new Date(state.Deactivation_Date).getTime() >=
                            new Date().getTime()
                            ? "black"
                            : "#58cde8",
                      }}
                    >
                      {state.UPIN}
                    </span>
                  </Typography>
                </Grid>
              </Grid>
            ) : (
                ""
              )}
            <Container>
            <Row>
              <Col style={{zIndex:state.right_col_zIndex}} className={classes.coll1} lg={6} id="div1">
                {state.contractGrid ? (
                  <div id="contractGrid">
                    <div
                      style={{
                        overflow: "scroll",
                        height: "170px",
                        width: state.resizewidth,
                        marginTop: state.resemargionorgspec,
                      }}
                    >
                      <table
                        id="resizeContractOrg"
                        className="table"
                        style={{ width: "2000px" }}
                      >
                        <thead>
                          <tr style={{ height: "50px" }}>
                            <th
                              style={{ width: "100px" }}
                              className="resizeTH stickyThTd"
                            >
                              <Tooltip
                                title={
                                  <div
                                    style={{
                                      backgroundColor: "white",
                                      color: "black",

                                      width: "290px",
                                      paddingLeft: "3px",
                                      paddingRight: "5px",
                                      paddingTop: "5px",
                                    }}
                                  >
                                    <b>NDB Screen Name/Mapping </b>
                                    <b>(</b>Category-Area-F Key<b>)</b>:
                                    SPECIALTY BY CONTRACT ORGANIZATION (S-Z)
                                    <br />
                                    <br />
                                    Contract Organization specialties are those
                                    specialties which apply to one or more
                                    Non-UHN contract organization(s). This field
                                    is leveraged to flag shared provider
                                    demographic considerations when performing
                                    maintenance.
                                  </div>
                                }
                              >
                                {
                                  <b className={classes.inputText2}>
                                    <b> Contract Org Spec</b>{" "}
                                  </b>
                                }
                              </Tooltip>
                            </th>
                            <th
                              style={{ width: "80px", textAlign: "center" }}
                              className="resizeTH stickyThTd"
                            >
                              Spec Cd
                            </th>
                            <th
                              style={{ width: "100px" }}
                              className="resizeTH stickyThTd"
                            >
                              Spec Description
                            </th>
                            <th style={{ width: "40px" }} className="resizeTH">
                              P/S
                            </th>
                            <th style={{ width: "50px" }} className="resizeTH">
                              Prac
                            </th>
                            <th style={{ width: "70px" }} className="resizeTH">
                              Source
                            </th>
                            <th
                              style={{
                                width: "40px",
                                display: pType == "o" ? "none" : "",
                              }}
                              className="resizeTH"
                            >
                              BC
                            </th>
                            <th className="resizeTH">Effective Date</th>
                            <th className="resizeTH">Cancel Date</th>
                            <th className="resizeTH">Board Date</th>
                            <th className="resizeTH">Exp Date</th>
                            <th className="resizeTH">Cert Date</th>
                            <th className="resizeTH">Recert Date</th>
                            <th className="resizeTH">Board #</th>
                            <th className="resizeTH">CATGY</th>
                            <th className="resizeTH">Resident</th>
                            <th className="resizeTH">PCP OVR</th>
                            <th className="resizeTH">TRC ID</th>
                          </tr>
                        </thead>
                        <tbody>
                          {state.Contract_Org_Spec.map((Specdata) => (
                            <tr
                              style={{
                                color:
                                  !Moment(
                                    `${Specdata.contr_org_spcl_canc_dt}`,
                                    "YYYY-MM-DD"
                                  ).isAfter() ||
                                  Specdata.contr_org_spcl_eff_dt ==
                                    Specdata.contr_org_spcl_canc_dt
                                    ? "#58cde8"
                                    : "",
                                lineHeight: "18px",
                              }}
                            >
                              <td>
                                <Tooltip
                                  title={
                                    <div
                                      style={{
                                        backgroundColor: "white",
                                        color: "black",
                                        height: "25px",
                                        paddingLeft: "5px",
                                        paddingRight: "5px",
                                        paddingTop: "5px",
                                      }}
                                    >
                                      <table
                                        border="0"
                                        cellSpacing="0"
                                        cellPadding="0"
                                      >
                                        <tbody>
                                          <tr>
                                            <td
                                              style={{
                                                color: Moment(
                                                  `${Specdata.contr_org_spcl_canc_dt}`,
                                                  "YYYY-MM-DD"
                                                ).isAfter()
                                                  ? "black"
                                                  : "#58cde8",
                                              }}
                                            >
                                              {Specdata.contr_org_cd_desc}
                                            </td>
                                          </tr>
                                        </tbody>
                                      </table>
                                    </div>
                                  }
                                >
                                  <div>{Specdata.contr_org_cd}</div>
                                </Tooltip>
                              </td>
                              <td>{Specdata.spcl_typ_cd}</td>
                              <td>
                                <EllipsisToolTip options={optionRight}>
                                  {Specdata.spcl_typ_full_desc}
                                </EllipsisToolTip>
                              </td>
                              <td>{Specdata.pri_cd}</td>
                              <td>{Specdata.prac_spcl_ind}</td>
                              <td>{Specdata.spcl_src_cd}</td>
                              <td
                                style={{ display: pType == "o" ? "none" : "" }}
                              >
                                {Specdata.spcl_bd_cert_cd}
                              </td>
                              <td>
                                {changeDateFormat(
                                  Specdata.contr_org_spcl_eff_dt
                                )}
                              </td>
                              <td>
                                {changeDateFormat(
                                  Specdata.contr_org_spcl_canc_dt
                                )}
                              </td>
                              <td>
                                {changeDateFormat(Specdata.spcl_bd_exam_dt)}
                              </td>
                              <td>
                                {changeDateFormat(Specdata.spcl_bd_expir_dt)}
                              </td>
                              <td>
                                {changeDateFormat(Specdata.spcl_bd_cert_dt)}
                              </td>
                              <td>{changeDateFormat(Specdata.rcert_eff_dt)}</td>
                              <td>
                                {Specdata.cred_verf_org_ind.length < 9
                                  ? prependZerosForBoard(
                                      Specdata.cred_verf_org_ind
                                    )
                                  : Specdata.cred_verf_org_ind}
                              </td>
                              <td>{Specdata.spcl_catgy_cd}</td>
                              <td>{Specdata.res_ind}</td>
                              <td>{Specdata.pcp_spcl_ovrd_ind}</td>
                              <td>{Specdata.tricare_ind}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                    <div
                      style={{
                        position: "absolute",
                        marginTop: "-3%",
                        marginLeft: state.contractOrgDiv ? "191.5%" : "93%",
                      }}
                    >
                      <HeightIcon
                        onClick={makeGridLargeforContractOrg}
                        style={{
                          cursor: "pointer",
                          transform: "rotate(90deg)",
                        }}
                      />
                    </div>
                  </div>
                ) : (
                  ""
                )}

                {state.contractGrid ? <div style={{ height: 5 }} /> : ""}

                {state.NPIGrid ? (
                  <div id="NPIGrid">
                    <div
                      style={{
                        overflow: "scroll",
                        height: "170px",
                        width: state.resizewidthNPI,
                        marginTop: state.resmarginonnpi,
                      }}
                    >
                      <table
                        id="resizeNPI"
                        className="table"
                        style={{ width:state.NPIdiv ?"100%":"1100px" }}
                      >
                        <thead>
                          <tr>
                            <th className="resizeTH stickyThTd defaultThWidth100">
                              <Link
                                style={{ cursor: "pointer" }}
                                onClick={() =>
                                  window.open(
                                    "https://nppes.cms.hhs.gov/#/",
                                    "_blank"
                                  )
                                }
                              >
                                <Tooltip
                                  title={
                                    <div
                                      style={{
                                        backgroundColor: "white",
                                        color: "black",

                                        width: "290px",
                                        paddingLeft: "3px",
                                        paddingRight: "5px",
                                        paddingTop: "5px",
                                      }}
                                    >
                                      <b>NDB Screen Name/Mapping</b> <b>(</b>
                                      Category-Area-F Key<b>):</b>NPI
                                      INFORMATION (5-Z)
                                      <br />
                                      <br />
                                      National Provider Identifier is a 10 digit
                                      number assigned by the Health Insurance
                                      Portability and Accountability Act (HIPAA)
                                      Administration to uniquely identify
                                      healthcare providers.
                                      <br /> <br />
                                      To navigate NPI Registry Website double
                                      click NPI column header.
                                    </div>
                                  }
                                >
                                  {
                                    <b className={classes.inputText2}>
                                      <b> NPI</b>{" "}
                                    </b>
                                  }
                                </Tooltip>
                              </Link>
                            </th>
                            <th className="resizeTH defaultThWidth100">
                              Taxonomy
                            </th>
                            <th style={{ width: "50px" }} className="resizeTH">
                              Prim <br /> Tax
                            </th>
                            <th style={{ width: "60px" }} className="resizeTH">
                              {" "}
                              NPI <br /> Level
                            </th>
                            <th className="resizeTH defaultThWidth100">
                              Level Information
                            </th>
                            <th className="resizeTH">Effective Date</th>
                            <th className="resizeTH">Cancel Date</th>
                            <th className="resizeTH">Reason</th>
                            <th className="resizeTH">Source</th>
                          </tr>
                        </thead>
                        <tbody>
                          {state.NPIinfo.map((npidata) => (
                            <tr
                              style={{
                                color:
                                  !Moment(
                                    `${npidata.canc_dt}`,
                                    "YYYY-MM-DD"
                                  ).isAfter() ||
                                  npidata.eff_dt == npidata.canc_dt
                                    ? "#58cde8"
                                    : "",
                                lineHeight: "18px",
                              }}
                            >
                              <td>{npidata.npi_id}</td>
                              <td>{npidata.npi_taxonomy}</td>
                              <td>{npidata.npi_primary_taxonomy}</td>
                              <td>{npidata.npi_level_code}</td>
                              <td>
                                {prependZerosForBoard(
                                  npidata.npi_level_information
                                )}
                              </td>
                              <td>{changeDateFormat(npidata.eff_dt)}</td>
                              <td>{changeDateFormat(npidata.canc_dt)}</td>
                              <td>{npidata.npi_cancel_reason}</td>
                              <td>{npidata.npi_source}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                    <div
                      style={{
                        position: "absolute",
                        marginTop: "-3%",
                        marginLeft: state.NPIdiv ? "191.5%" : "93%",
                      }}
                    >
                      <HeightIcon
                        onClick={makeGridLargeforNPI}
                        style={{
                          cursor: "pointer",
                          transform: "rotate(90deg)",
                        }}
                      />
                    </div>
                  </div>
                ) : (
                  ""
                )}

                {state.NPIGrid ? <div style={{ height: 5 }} /> : ""}
                {state.degreeGrid ? gridDisplay() : ""}
                {state.degreeGrid ? (
                  pType == "p" ? (
                    <div style={{ height: 5 }} />
                  ) : (
                    ""
                  )
                ) : (
                  ""
                )}
                {state.trainingTypeGrid ? (
                  <div id="trainingTypeGrid">
                    <div
                      style={{
                        overflow: "scroll",
                        height: "170px",
                        width: state.resizewidthTrainingType,
                        marginTop: state.resmarginontrainingtype,
                      }}
                    >
                      <table
                        id="resizeTrainingType"
                        className="table"
                        style={{ width: "1600px" }}
                      >
                        <thead>
                          <tr>
                            <th className="resizeTH stickyThTd">
                              <Tooltip
                                title={
                                  <div
                                    style={{
                                      backgroundColor: "white",
                                      color: "black",

                                      width: "290px",
                                      paddingLeft: "3px",
                                      paddingRight: "5px",
                                      paddingTop: "5px",
                                    }}
                                  >
                                    <b>NDB Screen Name/Mapping</b> <b>(</b>
                                    Category-Area-F Key<b>):</b> TRAINING (I-C)
                                    <br />
                                    <br />
                                    Identifies information regarding the
                                    provider’s Internship, Residency and
                                    Fellowship, if applicable.
                                  </div>
                                }
                              >
                                {
                                  <b className={classes.inputText2}>
                                    <b>
                                      {" "}
                                      Training
                                      <br /> Type{" "}
                                    </b>{" "}
                                  </b>
                                }
                              </Tooltip>
                            </th>
                            <th className="resizeTH">
                              Inst
                              <br /> Cd
                            </th>
                            <th className="resizeTH">
                              Institution
                              <br /> Name
                            </th>
                            <th className="resizeTH">Start Date</th>
                            <th className="resizeTH">End Date</th>
                            <th className="resizeTH defaultThWidth50">
                              Act
                              <br /> Cd
                            </th>
                            <th className="resizeTH">
                              Education
                              <br /> Type
                            </th>
                            <th className="resizeTH">
                              Education
                              <br /> Description
                            </th>
                            <th className="resizeTH">
                              Institution
                              <br /> Board Code
                            </th>
                            <th className="resizeTH">
                              Board
                              <br /> Name
                            </th>
                          </tr>
                        </thead>
                        <tbody>
                          {state.Training_info.map((Training_infodata) => (
                            <tr
                              style={{
                                color:
                                  Training_infodata.act_cd == "I"
                                    ? "#58cde8"
                                    : "",
                                lineHeight: "18px",
                              }}
                            >
                              <td>{Training_infodata.training_type}</td>
                              <td>{Training_infodata.inst_cd}</td>
                              <td>
                                <EllipsisToolTip options={Options}>
                                  {Training_infodata.institution_name}
                                </EllipsisToolTip>
                              </td>
                              <td>
                                {changeDateFormat(Training_infodata.start_date)}
                              </td>
                              <td>
                                {changeDateFormat(Training_infodata.end_date)}
                              </td>
                              <td>{Training_infodata.act_cd}</td>
                              <td>{Training_infodata.education_type}</td>
                              <td>{Training_infodata.education_desc}</td>
                              <td>
                                {Training_infodata.institution_board_code}
                              </td>
                              <td>
                                <EllipsisToolTip options={Options}>
                                  {Training_infodata.board_name}
                                </EllipsisToolTip>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                    <div
                      style={{
                        position: "absolute",
                        marginTop: "-3%",
                        marginLeft: state.trainingTypeDiv ? "191.5%" : "93%",
                      }}
                    >
                      <HeightIcon
                        onClick={makeGridLargeforTrainingType}
                        style={{
                          cursor: "pointer",
                          transform: "rotate(90deg)",
                        }}
                      />
                    </div>
                  </div>
                ) : (
                  ""
                )}
                {state.trainingTypeGrid ? <div style={{ height: 5 }} /> : ""}

                {state.malpracticeGrid ? (
                  <div id="malpracticeGrid">
                    <div
                      style={{
                        overflow: "scroll",
                        height: "170px",
                        width: state.resizewidthMalpractice,
                        marginTop: state.resmarginonmalpractice,
                      }}
                    >
                      <table
                        id="resizeMalpractice"
                        className="table"
                        style={{ width: "100%" }}
                      >
                        <thead>
                          <tr>
                            <th
                              className="resizeTH stickyThTd"
                              style={{ width: "95px" }}
                            >
                              <Tooltip
                                title={
                                  <div
                                    style={{
                                      backgroundColor: "white",
                                      color: "black",

                                      width: "290px",
                                      paddingLeft: "3px",
                                      paddingRight: "5px",
                                      paddingTop: "5px",
                                    }}
                                  >
                                    <b>NDB Screen Name/Mapping</b> <b>(</b>
                                    Category-Area-F Key<b>):</b> MALPRACTICE
                                    CARRIER (G-C)
                                    <br />
                                    <br />
                                    Malpractice Carrier Code identifies
                                    provider's medical malpractice insurance
                                    carrier.
                                  </div>
                                }
                              >
                                {
                                  <b className={classes.inputText2}>
                                    <b>
                                      {" "}
                                      Malpractice
                                      <br /> Carrier Cd
                                    </b>{" "}
                                  </b>
                                }
                              </Tooltip>
                            </th>
                            <th className="resizeTH">Carrier Name</th>
                            <th className="resizeTH" style={{ width: "141px" }}>
                              Policy Number
                            </th>
                            <th className="resizeTH defaultThWidth50">
                              Act
                              <br /> Cd
                            </th>
                            <th className="resizeTH">
                              Amount
                              <br /> Single
                            </th>
                            <th className="resizeTH">
                              Amount
                              <br /> Multiple
                            </th>
                            <th className="resizeTH" style={{ width: "93px" }}>
                              Effective Date
                            </th>
                            <th className="resizeTH" style={{ width: "93px" }}>
                              Expiration Date
                            </th>
                          </tr>
                        </thead>
                        <tbody>
                          {state.Malpractice_info.map((Malpractice_data) => (
                            <tr style={{ lineHeight: "18px" }}>
                              <td>
                                {Malpractice_data.malpractice_carrier_code}
                              </td>
                              <td>
                                <EllipsisToolTip options={Options}>
                                  {Malpractice_data.malpractice_carrier_name}
                                </EllipsisToolTip>
                              </td>
                              <td>
                                {Malpractice_data.malpractice_policy_number}
                              </td>
                              <td
                                style={{
                                  fontWeight:
                                    !Moment(
                                      `${Malpractice_data.malpractice_expiration_date}`,
                                      "YYYY-MM-DD"
                                    ).isAfter() ||
                                    Malpractice_data.malpractice_effective_date ==
                                      Malpractice_data.malpractice_expiration_date
                                      ? "bold"
                                      : "",
                                }}
                              >
                                {
                                  Malpractice_data.malpractice_active_status_code
                                }
                              </td>
                              <td>
                                {prependZerosForBoard(
                                  Malpractice_data.malpractice_amount_single
                                )}
                              </td>
                              <td>
                                {prependZerosForBoard(
                                  Malpractice_data.malpractice_amount_multiple
                                )}
                              </td>
                              <td>
                                {changeDateFormat(
                                  Malpractice_data.malpractice_effective_date
                                )}
                              </td>
                              <td
                                style={{
                                  color: !Moment(
                                    `${Malpractice_data.malpractice_expiration_date}`,
                                    "YYYY-MM-DD"
                                  ).isAfter()
                                    ? "#58cde8"
                                    : "",
                                  fontWeight:
                                    !Moment(
                                      `${Malpractice_data.malpractice_expiration_date}`,
                                      "YYYY-MM-DD"
                                    ).isAfter() ||
                                    Malpractice_data.malpractice_effective_date ==
                                      Malpractice_data.malpractice_expiration_date
                                      ? "bold"
                                      : "",
                                }}
                              >
                                {changeDateFormat(
                                  Malpractice_data.malpractice_expiration_date
                                )}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                    <div
                      style={{
                        position: "absolute",
                        marginTop: "-3%",
                        marginLeft: state.malpracticeDiv ? "191.5%" : "93%",
                      }}
                    >
                      <HeightIcon
                        onClick={makeGridLargeforMalpractice}
                        style={{
                          cursor: "pointer",
                          transform: "rotate(90deg)",
                        }}
                      />
                    </div>
                  </div>
                ) : (
                  ""
                )}
                {state.malpracticeGrid ? <div style={{ height: 5 }} /> : ""}
                {state.hospitalGrid ? (
                  <div id="hospitalGrid">
                    <div
                      style={{
                        overflow: "scroll",
                        height: "170px",
                        width: state.resizewidthHospital,
                        marginTop: state.resmarginonhospital,
                      }}
                    >
                      <table
                        id="resizeHospital"
                        className="table"
                        style={{ width: "100%" }}
                      >
                        <thead>
                          <tr>
                            <th className="resizeTH stickyThTd">
                              <Tooltip
                                title={
                                  <div
                                    style={{
                                      backgroundColor: "white",
                                      color: "black",

                                      width: "290px",
                                      paddingLeft: "3px",
                                      paddingRight: "5px",
                                      paddingTop: "5px",
                                    }}
                                  >
                                    <b>NDB Screen Name/Mapping</b> <b>(</b>
                                    Category-Area-F Key<b>):</b> AFFILIATION -
                                    HOSPITAL (I-H-A)
                                    <br />
                                    <br />
                                    Hospital MPIN's provider has a relationship
                                    with.
                                  </div>
                                }
                              >
                                {
                                  <b className={classes.inputText2}>
                                    <b>
                                      {" "}
                                      Hospital
                                      <br /> MPIN Affiliation{" "}
                                    </b>{" "}
                                  </b>
                                }
                              </Tooltip>
                            </th>
                            <th className="resizeTH defaultThWidth50">P/S</th>
                            <th className="resizeTH defaultThWidth50">AP</th>
                            <th className="resizeTH defaultThWidth50">DIR</th>
                            <th className="resizeTH">NAME</th>
                            {/* <th className='resizeTH' >Address Street</th>
                          <th className='resizeTH' >CITY</th>
                          <th className='resizeTH' >ST</th>
                          <th className='resizeTH' >ZIP</th>
                          <th className='resizeTH' >ZIP+4</th>
                          <th className='resizeTH' >PHONE</th> 
                            <th className='resizeTH' >PROD</th>
                            <th className='resizeTH' >Contract<br /> Org</th>
                            <th className='resizeTH' >Y Ind</th>*/}
                          </tr>
                        </thead>
                        <tbody>
                          {state.Hospital_affiliation_info.map(
                            (Hospital_affiliation_data) => (
                              <tr style={{ lineHeight: "18px" }}>
                                <td>
                                  {Hospital_affiliation_data.affil_prov_id}
                                </td>
                                <td>
                                  {
                                    Hospital_affiliation_data.hosp_affil_primary_secondary
                                  }
                                </td>
                                <td>
                                  {Hospital_affiliation_data.hosp_affil_ap}
                                </td>
                                <td>
                                  {
                                    Hospital_affiliation_data.hosp_affil_directory
                                  }
                                </td>
                                <td>
                                  <EllipsisToolTip options={Options}>
                                    {(
                                      Hospital_affiliation_data.fst_nm +
                                      " " +
                                      Hospital_affiliation_data.mdl_nm +
                                      " " +
                                      Hospital_affiliation_data.lst_nm +
                                      " " +
                                      Hospital_affiliation_data.nm_sufx_cd
                                    ).trim()}
                                  </EllipsisToolTip>
                                </td>

                                {/* <td><EllipsisToolTip options={Options}>{Malpractice_data.malpractice_carrier_name}</EllipsisToolTip></td> */}
                                {/* <td>{Hospital_affiliation_data.hosp_affil_address}</td>
                              <td>{Hospital_affiliation_data.hosp_affil_city}</td>
                              <td>{Hospital_affiliation_data.hosp_affil_state}</td>
                              <td>{Hospital_affiliation_data.hosp_affil_zip}</td>
                              <td>{Hospital_affiliation_data.hosp_affil_4_zip}</td>
                              <td>{Hospital_affiliation_data.hosp_affil_phone}</td> 
                                <td>{Hospital_affiliation_data.unet_prdct_cd}</td>
                                <td>{Hospital_affiliation_data.affil_prov_id}</td>
                                <td>{Hospital_affiliation_data.affil_prov_id}</td>*/}
                              </tr>
                            )
                          )}
                        </tbody>
                      </table>
                    </div>
                    <div
                      style={{
                        position: "absolute",
                        marginTop: "-3%",
                        marginLeft: state.hospitalDiv ? "191.5%" : "93%",
                      }}
                    >
                      <HeightIcon
                        onClick={makeGridLargeforHospital}
                        style={{
                          cursor: "pointer",
                          transform: "rotate(90deg)",
                        }}
                      />
                    </div>
                  </div>
                ) : (
                  ""
                )}
                {state.hospitalGrid ? <div style={{ height: 5 }} /> : ""}
              </Col>
              <Col className={classes.coll2} lg={6} id="div2">
                {state.contractViewGrid ? (
                  <div id="contractViewGrid">
                    <div
                      style={{
                        overflow: "scroll",
                        height: "170px",
                        marginTop: state.resetmargin_overview,
                        width: state.resetoverviewwidth,
                        marginLeft: state.resemargionorgspec_left,
                      }}
                    >
                      <table
                        id="resizeContractView"
                        className="table"
                        style={{ width: "100%" }}
                      >
                        <thead>
                          <tr>
                            <th
                              className="resizeTH stickyThTd"
                              style={{ width: "130px" }}
                            >
                              <Tooltip
                                title={
                                  <div
                                    style={{
                                      backgroundColor: "white",
                                      color: "black",

                                      width: "290px",
                                      paddingLeft: "3px",
                                      paddingRight: "5px",
                                      paddingTop: "5px",
                                    }}
                                  >
                                    <b>NDB Screen Name/Mapping</b> <b>(</b>
                                    Category-Area-F Key<b>):</b>
                                    <br />
                                    <b>(1) </b>TAXID BY CONTRACT ORGANIZATION
                                    (T-Z-F6)
                                    <br />
                                    <b>(2) </b>ADDRESS BY CONTRACT ORGANIZATION
                                    (A-Z-F9)
                                    <br />
                                    <b>(3)</b> SPECIALTY (S-Z) *<br />
                                    <b>(4) </b>SPECIALTY BY CONTRACT
                                    ORGANIZATION (S-Z-F5)
                                    <br />
                                    <br />
                                    This field displays Contract Organization(s)
                                    which have active/inactive history one or
                                    more of NDB Demographic screens.
                                    <br />
                                    <br />
                                    <span style={{ color: "blue" }}>
                                      * UHN Contract Org is assumed on Main
                                      (S-Z) specialty screen.
                                    </span>
                                  </div>
                                }
                              >
                                {
                                  <b className={classes.inputText2}>
                                    <b> Contract Org Overview</b>{" "}
                                  </b>
                                }
                              </Tooltip>
                            </th>
                            <th style={{ width: "80px" }} className="resizeTH">
                              Address
                            </th>
                            <th style={{ width: "70px" }} className="resizeTH">
                              Tax ID
                            </th>
                            <th style={{ width: "90px" }} className="resizeTH">
                              Speciality
                            </th>
                            <th className="resizeTH">
                              Contract Org Description
                            </th>
                          </tr>
                        </thead>
                        <tbody>
                          {state.Contract_org_info.map(
                            (Contract_org_infodata) => (
                              <tr style={{ lineHeight: "18px" }}>
                                <td
                                  style={{
                                    color:
                                      Contract_org_infodata.tin_flag == "A" ||
                                      Contract_org_infodata.adr_flag == "A" ||
                                      Contract_org_infodata.spec_flag == "A"
                                        ? ""
                                        : "#58cde8",
                                  }}
                                >
                                  {Contract_org_infodata.contr_org_cd}
                                </td>
                                <td
                                  style={{
                                    color:
                                      Contract_org_infodata.adr_flag == "I"
                                        ? "#58cde8"
                                        : "",
                                  }}
                                >
                                  {Contract_org_infodata.adr_flag}
                                </td>
                                <td
                                  style={{
                                    color:
                                      Contract_org_infodata.tin_flag == "I"
                                        ? "#58cde8"
                                        : "",
                                  }}
                                >
                                  {Contract_org_infodata.tin_flag}
                                </td>
                                <td
                                  style={{
                                    color:
                                      Contract_org_infodata.spec_flag == "I"
                                        ? "#58cde8"
                                        : "",
                                  }}
                                >
                                  {Contract_org_infodata.spec_flag}
                                </td>
                                <td
                                  style={{
                                    color:
                                      Contract_org_infodata.tin_flag == "A" ||
                                      Contract_org_infodata.adr_flag == "A" ||
                                      Contract_org_infodata.spec_flag == "A"
                                        ? ""
                                        : "#58cde8",
                                  }}
                                >
                                  <EllipsisToolTip options={Options}>
                                    {Contract_org_infodata.contr_org_cd_desc}
                                  </EllipsisToolTip>
                                </td>
                              </tr>
                            )
                          )}
                        </tbody>
                      </table>
                    </div>
                    <div
                      style={{
                        position: "absolute",
                        marginTop: "-3%",
                        marginLeft: state.contractViewDiv ? "94.7%" : "94.7%",
                      }}
                    >
                      <HeightIcon
                        onClick={makeGridLargeforContractOverview}
                        style={{
                          cursor: "pointer",
                          transform: "rotate(90deg)",
                        }}
                      />
                    </div>
                  </div>
                ) : (
                  ""
                )}
                {state.contractViewGrid ? <div style={{ height: 5 }} /> : ""}

                {state.federealGrid ? (
                  <div id="federealGrid">
                    <div
                      style={{
                        overflow: "scroll",
                        height: "170px",
                        marginTop: state.resetmargin_federal,
                        width: state.resetfederalwidth,
                        marginLeft: state.resemargionfederal_left,
                      }}
                    >
                      <table
                        id="resizeFedereal"
                        className="table"
                        style={{ width: "100%" }}
                      >
                        <thead>
                          <tr>
                            <th
                              style={{ width: "100px" }}
                              className="resizeTH stickyThTd"
                            >
                              <Tooltip
                                title={
                                  <div
                                    style={{
                                      backgroundColor: "white",
                                      color: "black",

                                      width: "290px",
                                      paddingLeft: "3px",
                                      paddingRight: "5px",
                                      paddingTop: "5px",
                                    }}
                                  >
                                    <b>NDB Screen Name/Mapping</b> <b>(</b>
                                    Category-Area-F Key<b>):</b>DEA/CDS/LICENSE
                                    (F-C)
                                    <br />
                                    <br />
                                    Drug Enforcement Agency number assigned to
                                    providers to help facilitate their
                                    prescription writing priveleges.
                                  </div>
                                }
                              >
                                {
                                  <b className={classes.inputText2}>
                                    <b>
                                      {" "}
                                      Federal
                                      <br /> DEA
                                    </b>{" "}
                                  </b>
                                }
                              </Tooltip>
                            </th>
                            {/* <th className='resizeTHHide' >NTIS State</th> */}
                            <th className="resizeTH defaultThWidth50">
                              Act Cd
                            </th>
                            <th className="resizeTH">
                              Expiration
                              <br /> Date
                            </th>
                            {/* <th className='resizeTHHide' >NTIS Name</th>
                          <th className='resizeTHHide' >NTIS Expiration Date</th>
                          <th className='resizeTHHide' >Activity Code</th>
                          <th className='resizeTHHide' >Activity Sub Code</th>
                          <th className='resizeTHHide' >NTIS Description</th> */}
                          </tr>
                        </thead>
                        <tbody>
                          {state.Federal_DEA_info.map(
                            (Federal_DEA_infodata) => (
                              <tr style={{ lineHeight: "18px" }}>
                                <td>
                                  {Federal_DEA_infodata.drg_enfc_agcy_nbr
                                    .length > 0
                                    ? "#########"
                                    : "N/A"}
                                </td>
                                {/* <td>{Federal_DEA_infodata.st_cd}</td> */}
                                <td
                                  style={{
                                    fontWeight: !Moment(
                                      `${Federal_DEA_infodata.expir_dt}`,
                                      "YYYY-MM-DD"
                                    ).isAfter()
                                      ? "bold"
                                      : "",
                                  }}
                                >
                                  {Federal_DEA_infodata.actv_cd}
                                </td>
                                <td
                                  style={{
                                    color: !Moment(
                                      `${Federal_DEA_infodata.expir_dt}`,
                                      "YYYY-MM-DD"
                                    ).isAfter()
                                      ? "#58cde8"
                                      : "",
                                    fontWeight: !Moment(
                                      `${Federal_DEA_infodata.expir_dt}`,
                                      "YYYY-MM-DD"
                                    ).isAfter()
                                      ? "bold"
                                      : "",
                                  }}
                                >
                                  {changeDateFormat(
                                    Federal_DEA_infodata.expir_dt
                                  )}
                                </td>
                                {/* <td>####</td>
                              <td>####</td>
                              <td>####</td>
                              <td>####</td>
                              <td>####</td> */}
                              </tr>
                            )
                          )}
                        </tbody>
                      </table>
                    </div>
                    <div
                      style={{
                        position: "absolute",
                        marginTop: "-3%",
                        marginLeft: state.federealDiv ? "94.7%" : "94.7%",
                      }}
                    >
                      <HeightIcon
                        onClick={makeGridLargeforFedereal}
                        style={{
                          cursor: "pointer",
                          transform: "rotate(90deg)",
                        }}
                      />
                    </div>
                  </div>
                ) : (
                  ""
                )}
                {state.federealGrid ? <div style={{ height: 5 }} /> : ""}
                {state.CDSGrid ? (
                  <div id="CDSGrid">
                    <div
                      style={{
                        overflow: "scroll",
                        height: "170px",
                        marginTop: state.resetmargin_cdschrt,
                        width: state.resetcdswidth,
                        marginLeft: state.resemargioncds_left,
                      }}
                    >
                      <table
                        id="resizeCDS"
                        className="table"
                        style={{ width: "100%" }}
                      >
                        <thead>
                          <tr>
                            <th className="resizeTH" style={{ width: "100px" }}>
                              <Tooltip
                                title={
                                  <div
                                    style={{
                                      backgroundColor: "white",
                                      color: "black",

                                      width: "290px",
                                      paddingLeft: "3px",
                                      paddingRight: "5px",
                                      paddingTop: "5px",
                                    }}
                                  >
                                    <b>NDB Screen Name/Mapping</b> <b>(</b>
                                    Category-Area-F Key<b>):</b>DEA/CDS/LICENSE
                                    (F-C)
                                    <br />
                                    <br />
                                    Chemical Dispensing Subscription
                                  </div>
                                }
                              >
                                {
                                  <b className={classes.inputText2}>
                                    <b> CDS Cert #</b>{" "}
                                  </b>
                                }
                              </Tooltip>
                            </th>
                            <th className="resizeTH defaultThWidth50">ST</th>
                            <th className="resizeTH defaultThWidth50">
                              ACT
                              <br /> Cd
                            </th>
                            <th className="resizeTH">Expiration Date</th>
                          </tr>
                        </thead>
                        <tbody>
                          {state.Cds_info.map((Cds_infofodata) => (
                            <tr style={{ lineHeight: "18px" }}>
                              <td>{Cds_infofodata.cds_cert}</td>
                              <td>{Cds_infofodata.st_cd}</td>
                              <td
                                style={{
                                  fontWeight: !Moment(
                                    `${Cds_infofodata.expir_dt}`,
                                    "YYYY-MM-DD"
                                  ).isAfter()
                                    ? "bold"
                                    : "",
                                }}
                              >
                                {Cds_infofodata.actv_cd}
                              </td>
                              <td
                                style={{
                                  color: !Moment(
                                    `${Cds_infofodata.expir_dt}`,
                                    "YYYY-MM-DD"
                                  ).isAfter()
                                    ? "#58cde8"
                                    : "",
                                  fontWeight: !Moment(
                                    `${Cds_infofodata.expir_dt}`,
                                    "YYYY-MM-DD"
                                  ).isAfter()
                                    ? "bold"
                                    : "",
                                }}
                              >
                                {changeDateFormat(Cds_infofodata.expir_dt)}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                    <div
                      style={{
                        position: "absolute",
                        marginTop: "-3%",
                        marginLeft: state.CDSdiv ? "94.7%" : "94.7%",
                      }}
                    >
                      <HeightIcon
                        onClick={makeGridLargeforCDS}
                        style={{
                          cursor: "pointer",
                          transform: "rotate(90deg)",
                        }}
                      />
                    </div>
                  </div>
                ) : (
                  ""
                )}
                {state.CDSGrid ? <div style={{ height: 5 }} /> : ""}
                {state.licenseGrid ? (
                  <div id="licenseGrid">
                    <div
                      style={{
                        overflow: "scroll",
                        height: "170px",
                        marginTop: state.resetmargin_license,
                        width: state.resetlicensewidth,
                        marginLeft: state.resemargionlicense_left,
                      }}
                    >
                      <table
                        id="resizeLicense"
                        className="table"
                        style={{ width: "100%" }}
                      >
                        <thead>
                          <tr>
                            <th
                              style={{ width: "135px" }}
                              className="resizeTH stickyThTd"
                            >
                              <Tooltip
                                title={
                                  <div
                                    style={{
                                      backgroundColor: "white",
                                      color: "black",

                                      width: "290px",
                                      paddingLeft: "3px",
                                      paddingRight: "5px",
                                      paddingTop: "5px",
                                    }}
                                  >
                                    <b>NDB Screen Name/Mapping</b> <b>(</b>
                                    Category-Area-F Key<b>):</b> DEA/CDS/LICENSE
                                    (F-C)
                                    <br />
                                    <br />
                                    License numbers are assigned at the state
                                    level to help facilitate where providers are
                                    legally allowed to practice medicine.
                                  </div>
                                }
                              >
                                {
                                  <b className={classes.inputText2}>
                                    <b> License #</b>{" "}
                                  </b>
                                }
                              </Tooltip>
                            </th>
                            <th style={{ width: "70px" }} className="resizeTH">
                              ST
                            </th>
                            <th className="resizeTH defaultThWidth50">
                              ACT
                              <br /> Cd
                            </th>
                            <th className="resizeTH">Expiration Date</th>
                            <th className="resizeTH">Effective Date</th>
                            <th style={{ width: "100px" }} className="resizeTH">
                              License
                              <br /> Board
                            </th>
                          </tr>
                        </thead>
                        <tbody>
                          {state.License_info.map((Licensedata) => (
                            <tr
                              style={{
                                color:
                                  Licensedata.actv_cd == "I" ||
                                  Licensedata.expir_dt == Licensedata.eff_dt
                                    ? "#58cde8"
                                    : "",
                                lineHeight: "18px",
                              }}
                            >
                              <td style={{ whiteSpace: "pre-wrap" }}>
                                {Licensedata.lic_nbr}
                              </td>
                              <td>{Licensedata.st_cd}</td>
                              <td
                                style={{
                                  fontWeight:
                                    Licensedata.actv_cd == "I"
                                      ? Moment(
                                          `${Licensedata.expir_dt}`,
                                          "YYYY-MM-DD"
                                        ).isAfter()
                                        ? "bold"
                                        : ""
                                      : !Moment(
                                          `${Licensedata.expir_dt}`,
                                          "YYYY-MM-DD"
                                        ).isAfter()
                                      ? "bold"
                                      : "",
                                }}
                              >
                                {Licensedata.actv_cd}
                              </td>
                              <td
                                style={{
                                  color: !Moment(
                                    `${Licensedata.expir_dt}`,
                                    "YYYY-MM-DD"
                                  ).isAfter()
                                    ? "#58cde8"
                                    : "",
                                  fontWeight:
                                    Licensedata.actv_cd == "I"
                                      ? Moment(
                                          `${Licensedata.expir_dt}`,
                                          "YYYY-MM-DD"
                                        ).isAfter()
                                        ? "bold"
                                        : ""
                                      : !Moment(
                                          `${Licensedata.expir_dt}`,
                                          "YYYY-MM-DD"
                                        ).isAfter()
                                      ? "bold"
                                      : "",
                                }}
                              >
                                {changeDateFormat(Licensedata.expir_dt)}
                              </td>
                              <td>{changeDateFormat(Licensedata.eff_dt)}</td>
                              <td>
                                {prependZerosForBoard(
                                  Licensedata.cred_verf_org_id
                                )}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                    <div
                      style={{
                        position: "absolute",
                        marginTop: "-3%",
                        marginLeft: state.licenseDiv ? "94.7%" : "94.7%",
                      }}
                    >
                      <HeightIcon
                        onClick={makeGridLargeforLicense}
                        style={{
                          cursor: "pointer",
                          transform: "rotate(90deg)",
                        }}
                      />
                    </div>
                  </div>
                ) : (
                  ""
                )}
                {state.licenseGrid ? <div style={{ height: 5 }} /> : ""}
                {state.medicareGrid ? (
                  pType == "o" ? (
                    <div id="medicareGrid">
                      <div
                        style={{
                          overflow: "scroll",
                          height: "170px",
                          marginTop: state.resetmargin_medic,
                          width: state.resetmedicarewidth,
                          marginLeft: state.resemargionmedicare_left,
                        }}
                      >
                        <table
                          id="resizeMedicare"
                          className="table"
                          style={{ width: "100%" }}
                        >
                          <thead>
                            <tr>
                              <th className="resizeTH stickyThTd">
                                <Tooltip
                                  title={
                                    <div
                                      style={{
                                        backgroundColor: "white",
                                        color: "black",

                                        width: "290px",
                                        paddingLeft: "3px",
                                        paddingRight: "5px",
                                        paddingTop: "5px",
                                      }}
                                    >
                                      <b>NDB Screen Name/Mapping</b> <b>(</b>
                                      Category-Area-F Key<b>):</b> GRP/FAC -
                                      MAIN (M-Z) (
                                      <span style={{ color: "blue" }}>F5*</span>
                                      )<br />
                                      <br />
                                      Medicare alpha-numeric identifier assigned
                                      by the federal government to distinguish
                                      providers when billing for medicare
                                      patients. The Medicare Hospital Number
                                      (also known as OSCAR #) of the facility is
                                      utilized for DRG pricing.
                                      <br />
                                      <br />
                                      <span style={{ color: "blue" }}>
                                        {" "}
                                        * NDB F5 mapping for additional Medicare
                                        ID's only applies to Group/Facility
                                        MPIN's.
                                      </span>
                                    </div>
                                  }
                                >
                                  {
                                    <b className={classes.inputText2}>
                                      <b>Medicare # </b>{" "}
                                    </b>
                                  }
                                </Tooltip>
                              </th>
                              <th className="resizeTH defaultThWidth50">LVL</th>
                              <th
                                style={{ width: "90px" }}
                                className="resizeTH"
                              >
                                Tax ID
                              </th>
                              <th className="resizeTH defaultThWidth50">
                                Tax <br />
                                Type
                              </th>
                              <th
                                style={{ width: "84px" }}
                                className="resizeTH"
                              >
                                MAID
                              </th>
                              <th className="resizeTH">
                                Facility
                                <br /> Service
                              </th>
                              {/* <th className='resizeTH defaultThWidth50' >CLM<br /> IND</th> */}
                              <th className="resizeTH defaultThWidth50">
                                ACT
                                <br /> Cd
                              </th>
                              <th
                                className="resizeTH"
                                style={{ width: "85px" }}
                              >
                                User
                                <br /> ID
                              </th>
                              <th
                                className="resizeTH"
                                style={{ width: "37px" }}
                              >
                                OFC
                                <br /> Cd
                              </th>
                              <th className="resizeTH">
                                Last
                                <br /> Update Date
                              </th>
                            </tr>
                          </thead>
                          <tbody>
                            {state.Medicare_info.map((Medicare_info_data) => (
                              <tr
                                style={{
                                  color:
                                    Medicare_info_data.medicare_active_status ==
                                    "I"
                                      ? "#58cde8"
                                      : "",
                                  lineHeight: "18px",
                                }}
                              >
                                <td>{Medicare_info_data.medicare_id}</td>
                                <td>{Medicare_info_data.medicare_level}</td>
                                <td>
                                  {prependZerosForBoard(
                                    Medicare_info_data.medicare_taxid
                                  )}
                                </td>
                                <td>{Medicare_info_data.medicare_tax_type}</td>
                                <td>
                                  {prependZerosForBoard(
                                    Medicare_info_data.medicare_maid
                                  )}
                                </td>
                                <td>
                                  {Medicare_info_data.medicare_facility_service}
                                </td>
                                {/* <td>{Medicare_info_data.medicare_claim_indicator}</td> */}
                                <td>
                                  {Medicare_info_data.medicare_active_status}
                                </td>
                                <td>{Medicare_info_data.medicare_user_id}</td>
                                <td>
                                  {Medicare_info_data.medicare_office_code}
                                </td>
                                <td>
                                  {changeDateFormat(
                                    Medicare_info_data.medicare_last_update_date
                                  )}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                      <div
                        style={{
                          position: "absolute",
                          marginTop: "-3%",
                          marginLeft: state.medicareDiv ? "94.7%" : "94.7%",
                        }}
                      >
                        <HeightIcon
                          onClick={makeGridLargeforMedicare}
                          style={{
                            cursor: "pointer",
                            transform: "rotate(90deg)",
                          }}
                        />
                      </div>
                    </div>
                  ) : state.Medicare_info.length == 1 &&
                    state.Medicare_info.map((p) => p.medicare_id)[0] == "" ? (
                    ""
                  ) : (
                    <div id="medicareGrid">
                      <div
                        style={{
                          overflow: "scroll",
                          height: "170px",
                          marginTop: state.resetmargin_medic,
                          width: state.resetmedicarewidth,
                          marginLeft: state.resemargionmedicare_left,
                        }}
                      >
                        <table
                          id="resizeMedicare"
                          className="table"
                          style={{ width: "100%" }}
                        >
                          <thead>
                            <tr>
                              <th className="resizeTH stickyThTd">
                                <Tooltip
                                  title={
                                    <div
                                      style={{
                                        backgroundColor: "white",
                                        color: "black",

                                        width: "290px",
                                        paddingLeft: "3px",
                                        paddingRight: "5px",
                                        paddingTop: "5px",
                                      }}
                                    >
                                      <b>NDB Screen Name/Mapping</b> <b>(</b>
                                      Category-Area-F Key<b>):</b> GRP/FAC -
                                      MAIN (M-Z) (
                                      <span style={{ color: "blue" }}>F5*</span>
                                      )<br />
                                      <br />
                                      Medicare alpha-numeric identifier assigned
                                      by the federal government to distinguish
                                      providers when billing for medicare
                                      patients. The Medicare Hospital Number
                                      (also known as OSCAR #) of the facility is
                                      utilized for DRG pricing.
                                      <br />
                                      <br />
                                      <span style={{ color: "blue" }}>
                                        {" "}
                                        * NDB F5 mapping for additional Medicare
                                        ID's only applies to Group/Facility
                                        MPIN's.
                                      </span>
                                    </div>
                                  }
                                >
                                  {
                                    <b className={classes.inputText2}>
                                      <b>
                                        &nbsp;
                                        <br /> Medicare #{" "}
                                      </b>{" "}
                                    </b>
                                  }
                                </Tooltip>
                              </th>
                            </tr>
                          </thead>
                          <tbody>
                            {state.Medicare_info.map((Medicare_info_data) => (
                              <tr>
                                <td>{Medicare_info_data.medicare_id}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                      <div
                        style={{
                          position: "absolute",
                          marginTop: "-3%",
                          marginLeft: state.medicareDiv ? "94.7%" : "94.7%",
                        }}
                      >
                        <HeightIcon
                          onClick={makeGridLargeforMedicare}
                          style={{
                            cursor: "pointer",
                            transform: "rotate(90deg)",
                          }}
                        />
                      </div>
                    </div>
                  )
                ) : (
                  ""
                )}
              </Col>
            </Row>
          </Container>
            <br />
          </div>
        )}
      {/* }  */}
    </Paper>
    // </div>
  );
}

function getObjects(obj, key, val) {
  var objects = [];
  for (var i in obj) {
    if (!obj.hasOwnProperty(i)) continue;
    if (typeof obj[i] == "object") {
      objects = objects.concat(getObjects(obj[i], key, val));
    }
    //if key matches and value matches or if key matches and value is not passed (eliminating the case where key matches but passed value does not)
    else if ((i == key && obj[i] == val) || (i == key && val == "")) {
      //
      objects.push(obj);
    } else if (obj[i] == val && key == "") {
      //only add if the object is not already in the array
      if (objects.lastIndexOf(obj) == -1) {
        objects.push(obj);
      }
    }
  }
  return objects;
}
const createResizableTable = function (table) {
  const cols = table.querySelectorAll("th.resizeTH");
  [].forEach.call(cols, function (col) {
    // Add a resizer element to the column
    const resizer = document.createElement("div");
    resizer.classList.add("resizer");

    // Set the height
    resizer.style.height = `${table.offsetHeight}px`;

    col.appendChild(resizer);
    for (
      var i = 0;
      i < col.parentElement.parentElement.nextElementSibling.childElementCount;
      i++
    ) {
      if (col.classList.contains("stickyThTd"))
        //checking th
        col.parentElement.parentElement.nextElementSibling.children[i].cells[
          col.cellIndex
        ].className = "stickyThTd"; //setting to tds
    }
    createResizableColumn(col, resizer);
  });
  const cols1 = table.querySelectorAll("th.stickyThTd");
  [].forEach.call(cols1, function (col) {
    if (
      col.cellIndex <
      col.parentElement.parentElement.parentElement.querySelectorAll(
        "th.stickyThTd"
      ).length -
      1
    ) {
      var left = 0;
      for (
        var i = 1;
        i <
        col.parentElement.parentElement.parentElement.querySelectorAll(
          "th.stickyThTd"
        ).length;
        i++
      ) {
        var previousWidth = parseInt(
          window
            .getComputedStyle(
              col.parentElement.parentElement.parentElement.querySelectorAll(
                "th.stickyThTd"
              )[i - 1]
            )
            .width.split("px")[0]
        ); // col.parentElement.parentElement.parentElement.querySelectorAll('th.resizeTH')[i-1].style.width!=""?parseInt(col.parentElement.parentElement.parentElement.querySelectorAll('th.resizeTH')[i-1].style.width.split('px')[0]):0;
        left += previousWidth;
        col.parentElement.parentElement.parentElement.querySelectorAll(
          "th.stickyThTd"
        )[i].style.left = left + 0 + "px";

        for (
          var j = 0;
          j <
          col.parentElement.parentElement.nextElementSibling.childElementCount;
          j++
        ) {
          col.parentElement.parentElement.nextElementSibling.children[
            j
          ].querySelectorAll("td.stickyThTd")[i].style.left = left + 0 + "px";
        }
      }
    }
  });
};

const createResizableColumn = function (col, resizer) {
  let x = 0;
  let w = 0;

  const mouseDownHandler = function (e) {
    x = e.clientX;

    const styles = window.getComputedStyle(col);
    w = parseInt(styles.width, 10);

    document.addEventListener("mousemove", mouseMoveHandler);
    document.addEventListener("mouseup", mouseUpHandler);
    resizer.classList.add("resizing");
  };

  const mouseMoveHandler = function (e) {
    const dx = e.clientX - x;

    col.style.width = `${w + dx}px`;
    console.log(w + dx);
    let ob = w + dx;
    if (ob < 10) {

      console.log("match" + ob)
    }
    else {
      console.log("not match" + ob)
    }
    //console.log(col.style.width);
    if (
      col.cellIndex <
      col.parentElement.parentElement.parentElement.querySelectorAll(
        "th.stickyThTd"
      ).length -
      1
    ) {
      var left = 0;
      for (
        var i = 1;
        i <
        col.parentElement.parentElement.parentElement.querySelectorAll(
          "th.stickyThTd"
        ).length;
        i++
      ) {
        var previousWidth = parseInt(
          window
            .getComputedStyle(
              col.parentElement.parentElement.parentElement.querySelectorAll(
                "th.stickyThTd"
              )[i - 1]
            )
            .width.split("px")[0]
        ); // col.parentElement.parentElement.parentElement.querySelectorAll('th.resizeTH')[i-1].style.width!=""?parseInt(col.parentElement.parentElement.parentElement.querySelectorAll('th.resizeTH')[i-1].style.width.split('px')[0]):0;
        left += previousWidth;
        col.parentElement.parentElement.parentElement.querySelectorAll(
          "th.stickyThTd"
        )[i].style.left = left + 0 + "px";
        for (
          var j = 0;
          j <
          col.parentElement.parentElement.nextElementSibling.childElementCount;
          j++
        ) {
          col.parentElement.parentElement.nextElementSibling.children[
            j
          ].querySelectorAll("td.stickyThTd")[i].style.left = left + 0 + "px";
        }
      }
    }


  };

  const mouseUpHandler = function () {
    resizer.classList.remove("resizing");
    document.removeEventListener("mousemove", mouseMoveHandler);
    document.removeEventListener("mouseup", mouseUpHandler);
  };

  resizer.addEventListener("mousedown", mouseDownHandler);
};

ProviderFirstInfocomponents.propTypes = {
  handleProviderFirstInfoChange: PropTypes.func,
  ProviderFirstInfo: PropTypes.any,
  resultList: PropTypes.any,
  fetchResults: PropTypes.func,
};

const mapStateToProps = (state) => {
  return {
    resultList: state.result,
  };
};

export default connect(mapStateToProps)(ProviderFirstInfocomponents);
