/* eslint-disable */
import React from "react";
import ProviderFirstInfocomponents from "./provider.first.info.components";

function ProviderDetailsComponent() {
  return <ProviderFirstInfocomponents></ProviderFirstInfocomponents>;
}

export default ProviderDetailsComponent;
