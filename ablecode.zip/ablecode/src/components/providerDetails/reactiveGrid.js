import React, { useState } from 'react';
import Paper from '@material-ui/core/Paper';
import HeightIcon from '@material-ui/icons/Height';
import ArrowBackIcon from '@material-ui/icons/ArrowBack';
import ArrowForwardIcon from '@material-ui/icons/ArrowForward';
import EllipsisToolTip from 'ellipsis-tooltip-react-chan';
import {
  Grid,
  Table,
  TableHeaderRow,
  VirtualTable,
  TableFixedColumns,
  TableColumnResizing,
} from '@devexpress/dx-react-grid-material-ui';
// import Draggable from 'react-draggable';

export default () => {
  const [tableColumnExtensions] = useState([
    { columnName: 'Spec', width: 80 },
    { columnName: 'Cd', width: 80 },
    { columnName: 'Description', width: 120 },
    { columnName: 'BoardDate', width: 120 },
    { columnName: 'CertDate', width: 120 },
    { columnName: 'RecertDate', width: 120 },
    { columnName: 'Board', width: 80 },
    { columnName: 'Resident',width: 120 },
    { columnName: 'CATGY',width: 120 },
    { columnName: 'PCPOVR',width: 120 },
    { columnName: 'TRCID',width: 120 },
  ]);
  const [largeDiv,setLargeDiv] = React.useState(false)
  const [leftColumns] = useState(['Spec', 'Cd']);
  const Root = props => <Grid.Root {...props} style={{ height: '100%',fontWeight:'bold' }} />;
  const bgColor = props => <TableHeaderRow.Root {...props} style={{backgroundColor:'#d3d3d34d'}}/>
  const makeGridLarge = () => {
    largeDiv == true ? setLargeDiv(false) : setLargeDiv(true)
  }
  // console.log("rows,columns",rows,"----->",columns)
 const rows = [{Spec: "UBH",Cd: "037",Description: "Pediatrics",BoardDate: "MM DD YYYY",CertDate: "MM DD YYYY",RecertDate: "MM DD YYYY",Board: "#########",Resident: "N",CATGY:"",PCPOVR:"N",TRCID:""},
 {Spec: "UBH",Cd: "037",Description: "Pediatrics",BoardDate: "MM DD YYYY",CertDate: "MM DD YYYY",RecertDate: "MM DD YYYY",Board: "#########",Resident: "N",CATGY:"",PCPOVR:"N",TRCID:""},
 {Spec: "UBH",Cd: "037",Description: "Pediatrics",BoardDate: "MM DD YYYY",CertDate: "MM DD YYYY",RecertDate: "MM DD YYYY",Board: "#########",Resident: "N",CATGY:"",PCPOVR:"N",TRCID:""},
 {Spec: "UBH",Cd: "037",Description: "Pediatrics",BoardDate: "MM DD YYYY",CertDate: "MM DD YYYY",RecertDate: "MM DD YYYY",Board: "#########",Resident: "N",CATGY:"",PCPOVR:"N",TRCID:""},
 {Spec: "UBH",Cd: "037",Description: "Pediatrics",BoardDate: "MM DD YYYY",CertDate: "MM DD YYYY",RecertDate: "MM DD YYYY",Board: "#########",Resident: "N",CATGY:"",PCPOVR:"N",TRCID:""},
 {Spec: "UBH",Cd: "037",Description: "Pediatrics",BoardDate: "MM DD YYYY",CertDate: "MM DD YYYY",RecertDate: "MM DD YYYY",Board: "#########",Resident: "N",CATGY:"",PCPOVR:"N",TRCID:""},
 {Spec: "UBH",Cd: "037",Description: "Pediatrics",BoardDate: "MM DD YYYY",CertDate: "MM DD YYYY",RecertDate: "MM DD YYYY",Board: "#########",Resident: "N",CATGY:"",PCPOVR:"N",TRCID:""},
 {Spec: "UBH",Cd: "037",Description: "Pediatrics",BoardDate: "MM DD YYYY",CertDate: "MM DD YYYY",RecertDate: "MM DD YYYY",Board: "#########",Resident: "N",CATGY:"",PCPOVR:"N",TRCID:""},
 {Spec: "UBH",Cd: "037",Description: "Pediatrics",BoardDate: "MM DD YYYY",CertDate: "MM DD YYYY",RecertDate: "MM DD YYYY",Board: "#########",Resident: "N",CATGY:"",PCPOVR:"N",TRCID:""}]
 const columns =[{name: "Spec", title: "Spec"},
  {name: "Cd", title: "Cd"},
  {name: "Description", title: "Description"},
  {name: "BoardDate", title: "ExpireDate"},
  {name: "CertDate",title: "CertDate"},
  {name: "RecertDate", title: "RecertDate"},
  {name: "Board", title: "Board"},
  {name: "Resident", title: "Resident"},
  {name: "CATGY", title: "CATGY"},
  {name: "PCPOVR", title: "PCPOVR"},
  {name: "TRCID", title: "TRCID"}]
  const layout = [{ key: 'test', x: 0, y: 0, width: 200, height: 100, zIndex: 1 }]
  const canResizable = (isResize) => {
    return { top: isResize, right: isResize, bottom: isResize, left: isResize, topRight: isResize, bottomRight: isResize, bottomLeft: isResize, topLeft: isResize };
};
  return (
    <React.Fragment>
    {/* <Draggable axis="both"
        defaultPosition={{x: 0, y: 0}}
        grid={[25, 25]}
        scale={1}
        > */}
    <div style={{display:'flex',position:'relative',paddingTop:'10px',zIndex:9999}}>
    <div style={{width : largeDiv ? '100%' : '50%'}}>
    <Paper style={{ height: '200px' }}>
      <Grid
        rows={rows}
        columns={columns}
        rootComponent={Root}
      >
        <VirtualTable height="auto"/>
        <TableColumnResizing defaultColumnWidths={tableColumnExtensions} />
        <TableHeaderRow rootComponent={bgColor}/>
        <TableFixedColumns
          leftColumns={leftColumns}
        />
      </Grid>
    </Paper>
    </div>
    
    </div>
    {/* </Draggable> */}
    {/* <Paper style={{ height: '200px' }}>
      <Grid
        rows={rows}
        columns={columns}
        rootComponent={Root}
      >
        <VirtualTable height="auto"/>
        <TableColumnResizing defaultColumnWidths={tableColumnExtensions} />
        <TableHeaderRow rootComponent={bgColor}/>
        <TableFixedColumns
          leftColumns={leftColumns}
        />
      </Grid>
    </Paper> */}
    {/* <table style={{border: '1px solid #000000',width:100}}>
  <tr style={{border: '1px solid #000000'}}>
    <th>Company</th>
    <th>Contact</th>
    <th>Country</th>
  </tr>
  <tr>
    <td><div style={{width:220}}><EllipsisToolTip>KKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKK</EllipsisToolTip></div></td>
    <td>Maria Anders</td>
    <td>Germany</td>
  </tr>
  <tr>
    <td>Centro comercial Moctezuma</td>
    <td>Francisco Chang</td>
    <td>Mexico</td>
  </tr>
  <tr>
    <td>Ernst Handel</td>
    <td>Roland Mendel</td>
    <td>Austria</td>
  </tr>
  <tr>
    <td>Island Trading</td>
    <td>Helen Bennett</td>
    <td>UK</td>
  </tr>
  <tr>
    <td>Laughing Bacchus Winecellars</td>
    <td>Yoshi Tannamuri</td>
    <td>Canada</td>
  </tr>
  <tr>
    <td>Magazzini Alimentari Riuniti</td>
    <td>Giovanni Rovelli</td>
    <td>Italy</td>
  </tr>
</table> */}

    </React.Fragment>
  );
};
