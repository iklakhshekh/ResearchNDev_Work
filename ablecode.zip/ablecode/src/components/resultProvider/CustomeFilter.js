/* eslint-disable */
export const getprimaryAddressIndicatorFun = list => {
    var filteredprimaryAddressIndicator = [];
    for (var i = 0; i < list.length; i++) {
        if (
            filteredprimaryAddressIndicator.filter(
                x =>
                    x.primaryAddressIndicator ==
                    list[i].addressinfo[0].pri_cd + "-" + list[i].addressinfo[0].corsp_adr_ind
            ).length == 0
        ) {
            filteredprimaryAddressIndicator.push({
                addressId: list[i].adr_id,
                primaryAddressIndicator:
                    list[i].addressinfo[0].pri_cd + "-" + list[i].addressinfo[0].corsp_adr_ind
            });
        }
    }
    return filteredprimaryAddressIndicator;
};
export const getAddressList = list => {
    var filtered = [];
    for (var i = 0; i < list.length; i++) {
        if (
            filtered.filter(
                x =>
                    x.addressTypeCode ==
                    list[i].adr_typ_cd
            ).length == 0
        ) {
            filtered.push({
                addressId: list[i].adr_id,
                addressTypeCode:
                    list[i].adr_typ_cd
            });
        }
    }
    return filtered;
};

export const billSequenceList = list => {
    var filtered = [];
    for (var i = 0; i < list.length; i++) {
        let billSequence = list[i].addressinfo[0].bill_postal_information.bill_seq_num !== undefined ? list[i].addressinfo[0].bill_postal_information.bill_seq_num : "";
        if (billSequence !== "")
            billSequence = "" + addZerosForSequence(billSequence)
        if (
            filtered.filter(
                x =>
                    x.billSequence == billSequence
            ).length == 0
        ) {
            filtered.push({
                addressId: list[i].adr_id,
                billSequence: billSequence
            });
        }
    }
    return filtered;
};

export const mpinList = list => {
    var mpinFiltered = [];
    for (var i = 0; i < list.length; i++) {
        if (
            mpinFiltered.filter(
                x =>
                    x.mpin === "" + list[i].prov_id
            ).length == 0
        ) {
            mpinFiltered.push({
                addressId: "" + list[i].adr_id,
                mpin: "" + list[i].prov_id
            });
        }
    }
    return mpinFiltered;
};

export const mpinTypeList = list => {
    var mpinTypeFiltered = [];
    for (var i = 0; i < list.length; i++) {
        if (
            mpinTypeFiltered.filter(
                x =>
                    x.mpinType === list[i].providerinformation[0].mpin_type
            ).length == 0
        ) {
            mpinTypeFiltered.push({
                addressId: list[i].adr_id,
                mpinType: list[i].providerinformation[0].mpin_type
            });
        }
    }
    return mpinTypeFiltered;
};

export const npiList = list => {
    var npiFiltered = [];
    for (var i = 0; i < list.length; i++) {
        if (list[i].providerinformation[0].npiinfo !== undefined && list[i].providerinformation[0].npiinfo.length > 0) {
            if (
                npiFiltered.filter(
                    x =>
                        x.npi === list[i].providerinformation[0].npiinfo[0].npi_id
                ).length == 0
            ) {
                npiFiltered.push({
                    addressId: list[i].adr_id,
                    npi: list[i].providerinformation[0].npiinfo[0].npi_id
                });
            }
        }

    }
    //npiFiltered = JSON.stringify(npiFiltered)
    return npiFiltered
};

export const taxIdTypeList = list => {
    var taxIdTypesFiltered = [];
    for (var i = 0; i < list.length; i++) {
        // if (list[i].providerinformation[0].npiinfo !== undefined && list[i].providerinformation[0].npiinfo.length > 0) {
        if (
            taxIdTypesFiltered.filter(
                x =>
                    x.taxIdType === list[i].tax_id_typ_cd + "-" + list[i].tax_id_nbr
            ).length == 0
        ) {
            taxIdTypesFiltered.push({
                addressId: list[i].adr_id,
                taxIdType: list[i].tax_id_typ_cd + "-" + list[i].tax_id_nbr
            });
        }
        // }

    }
    return taxIdTypesFiltered;
};
export const prefixSuffixList = list => {
    var prefixSuffixFiltered = [];
    for (var i = 0; i < list.length; i++) {
        if (list[i].addressinfo[0].tops_tin_prfx_cd !== undefined && list[i].addressinfo[0].tops_tin_prfx_cd !== "" && list[i].addressinfo[0].tops_tin_sufx_cd !== undefined) {
            if (
                prefixSuffixFiltered.filter(
                    x =>
                        x.prefixSuffix === list[i].addressinfo[0].tops_tin_prfx_cd + "-" + addZerosforSuffix(list[i].addressinfo[0].tops_tin_sufx_cd)
                ).length == 0
            ) {
                prefixSuffixFiltered.push({
                    addressId: list[i].adr_id,
                    prefixSuffix: list[i].addressinfo[0].tops_tin_prfx_cd + "-" + addZerosforSuffix(list[i].addressinfo[0].tops_tin_sufx_cd)
                });
            }
        }

    }
    return prefixSuffixFiltered;
};

export const providerNameList = list => {
    var providerNameFiltered = [];
    for (var i = 0; i < list.length; i++) {
        let comma = list[i].providerinformation[0].prov_typ_cd == "P" ? ", " : " ";
        let space = list[i].providerinformation[0].nm_sufx_cd !== "" ? " " : "";
        // if (list[i].addressinfo[0].tops_tin_prfx_cd !== undefined && list[i].addressinfo[0].tops_tin_prfx_cd !== "" && list[i].addressinfo[0].tops_tin_sufx_cd !== undefined) {
        if (
            providerNameFiltered.filter(
                x =>
                    x.providerName === list[i].providerinformation[0].lst_nm + space + list[i].providerinformation[0].nm_sufx_cd + comma + list[i].providerinformation[0].fst_nm + " " + list[i].providerinformation[0].mdl_nm
            ).length == 0
        ) {
            providerNameFiltered.push({
                addressId: list[i].adr_id,
                providerName: list[i].providerinformation[0].lst_nm + space + list[i].providerinformation[0].nm_sufx_cd + comma + list[i].providerinformation[0].fst_nm + " " + list[i].providerinformation[0].mdl_nm
            });
        }
        // }

    }
    return providerNameFiltered;
};

export const addressAndTelephoneList = (list, params) => {

    var addressAndTelephoneFiltered = [];
    for (var i = 0; i < list.length; i++) {
        // if (list[i].addressinfo[0].tops_tin_prfx_cd !== undefined && list[i].addressinfo[0].tops_tin_prfx_cd !== "" && list[i].addressinfo[0].tops_tin_sufx_cd !== undefined) {
        let addressInfo = getFilterAddress(list[i].addressinfo, params);
        if (addressAndTelephoneFiltered.filter(x =>
            x.addressTelephone === addressInfo[0].postaladdressinfo.adr_ln_1_txt + " " +
            addressInfo[0].postaladdressinfo.cty_nm + " " +
            addressInfo[0].postaladdressinfo.st_cd + " " +
            addZerosforSuffix(addressInfo[0].postaladdressinfo.zip_cd) + " " +
            addZerosForSequence(addressInfo[0].postaladdressinfo.zip_pls_4_cd) + " " +
            addressInfo[0].telephoneinfo[0].tel_use_typ_cd + "-" +
            addressInfo[0].telephoneinfo[0].tel_nbr
            // addressInfo[0].telephoneinfo[0].area_cd +
            // addressInfo[0].telephoneinfo[0].tel_nbr.substring(0, 3) +
            // addressInfo[0].telephoneinfo[0].tel_nbr.substring(3)
        ).length == 0
        ) {
            addressAndTelephoneFiltered.push({
                addressId: list[i].adr_id,
                addressTelephone: addressInfo[0].postaladdressinfo.adr_ln_1_txt + " " +
                    addressInfo[0].postaladdressinfo.cty_nm + " " +
                    addressInfo[0].postaladdressinfo.st_cd + " " +
                    addZerosforSuffix(addressInfo[0].postaladdressinfo.zip_cd) + " " +
                    addZerosForSequence(addressInfo[0].postaladdressinfo.zip_pls_4_cd) + " " +
                    addressInfo[0].telephoneinfo[0].tel_use_typ_cd + "-" +
                    addressInfo[0].telephoneinfo[0].tel_nbr
                // addressInfo[0].telephoneinfo[0].area_cd +
                // addressInfo[0].telephoneinfo[0].tel_nbr.substring(0, 3) +
                // addressInfo[0].telephoneinfo[0].tel_nbr.substring(3)
            });
        }
        // }

    }
    return addressAndTelephoneFiltered;
};

function getFilterAddress(addressInfo, params) {
    if (addressInfo.length > 1) {
        let addressInfoDuplicate = addressInfo
        addressInfo = addressInfo.filter(adObj => adObj.address_flag === "A");
        if (addressInfo.length <= 0) {
            addressInfo = [addressInfoDuplicate[0]]
        }
    }
    // addressInfo.telephoneinfo = addressInfo.telephoneinfo
    let telephoneObj
    let telephoneinfo = addressInfo[0].telephoneinfo;
    if (params.telephone !== "") {
        telephoneObj = telephoneinfo.filter(teleObj => teleObj.tel_nbr === params.telephone)
    } else {
        telephoneObj = telephoneinfo.filter(teleObj => teleObj.pri_cd === "P")
    }
    addressInfo[0].telephoneinfo = telephoneObj
    return addressInfo
}

export const uhcidInfoList = (list, params) => {
    var uhcidInfoFiltered = [];
    for (var i = 0; i < list.length; i++) {
        if (list[i].addressinfo[0].uhcidinfo !== undefined && list[i].addressinfo[0].uhcidinfo.length > 0) {
            let uhcidInfoId;
            let info = list[i].addressinfo[0].uhcidinfo.filter(item => item.uhc_id.includes(params.uhcid.toUpperCase()));
            if (info.length >= 1) {
                let active = info.filter(item => item.uhcid_flag === "A")
                if (active.length >= 1) {
                    uhcidInfoId = active[0].uhc_id
                }
                else {
                    let inactive = info.filter(item => item.uhcid_flag === "I")
                    if (inactive.length >= 1) {
                        uhcidInfoId = inactive[0].uhc_id
                    }
                }
            }
            if (
                uhcidInfoFiltered.filter(
                    x =>
                        x.uhcId === "" + uhcidInfoId
                ).length == 0
            ) {
                uhcidInfoFiltered.push({
                    addressId: list[i].adr_id,
                    uhcId: "" + uhcidInfoId
                });
            }
        }
    }
    return uhcidInfoFiltered;
};

const addZerosForSequence = (value) => {
    if (value.length !== 0) {
        for (let i = value.length; i < 4; i++) {
            value = '0' + value;
        }
        return value
    }
}

const addZerosforSuffix = (value) => {
    if (value.length !== 0) {
        for (let i = value.length; i < 5; i++) {
            value = '0' + value;
        }
        return value
    }
}
