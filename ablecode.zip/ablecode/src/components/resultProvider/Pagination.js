/* eslint-disable */
import React, { useState, useEffect } from "react";
import PropTypes from "prop-types";
import { makeStyles } from "@material-ui/core/styles";
import Button from "@material-ui/core/Button";
import ChevronLeftIcon from "@material-ui/icons/ChevronLeft";
import ChevronRightIcon from "@material-ui/icons/ChevronRight";
import Typography from "@material-ui/core/Typography";
import OutlinedInput from "@material-ui/core/OutlinedInput";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import ReactExport from "react-data-export";
import CloudDownloadIcon from "@material-ui/icons/CloudDownload";
import ErrorOutlineIcon from '@material-ui/icons/ErrorOutline';
import ListIcon from "@material-ui/icons/List";
import Card from "@material-ui/core/Card";
import FormLabel from "@material-ui/core/FormLabel";
import FormControl from "@material-ui/core/FormControl";
import { getTeleStatusType } from "../../utils/fields.constant";
import TextField from '@material-ui/core/TextField';
import responsePojo from './ResponsePojo';
import {
  getprimaryAddressIndicatorFun, getAddressList, billSequenceList,
  mpinList, mpinTypeList, npiList, taxIdTypeList, prefixSuffixList,
  providerNameList, addressAndTelephoneList, uhcidInfoList
} from './CustomeFilter'


const ExcelFile = ReactExport.ExcelFile;
const ExcelSheet = ReactExport.ExcelFile.ExcelSheet;
const useStyles = makeStyles(() => ({
  root: {
    display: "flex",
    // padding: "1rem 0",
    width: "100%",
    position: "sticky",
    bottom: 0,
    backgroundColor: "#FFFFFF"
  },
  subRoot: {
    display: "block",
    padding: "1rem 0"
  },
  subRootNone: {
    display: "none",
    padding: "1rem 0"
  },

  gap: {
    flexGrow: 1
  },
  inputPad: {
    padding: "10px",
    width: "3rem",
    textAlign: "center"
  },
  hideButton: {
    // "pointer-events": "none",
    cursor: "not-allowed",
    backgroundColor: "#e0e0e0",
    color: "blue",
    disabled: "disabled",
    '&:hover': {
      cursor: "not-allowed",
      backgroundColor: "#e0e0e0",
      color: "blue",
      disabled: "disabled",
      // color: "black",
    }
    // overflow: "hidden",
    // cursor: "pointer",
    // visibility:"hidden",
    // display:"none"

    // disabled: "disabled"
  },
  text: {
    margin: "0.5rem",
    marginTop: "0.7rem"
  },
  pageNavBtn: {
    minWidth: "55px",
    margin: "0 5px"
  },
  radioButton: {
    flexDirection: "row"
  },

}));

export const getParams = () => {
  return (
    Params
  )
}

const Params = []
function Pagination({
  items,
  onChangePage,
  ExportData,
  fetchResultsOnPageChange,
  metadata,
  fetchResultsOnExportExcel,
  exportSearchParams,
  clearAllFilters,
  handleResultFilterChange,
  errorDetails,
  handleError
}) {
  const classes = useStyles();
  let _counter = 0;

  let itemList = {};
  let exportName = "LOADING EXPORT";
  let { resetfilter } = errorDetails

  if ("" + metadata.excelData !== "undefined" && metadata.excelData.length > 0) {
    exportName = "EXPORT RESULTS"

  }
  if (metadata.isHeavyData)
    exportName = "UNABLE TO LOAD"
  if (items == undefined) items = [];
  const [state, setState] = React.useState({
    initialPage: 1,
    noOfItems: 0,
    start: 0,
    count: 50,
    addNew: true
    // searchParamsExport: []
  });
  const [valueOfMPIN, setvalueOfMPIN] = React.useState("All");
  const [valueOfTaxId, setvalueOfTaxId] = React.useState("All");
  const [valueOfAddress, setvalueOfAddress] = React.useState("All");
  const [pageNo, setPageNo] = React.useState(1);
  const [largeData, setLargeData] = React.useState(false);
  const [isExportDataAvailable, setIsExportDataAvailable] = React.useState(false);
  // const [searchParamsExport, setSearchParamsExport] = React.useState([]);
  useEffect(() => {
    if (items.length && items.length > 0 && !metadata.searchParams.isHeaderFilterApplied) {
      setPage(state.initialPage)
      setState({ ...state, addNew: false })
    }
  }, [items]);
  // console.log(" excelSearchParams ACTION ==== ", metadata.excelSearchParams.action)

  useEffect(() => {
    if (!isExportDataAvailable) {
      setIsExportDataAvailable(true)
      setTimeout(() => {
        handleOnExportExcelValues()
      }, 100);
    }
    if (metadata.excelSearchParams.action == "filter") {
      setTimeout(() => {
        handleOnExportExcelValues()
      }, 100);
    }
  }, [ExportData[0].data.length === 0 || metadata.excelSearchParams.action == "filter"]);
  // useEffect(() => {
  //   setTimeout(() => {
  //     console.log("22222222222")
  //     handleOnExportExcelValues()
  //   }, 100);
  // }, [metadata.excelSearchParams.action == "filter"]);



  useEffect(() => {
    if (resetfilter === true) {
      setvalueOfMPIN("All");
      setvalueOfTaxId("All");
      setvalueOfAddress("All");
      handleError('resetfilter', false)
    }
  }, [resetfilter])

  // console.log("Metadata here ===== ", ExportData)
  // console.log("Metadata here ===== ", ExportData[0].columns)
  // console.log("Metadata here ===== ", ExportData[0].data.length)
  // console.log("Metadata PAGINATION here ===== ", metadata)
  const handleNextValues = () => {
    let searchParams = metadata.searchParams;
    for (var key in searchParams) {
      if (key == "start") {
        searchParams[key] = parseInt(searchParams[key] + 50);
      }
      if (key == "exCount") {
        searchParams[key] = "0";
      }
      if (key == "action") {
        searchParams[key] = "nextpage";
      }
    }
    setPageNo(pageNo + 1);
    if (metadata.metadata.offset == 4950) setLargeData(true);
    fetchResultsOnPageChange(searchParams);
    setvalueOfMPIN("All");
    setvalueOfTaxId("All");
    setvalueOfAddress("All");
    metadata.searchParams.isHeaderFilterApplied = false;
    clearAllFilters()
  };
  const handleOnExportExcelValues = () => {
    let searchParams = metadata.excelSearchParams;
    if (searchParams !== undefined) {
      for (var key in searchParams) {
        if (key == "exStart") {
          searchParams[key] = parseInt(0);
        }
        if (key == "exCount") {
          searchParams[key] = parseInt(5000);
        }
        if (key == "action") {
          searchParams[key] = "scroll";
        }
      }
      fetchResultsOnExportExcel(searchParams);
    }
  };

  function handleOnExportExcelLogs() {
    // console.log("Metadata here ===== ", metadata.excelSearchParams)
    let searchParams = metadata.excelSearchParams;
    if (searchParams !== undefined) {
      for (var key in searchParams) {
        if (key == "exStart") {
          searchParams[key] = parseInt(0);
        }
        if (key == "exCount") {
          searchParams[key] = parseInt(0);
        }
        if (key == "action") {
          searchParams[key] = "export";
        }
      }
      searchParams["totalCount"] = metadata.excelMetadata.total;
      searchParams["responseTime"] = metadata.excelMetadata.responseTime;
      fetchResultsOnExportExcel(searchParams);
    }
  }

  const handlePageInputValue = (event) => {
    if (event.key === 'Enter' && event.target.value != '') {
      let searchParams = metadata.searchParams;
      let multiPlier = parseInt(event.target.value)
      let actionData = "nextpage"
      if (multiPlier < pageNo)
        actionData = "prepage"
      if (pageNo != multiPlier) {
        if (multiPlier > 100 || multiPlier > Math.ceil(metadata.metadata.total / 50) || multiPlier <= 0) {
          window.location.reload(false)
        }
        else {
          for (var key in searchParams) {
            if (key == "start") {
              searchParams[key] = parseInt(multiPlier * 50 - 50);
            }
            if (key == "exCount") {
              searchParams[key] = "0";
            }
            if (key == "action") {
              searchParams[key] = actionData;
            }
          }
          setPageNo(multiPlier);
          if (metadata.metadata.offset == 4950) setLargeData(true);
          fetchResultsOnPageChange(searchParams);
          setvalueOfMPIN("All");
          setvalueOfTaxId("All");
          setvalueOfAddress("All");
          metadata.searchParams.isHeaderFilterApplied = false;
          clearAllFilters()
        }
      }
    }
  }
  const handlePreviousValues = () => {
    let searchParams = metadata.searchParams;
    for (var key in searchParams) {
      if (key == "start") {
        searchParams[key] = parseInt(searchParams[key] - 50);
      }
      if (key == "exCount") {
        searchParams[key] = "0";
      }
      if (key == "action") {
        searchParams[key] = "prepage";
      }
    }
    setPageNo(pageNo - 1);
    setLargeData(false);
    fetchResultsOnPageChange(searchParams);
    setvalueOfMPIN("All");
    setvalueOfTaxId("All");
    setvalueOfAddress("All");
    metadata.searchParams.isHeaderFilterApplied = false;
    clearAllFilters()
  };

  let setPage = page => {
    let pageOfItemsFormatted = responsePojo(items, metadata.searchParams);
    let getAddressListFormatted = getAddressList(items);
    let primaryAddressIndicator = getprimaryAddressIndicatorFun(items);
    let billSequenceFun = billSequenceList(items)
    let mpinListFun = mpinList(items)
    let mpinTypeListFun = mpinTypeList(items)
    let npiListFun = npiList(items)
    let taxIdTypeListFun = taxIdTypeList(items)
    let prefixSuffixListFun = prefixSuffixList(items)
    let providerNameListFun = providerNameList(items)
    let addressAndTelephoneListFun = addressAndTelephoneList(items, metadata.searchParams)
    let uhcidInfoFun = uhcidInfoList(items, metadata.searchParams)
    setState({
      ...state,
      noOfItems: items.length
    });
    const x = state;

    itemList = {
      pageOfItemsFormatted: pageOfItemsFormatted,
      staticPageOfItems: items,
      getAddressListFormatted: getAddressListFormatted,
      primaryAddressIndicator: primaryAddressIndicator,
      billSequenceFun: billSequenceFun,
      mpinListFun: mpinListFun,
      mpinTypeListFun: mpinTypeListFun,
      npiListFun: npiListFun,
      taxIdTypeListFun: taxIdTypeListFun,
      prefixSuffixListFun: prefixSuffixListFun,
      providerNameListFun: providerNameListFun,
      addressAndTelephoneListFun: addressAndTelephoneListFun,
      uhcidInfoFun: uhcidInfoFun
    };
    onChangePage(itemList);
  };

  //converting a number to number with commas for every 3 digits
  function numberWithCommas(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  }

  const toggle = () => {
    setState({ ...state, isOpen: !state.isOpen });
    setvalueOfMPIN("All");
    setvalueOfTaxId("All");
    setvalueOfAddress("All");
    handleResultFilterChange('MPIN', 'All', 'TAXID', 'All', 'ADDRESS', 'All')
    clearAllFilters()
  };
  const handleChangeForMPIN = event => {
    setvalueOfMPIN(event.target.value);
    const Mpin = event.target.value;
    handleResultFilterChange('MPIN', Mpin, 'TAXID', valueOfTaxId, 'ADDRESS', valueOfAddress)
  };
  const handleChangeForTaxId = event => {
    setvalueOfTaxId(event.target.value);
    const TaxId = event.target.value;
    handleResultFilterChange('MPIN', valueOfMPIN, 'TAXID', TaxId, 'ADDRESS', valueOfAddress)
  };
  const handleChangeForAddress = event => {
    setvalueOfAddress(event.target.value);
    const AddressValue = event.target.value;
    handleResultFilterChange('MPIN', valueOfMPIN, 'TAXID', valueOfTaxId, 'ADDRESS', AddressValue)
  };
  const handleClick = () => {
    setvalueOfAddress("All")
    setvalueOfMPIN("All")
    setvalueOfTaxId("All")
    clearAllFilters()
  }
  function getDateTimeString() {
    var d = new Date();
    d.setUTCHours(d.getUTCHours() - 6);
    return d.getUTCMonth() + 1 + '-' +
      d.getUTCDate() + '-' +
      d.getUTCFullYear() + '_' +
      ((d.getUTCHours() % 12) || 12) + ':' +
      ('0' + d.getUTCMinutes()).slice(-2) + '' +
      (d.getUTCHours() < 12 ? 'AM' : 'PM');
    // var timeString = new Date().getHours() + ":" + new Date().getMinutes();
    // var date = new Date();
    // var H = +timeString.substr(0, 2);

    // var h = H % 12 || 12;
    // if (h.toString().length == 1) h = "0" + h;
    // var ampm = H < 12 ? "AM" : "PM";
    // timeString =
    //   h +
    //   (timeString.substr(2, 3).length == 2 ? "0" : "") +
    //   timeString.substr(2, 3) +
    //   ampm;
    // var datePart =
    //   (date.getMonth().toString().length == 1 ? "0" : "") +
    //   date.getMonth() +
    //   "-" +
    //   (date.getDate().toString().length == 1 ? "0" : "") +
    //   date.getDate() +
    //   "-" +
    //   date.getFullYear();
    // return datePart + "_" + timeString;
  }
  const filename = "ABLE Search Results_" + getDateTimeString() + "_CST";
  return (
    <React.Fragment>
      <div className={classes.root}>
        {/* <div
        className={
          isDisplayPagination ? classes.subRootNone : classes.subRoot
        }
      >
        <Typography component="span" className={classes.text}>
          Displaying
        </Typography>
          <FormControl style={{marginTop:"-6px"}} variant="outlined">
          <Select
            id="items-per-page-dropdown"
            value={itemsPerPage}
            onChange={onRowsPerPageChange}
            classes={{ outlined: classes.inputPad }}
            IconComponent={KeyboardArrowDownIcon}
          >
            {getOddOption(itemsPerPage, itemsPerPageOptions)}
            {itemsPerPageOptions.map(len => (
              <MenuItem key={len} value={len}>
                {len}
              </MenuItem>
            ))}
          </Select>
        </FormControl> 
        <Typography component="span" className={classes.text}> 
          of {totalRows}
        </Typography>
        </div> */}
        <div style={{ marginTop: 20 }}>
          <Typography component="span" className={classes.text}>
            Displaying {parseInt(metadata.metadata.offset + 1) + "-"}
            {parseInt(metadata.metadata.offset + 50) >= parseInt(metadata.metadata.total) ? parseInt(metadata.metadata.total) : parseInt(metadata.metadata.offset + 50)}
            &nbsp;of {metadata.metadata.total >= 5000 ? "5,000" : numberWithCommas(parseInt(metadata.metadata.total))}
          </Typography>
          {/* <Typography component="span" className={classes.text}>
            {parseInt(metadata.metadata.offset + 1) + " - "
              //parseInt(metadata.metadata.offset + 50) >= parseInt(metadata.metadata.total)?parseInt(metadata.metadata.total):parseInt(metadata.metadata.offset + 50)
            }{parseInt(metadata.metadata.offset + 50) >= parseInt(metadata.metadata.total) ? parseInt(metadata.metadata.total) : parseInt(metadata.metadata.offset + 50)}
            
          </Typography> */}
          {/* <OutlinedInput
            classes={{ input: classes.inputPad }}
            value={
              parseInt(metadata.metadata.offset + 1) + " - " + parseInt(metadata.metadata.offset)
            }
            // value={
            //   metadata.searchParams.start + 50 > metadata.metadata.total
            //     ? numberWithCommas(parseInt(metadata.metadata.total))
            //     : numberWithCommas(parseInt(metadata.searchParams.start + 50))
            // }
            disabled
          /> */}
          {/* <Typography component="span" className={classes.text}>
            of {metadata.metadata.total >= 5000 ? "5,000" : numberWithCommas(parseInt(metadata.metadata.total))}
          </Typography> */}
        </div>
        <div className={classes.gap}>
          <div
            style={{ textAlign: "center", marginTop: "20px", marginLeft: 0 }}
          >
            {"" + metadata.excelData === "undefined" || metadata.excelData.length <= 0 ?
              <Button
                variant="contained"
                color="primary"
                size="small"
                className={"" + exportName == "LOADING EXPORT" || metadata.isHeavyData ? classes.hideButton : ""}
                startIcon={metadata.isHeavyData ? <ErrorOutlineIcon />  : <CloudDownloadIcon />}
              >
                {exportName}
              </Button>
              : <ExcelFile
                filtered={true}
                filename={filename}
                style={{ paddingRight: 10 }}
                element={
                  <Button
                    variant="contained"
                    color="primary"
                    size="small"
                    className={"" + exportName == "LOADING EXPORT" ? classes.hideButton : ""}
                    startIcon={<CloudDownloadIcon />}
                    onClick={handleOnExportExcelLogs}
                  >
                    {exportName}
                  </Button>
                }
              >

                <ExcelSheet
                  dataSet={ExportData}
                  name="MPIN-TIN-Address"
                  filtered={true}
                />

                <ExcelSheet
                  name="Search Parameters"
                  dataSet={exportSearchParams}
                />

              </ExcelFile>
            }
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <Button
              variant="contained"
              color="secondary"
              size="small"
              className={classes.button}
              onClick={handleClick}
              style={{ backgroundColor: "#e73232" }}
            >
              CLEAR ALL FILTERS
            </Button>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <Button
              variant="contained"
              //color="primary"
              style={{ color: "blue" }}
              size="small"
              className={classes.button}
              startIcon={<ListIcon />}
              onClick={toggle}
            >
              Result Options
            </Button>
          </div>
        </div>
        <div
          style={{
            display: state.isOpen ? "block" : "none",
            alignContent: "center"
          }}
        >
          <Card style={{ width: 400 }}>
            <FormControl component="fieldset" style={{ marginLeft: 55 }}>
              <span style={{ display: "flex", height: 25 }}>
                <FormLabel style={{ lineHeight: 3, marginRight: 20 }}>
                  MPIN
                </FormLabel>
                <RadioGroup
                  aria-label="MPIN"
                  name="MPIN1"
                  value={valueOfMPIN}
                  onChange={handleChangeForMPIN}
                  row
                >
                  <FormControlLabel
                    value="All"
                    control={<Radio size="small" color="default" />}
                    label="All"
                  />
                  <FormControlLabel
                    value="A"
                    control={<Radio size="small" color="default" />}
                    label="Active"
                  />
                  <FormControlLabel
                    value="I"
                    control={<Radio size="small" color="default" />}
                    label="Inactive"
                  />
                </RadioGroup>
              </span>
              <span style={{ display: "flex", height: 25 }}>
                <FormLabel style={{ lineHeight: 3, marginRight: 20 }}>
                  TaxID
                </FormLabel>
                <RadioGroup
                  aria-label="TaxID"
                  name="TaxID1"
                  value={valueOfTaxId}
                  onChange={handleChangeForTaxId}
                  row
                >
                  <FormControlLabel
                    value="All"
                    control={<Radio size="small" color="default" />}
                    label="All"
                  />
                  <FormControlLabel
                    value="A"
                    control={<Radio size="small" color="default" />}
                    label="Active"
                  />
                  <FormControlLabel
                    value="I"
                    control={<Radio size="small" color="default" />}
                    label="Inactive"
                  />
                </RadioGroup>
              </span>
              <span style={{ display: "flex", height: 27 }}>
                <FormLabel style={{ lineHeight: 3, marginRight: 5 }}>
                  Address
                </FormLabel>
                <RadioGroup
                  aria-label="Address"
                  name="Address1"
                  value={valueOfAddress}
                  onChange={handleChangeForAddress}
                  row
                  id="rbtn-address"
                >
                  <FormControlLabel
                    value="All"
                    control={<Radio size="small" color="default" />}
                    label="All"
                  />
                  <FormControlLabel
                    value="A"
                    control={<Radio size="small" color="default" />}
                    label="Active"
                  />
                  <FormControlLabel
                    value="I"
                    control={<Radio size="small" color="default" />}
                    label="Inactive"
                  />
                </RadioGroup>
              </span>
            </FormControl>
          </Card>
        </div>
        <div
        //   className={
        //     isDisplayPagination ? classes.subRootNone : classes.subRoot
        //   }
        >

          <div style={{ marginTop: 20 }}>
            <Typography component="span" className={classes.text}>
              Page
            </Typography>
            <OutlinedInput
              classes={{ input: classes.inputPad }}
              // value={pageNo}
              defaultValue={pageNo}
              onKeyPress={handlePageInputValue}
              key={pageNo}
            // error={state.inputError}
            // onChange={onPageInputChange}
            />
            <Typography component="span" className={classes.text}>
              of{" "}
              {metadata.metadata.total >= 5000 ? "100" : parseInt(Math.ceil(metadata.metadata.total / 50))}
            </Typography>
            <Button
              variant="outlined"
              color="primary"
              disabled={pageNo === 1 || metadata.metadata.offset == 0 ? true : false}
              className={classes.pageNavBtn}
              onClick={handlePreviousValues}
            >
              <ChevronLeftIcon />
            </Button>
            <Button
              variant="outlined"
              color="primary"
              disabled={
                Math.ceil(metadata.metadata.total / 50) == pageNo || largeData || metadata.metadata.total < 50
                  ? true
                  : false
              }
              className={classes.pageNavBtn}
              onClick={handleNextValues}
            >
              <ChevronRightIcon />
            </Button>
          </div>
        </div>
      </div>
    </React.Fragment>
  );
}

Pagination.propTypes = {
  clearAllFilters: PropTypes.func,
  fetchResultsOnPageChange: PropTypes.func,
  fetchResultsOnExportExcel: PropTypes.func,
  handleResultFilterChange: PropTypes.func
};

export default Pagination;
