// import e from "express";

/* eslint-disable */
const addZerosforSuffix = (value) => {
  if (value.length !== 0) {
    for (let i = value.length; i < 5; i++) {
      value = '0' + value;
    }
    return value
  }
}
const addZerosforAddressId = (value) => {
  if (value.length !== 0) {
    for (let i = value.length; i < 9; i++) {
      value = '0' + value;
    }
    return value
  }
}
const addZerosForSequence = (value) => {
  if (value.length !== 0) {
    for (let i = value.length; i < 4; i++) {
      value = '0' + value;
    }
    return value
  }
}

const responsePojo = (list, params) => {
  // debugger
  // console.log("LIST in POJO  === ", list);
  let paramsNPI
  let paramsUhcid
  let valueparamsZIP
  if (params !== undefined) {
    paramsNPI = params.npi
    paramsUhcid = params.uhcid
    valueparamsZIP = params.paramsZI
  }
  let provider = list;
  let final = [];
  let _counter = 0;

  //a.adr_id == x.adr_id ||
  //a.tax_id_nbr == x.tax_id_nbr
  //a.prov_id == x.prov_id
  // console.log(" Without Unique Array", list.length);
  // const unique = [];
  // list.map(x =>
  //   unique.filter(a => a.adr_id == x.adr_id).length > 0 ? null : unique.push(x)
  // );
  // console.log("unique Array Length ", unique.length);
  provider.map((obj, index) => {
    // console.log("XXXXXXXXXXXXXXX", obj);
    _counter = _counter + 1;
    let providerId = obj.prov_id;
    let activeCode = obj.providerinformation[0].mpin_flag;
    let primaryDegreeCode = obj.providerinformation[0].deg_cd === undefined ? "" : obj.providerinformation[0].deg_cd;
    let suffix = obj.providerinformation[0].nm_sufx_cd;
    let comma = obj.providerinformation[0].prov_typ_cd == "P" ? ", " : " ";
    let space = obj.providerinformation[0].nm_sufx_cd ? " " : ""
    var name =
      obj.providerinformation[0].lst_nm + " " +
      suffix +
      comma +
      obj.providerinformation[0].fst_nm +
      " " +
      obj.providerinformation[0].mdl_nm;
    var quickviewlastname = "";
    if (obj.providerinformation[0].mdl_nm == "") {
      quickviewlastname = "";
    } else {
      quickviewlastname = ", ";
    }
    var qname =
      obj.providerinformation[0].fst_nm +
      "  " +
      obj.providerinformation[0].mdl_nm +
      "  " +
      obj.providerinformation[0].lst_nm
      + space + suffix;

    let npiinfoObj = obj.providerinformation[0].npiinfo;
    let npiFlag = ''
    let npi = obj.providerinformation[0].current_npi;
    npiFlag = "A"
    if (npi == 0) {
      if (npiinfoObj !== undefined && npiinfoObj.length > 0) {
        npi = npiinfoObj[0].npi_id
        npiFlag = npiinfoObj[0].prov_npi_flag
      }
    }
    let additionalNpiFlag = ""
    if (npiinfoObj !== undefined && npiinfoObj.length > 0) {
      if (npiinfoObj.length > 1) {
        const countActive = npiinfoObj.filter((obj) => obj.prov_npi_flag === "A").length;
        const countInactive = npiinfoObj.filter((obj) => obj.prov_npi_flag === "I").length;
        if (countInactive >= 1) {
          additionalNpiFlag = "N"
        }
        else if (countActive >= 1) {
          additionalNpiFlag = "Y"
        }
        else {
          additionalNpiFlag = ""
        }
      }
    }
    if (paramsNPI !== '') {
      npi = paramsNPI
    }
    let mpin = obj.prov_id;
    let cosmosContractStatus = obj.taxidinfo[0].cos_prdct_cd;
    let cspContractStatus = "";
    let providerFound = final.findIndex(s => s.providerId == providerId);
    let unetContractStatus = "I"; //obj.taxidinfo[0].unet_prdct_cd;
    let gender = obj.providerinformation[0].prov_gdr_cd;
    let mpinType = obj.providerinformation[0].mpin_type;
    let mpinTypeDescription = obj.providerinformation[0].mpin_type_desc;
    let pcpSpec = obj.providerinformation[0].prov_spec_ind;
    let dob = obj.providerinformation[0].prov_bth_dt;
    let services = obj.providerinformation[0].services;
    let ssn = obj.providerinformation[0].soc_secur_nbr;
    // console.log("providerFound ====== ", providerFound);
    if (providerFound >= 0) {
      // final
      // .find(s => s.providerId == providerId)
      // .professionalInformation.push(obj.professionalInformation);
      final.map(s => {
        if (s.providerId === providerId) {
          s.providerinformation.push(obj);
        }
      });
    } else {
      final.push({
        gender: gender,
        name: name,
        qname: qname,
        activeCode: activeCode,
        providerId: providerId,
        providerinformation: new Array(obj),
        taxIdStatus: "",
        mpin: mpin,
        npi: npi,
        additionalNpiFlag: additionalNpiFlag,
        cosmosContractStatus: cosmosContractStatus,
        cspContractStatus: cspContractStatus,
        unetContractStatus: unetContractStatus,
        mpinType: mpinType,
        mpinTypeDescription: mpinTypeDescription,
        pcpSpec: pcpSpec,
        dob: dob,
        services: services,
        ssn: ssn,
        primaryDegreeCode: primaryDegreeCode,
        npiFlag: npiFlag,
        addressDetails: new Array()
      });
    }
  });
  // console.log("Before sorting Final Array ", final);
  final = sortByKeyPagi(final, "name");
  // console.log("AFTER sorting Final Array ", final);
  final.map((obj1, index) => {
    obj1.providerinformation.map((adInfo, i) => {
      let taxtId = addZerosforAddressId(adInfo.tax_id_nbr.toString());
      let isTextIdVisible = true;
      let taxtIdTypeCode = adInfo.tax_id_typ_cd;
      let taxIdStatus = adInfo.taxidinfo[0].mpin_tin_flag;
      let corpStatus = adInfo.taxidinfo[0].corp_mpin_act_flag == "A" || adInfo.taxidinfo[0].corp_mpin_act_flag == "I" ? adInfo.taxidinfo[0].corp_mpin_act_flag : ""
      let corpMpin = adInfo.taxidinfo[0].corp_ownr_prov_id !== undefined ? adInfo.taxidinfo[0].corp_ownr_prov_id : "";
      let corpMpinName = adInfo.taxidinfo[0].corp_mpin_name !== undefined ? adInfo.taxidinfo[0].corp_mpin_name : "";
      let ptiStatus = adInfo.taxidinfo[0].pti_mpin_act_flag == "A" || adInfo.taxidinfo[0].pti_mpin_act_flag == "I" ? adInfo.taxidinfo[0].pti_mpin_act_flag : "";
      let ptiIndicator = adInfo.taxidinfo[0].pay_typ_cd !== undefined ? adInfo.taxidinfo[0].pay_typ_cd : "";
      let ptiMpin = adInfo.taxidinfo[0].paye_prov_id !== undefined ? adInfo.taxidinfo[0].paye_prov_id : "";
      let ptiMpinName = adInfo.taxidinfo[0].pti_mpin_name !== undefined ? adInfo.taxidinfo[0].pti_mpin_name : "";


      // obj1.addressDetails.map(txObj=>{
      //   if(taxtId === txObj.taxtId)
      // })

      let textIdFound = obj1.addressDetails.findIndex((t) => {
        if (parseInt(t.taxtId) === parseInt(taxtId) && t.taxtIdTypeCode == taxtIdTypeCode) {
          return true
        } else return false
      }
      );
      if (textIdFound >= 0) {
        isTextIdVisible = false
      }
      let addressObj = {};
      let addressInfoData = adInfo.addressinfo;
      if (addressInfoData.length > 1) {
        addressInfoData = addressInfoData.filter(adObj => adObj.address_flag === "A");
        if (addressInfoData.length <= 0)
          addressInfoData = adInfo.addressinfo
      }
      let isAddressIdVisible = true;
      let corpOwnerFlag = ""
      if (adInfo.prov_id == adInfo.taxidinfo[0].corp_ownr_prov_id) {
        corpOwnerFlag = "Y"
      }
      else {
        corpOwnerFlag = "N"
      }
      let postaladdressinfo = addressInfoData[0].postaladdressinfo;
      let telephoneObj
      let telephoneinfo = addressInfoData[0].telephoneinfo;
      if (params.telephone !== "") {
        telephoneObj = telephoneinfo.filter(teleObj => teleObj.tel_nbr === params.telephone)
      } else {
        telephoneObj = telephoneinfo.filter(teleObj => teleObj.pri_cd === "P")
      }

      let quickviewAddressInfo = {
        bill_zip_pls_4_cd: addressInfoData[0].bill_postal_information.bill_zip_pls_4_cd !== undefined ? addressInfoData[0].bill_postal_information.bill_zip_pls_4_cd : "",
        bill_seq_num: addressInfoData[0].bill_postal_information.bill_seq_num !== undefined ? addressInfoData[0].bill_postal_information.bill_seq_num : "",
        bill_cty_nm: addressInfoData[0].bill_postal_information.bill_cty_nm !== undefined ? addressInfoData[0].bill_postal_information.bill_cty_nm : "",
        bill_adr_eff_dt: addressInfoData[0].bill_postal_information.bill_adr_eff_dt !== undefined ? addressInfoData[0].bill_postal_information.bill_adr_eff_dt : "",
        bill_adr_ln_1_txt: addressInfoData[0].bill_postal_information.bill_adr_ln_1_txt !== undefined ? addressInfoData[0].bill_postal_information.bill_adr_ln_1_txt : "",
        bil_adr_typ: addressInfoData[0].bill_postal_information.bil_adr_typ !== undefined ? addressInfoData[0].bill_postal_information.bil_adr_typ : "",
        bill_telephoneinfo: addressInfoData[0].bill_postal_information.bill_telephoneinfo !== undefined ? addressInfoData[0].bill_postal_information.bill_telephoneinfo : [],
        bill_st_cd: addressInfoData[0].bill_postal_information.bill_st_cd !== undefined ? addressInfoData[0].bill_postal_information.bill_st_cd : "",
        bill_adr_canc_dt: addressInfoData[0].bill_postal_information.bill_adr_canc_dt !== undefined ? addressInfoData[0].bill_postal_information.bill_adr_canc_dt : "",
        bill_adr_act_flag: addressInfoData[0].bill_postal_information.bill_adr_act_flag !== undefined ? addressInfoData[0].bill_postal_information.bill_adr_act_flag : "",
        bill_zip_cd: addressInfoData[0].bill_postal_information.bill_zip_cd ? addressInfoData[0].bill_postal_information.bill_zip_cd : "",
        bill_address_flag: addressInfoData[0].bill_postal_information.bill_address_flag ? addressInfoData[0].bill_postal_information.bill_address_flag : "",
        bil_adr_id: addressInfoData[0].bill_postal_information.bil_adr_id ? addressInfoData[0].bill_postal_information.bil_adr_id : "",
      }
      //addressInfoData[0].bill_postal_information;
      let quickViewTelephoneObj = [];
      let teleinfo = quickviewAddressInfo.bill_telephoneinfo;
      quickViewTelephoneObj = teleinfo.filter(teleObj => teleObj.pri_cd === "P")
      if (quickViewTelephoneObj.length <= 0)
        quickViewTelephoneObj = teleinfo[0]

      let addressMasterType = addressInfoData[0].address_type_flag;
      let addressId = addZerosforAddressId(adInfo.adr_id.toString());
      let addressIdFound = obj1.addressDetails.findIndex(
        t => t.addressinfo.addressId === addressId
      );
      if (addressIdFound >= 0) {
        isAddressIdVisible = false
      }
      let addressTypeCode = adInfo.adr_typ_cd;
      let epqAddressSequence = addZerosForSequence(addressInfoData[0].epd_addr_seq.toString());
      let addressIndicator = addressInfoData[0].pri_cd;
      let addressCorrespondence = addressInfoData[0].corsp_adr_ind;

      //let corspAddressType = addressInfoData[0].corsp_adr_ind;
      let cosmosStatus = adInfo.taxidinfo[0].cos_prdct_cd;
      let topsTinPrefix = addressInfoData[0].tops_tin_prfx_cd;
      let topsTinSuffix = addZerosforSuffix(addressInfoData[0].tops_tin_sufx_cd.toString());
      let billSequence = addressInfoData[0].bill_postal_information.bill_seq_num != undefined ? addZerosForSequence(addressInfoData[0].bill_postal_information.bill_seq_num.toString()) : "";
      let addressStatus = addressInfoData[0].address_flag;
      let billAddressId = addZerosforAddressId(quickviewAddressInfo.bil_adr_id.toString());
      let unetContractStatus = ""
      let uhcidInfo = ''
      let additionalUhcidFlag = ''
      let uhcidFlag = ''
      if (paramsUhcid !== '' && paramsUhcid !== undefined) {
        let uhcidInfoObj = addressInfoData[0].uhcidinfo
        if (uhcidInfoObj !== undefined && uhcidInfoObj.length > 0) {
          const countActive = uhcidInfoObj.filter((obj) => obj.uhcid_flag === "A").length;
          const countInactive = uhcidInfoObj.filter((obj) => obj.uhcid_flag === "I").length;
          let info = uhcidInfoObj.filter(item => item.uhc_id.includes(paramsUhcid.toUpperCase()));
          if (paramsUhcid.length == 4) {
            info = uhcidInfoObj.filter(item => item.uhc_id.substr(0, 4).includes(paramsUhcid));
          }
          if (info.length >= 1) {
            let active = info.filter(item => item.uhcid_flag === "A")
            if (active.length >= 1) {
              uhcidInfo = active[0].uhc_id
              uhcidFlag = active[0].uhcid_flag
              if (countInactive >= 1) {
                additionalUhcidFlag = "N"
              }
              if (countActive > 1) {
                additionalUhcidFlag = "Y"
              }
            }
            else {
              let inactive = info.filter(item => item.uhcid_flag === "I")
              if (inactive.length >= 1) {
                uhcidInfo = inactive[0].uhc_id
                uhcidFlag = inactive[0].uhcid_flag
              }
              if (inactive.length >= 1 && countInactive > 1) {
                additionalUhcidFlag = "N"
              }
            }

          }
          // if (paramsUhcid.length > 14) {
          //   let info = uhcidInfoObj.filter(item => item.uhc_id == paramsUhcid);
          //   if (info.length >= 1) {
          //     uhcidInfo = info[0].uhc_id
          //   }
          // }
        }


      }
      obj1.addressDetails.push({
        counter: ++i,
        isTextIdVisible: isTextIdVisible,
        taxtId: taxtId,
        taxIdStatus: taxIdStatus,
        taxtIdTypeCode: taxtIdTypeCode,
        corpStatus: corpStatus,
        corpMpin: corpMpin,
        corpMpinName: corpMpinName,
        ptiStatus: ptiStatus,
        ptiIndicator: ptiIndicator,
        ptiMpin: ptiMpin,
        ptiMpinName: ptiMpinName,
        corpOwnerFlag: corpOwnerFlag,
        addressinfo: {
          addressMasterType: addressMasterType,
          isAddressIdVisible: isAddressIdVisible,
          addressId: addressId,
          addressTypeCode: addressTypeCode,
          epqAddressSequence: epqAddressSequence,
          addressIndicator: addressIndicator,
          addressCorrespondence: addressCorrespondence,
          cosmosStatus: cosmosStatus,
          unetContractStatus: unetContractStatus,
          postaladdressinfo: postaladdressinfo,
          telephoneObj: telephoneObj[0],
          topsTinPrefix: topsTinPrefix,
          topsTinSuffix: topsTinSuffix,
          billSequence: billSequence,
          billAddressId: billAddressId,
          addressStatus: addressStatus,
          uhcidInfo: uhcidInfo,
          additionalUhcidFlag: additionalUhcidFlag,
          uhcidFlag: uhcidFlag,
          quickviewAddressInfo: quickviewAddressInfo,
          quickViewTelephoneObj: quickViewTelephoneObj !== undefined ? quickViewTelephoneObj[0] : []
        }
      });

    });
  });

  if (list.length > 0) delete final[0].providerinformation;
  // console.log("Array Length ===== final ", final);
  return final;
};

const sortByKeyPagi = (array, key) => {
  return array.sort(function (a, b) {
    var x = a[key];
    var y = b[key];

    if (typeof x == "string") {
      x = ("" + x).toLowerCase();
    }
    if (typeof y == "string") {
      y = ("" + y).toLowerCase();
    }

    return x < y ? -1 : x > y ? 1 : 0;
  });
};

export default responsePojo;

//a.adr_id == x.adr_id ||
    //a.tax_id_nbr == x.tax_id_nbr
    //a.prov_id == x.prov_id
    // console.log(" Without Unique Array", list);
    //  const unique = [];
    // list.map(x =>
    //   unique.filter(a => a.adr_id == x.adr_id || a.tax_id_nbr == x.tax_id_nbr).length > 0 ? null : unique.push(x)
    // );
    // console.log("unique Array Length ", unique);



     // console.log("************PPPPPPPP ******************");
    // console.log(provider)
    // if (items.length < 50) provider.splice(provider.length - 1, 1);
    // console.log(provider)
    // console.log("******************************");



    // let telePhoneHandleSearch;
        // if (localStorage.getItem("BySerach") == "yes") {
        //   telePhoneHandleSearch = getTeleStatusType("Y", "Search");
        // } else {
        //   telePhoneHandleSearch = getTeleStatusType("N", "Tabel");
        // }
        //     let _phones;
        //     if (telePhoneHandleSearch == "Yes") {
        //       _phones = adInfo.phone.find(num => num.areaCode && num.phoneNumber);
        //     } else {
        //       _phones = adInfo.phone.find(
        //         num =>
        //           num.activeIndicator === "A" &&
        //           num.primaryTelephoneIndicator === "P"
        //       );
        //     }
        //     adInfo.addressobj = { address: adInfo.address, phone: _phones };
        //   });
        //   obj1.professionalInformation = obj1.professionalInformation.sort(
        //     (a, b) => {
        //       var nameA = a.addressobj.address.addressTypeCode,
        //         nameB = b.addressobj.address.addressTypeCode;
        //       if (nameA < nameB) return -1;
        //       if (nameA > nameB) return 1;
        //       return 0;
        //     }
        //   );
        //   obj1.professionalInformation = obj1.professionalInformation.sort(
        //     (a, b) => {
        //       var nameA = a.taxId.taxId,
        //         nameB = b.taxId.taxId;
        //       if (nameA < nameB) return -1;
        //       if (nameA > nameB) return 1;
        //       return 0;
        //     }
        //   );
        //   var taxId = "";
        //   var grey = "Y";
        //   var taxIdStatus = "Y";
        //   var taxIdTypeString = "",
        //     addressString = "",
        //     prefixSuffixString = "",
        //     addressTypeString = "",
        //     phoneString = "";
        //   obj1.professionalInformation.map((add, i) => {
        //     _counter = _counter + 1;
        //     Object.assign(add, { counter: _counter });
        //     if (taxId == add.taxId.taxId) {
        //       add.taxId.isVisible = false;
        //     } else {
        //       add.taxId.isVisible = true;
        //       taxId = add.taxId.taxId;
        //     }