
/* eslint-disable */
import React from "react";
import PropTypes from "prop-types";
import { useHistory } from "react-router-dom";
import { makeStyles, withStyles } from "@material-ui/core/styles";
import Breadcrumbs from "@material-ui/core/Breadcrumbs";
import NavigateNextIcon from "@material-ui/icons/NavigateNext";
import Link from "@material-ui/core/Link";
import Button from "@material-ui/core/Button";
import Chip from "@material-ui/core/Chip";
import ClearIcon from "@material-ui/icons/Clear";
import FormControl from "@material-ui/core/FormControl";
import Select from "@material-ui/core/Select";
import Typography from "@material-ui/core/Typography";
import InputBase from "@material-ui/core/InputBase";
import fieldList from "../../utils/fields.constant";
import InputLabel from '@material-ui/core/InputLabel';
import Moment from 'moment';
import FormHelperText from '@material-ui/core/FormHelperText';
import ExpandLessIcon from '@material-ui/icons/ExpandLess';
import validateField from '../../utils/validator';
import { conformToMask } from 'react-text-mask';
import { UhcidMaskInResult, ZipMask, PTIMpinMask, MpinMask, TaxMask, MaidMask, BaidMask, PhoneMask, NpiMask, SSNMask, PrefixSuffixMask, StateMask } from '../../utils/custom.input';
import Tooltip from '@material-ui/core/Tooltip';

const useStyles = makeStyles(() => ({
  root: {
    //padding: "2rem"
  },
  gap: {
    flexGrow: 1
  },
  customLink: {
    color: "#269AE6",
    fontSize: 15
  },
  customButton: {
    textTransform: "none",
    borderRadius: 0,
    //marginBottom: "1rem"
  },
  customChip: {
    marginRight: "1.5rem",
    border: "1px solid #B3BABC",
    marginBottom: "1rem"
  },
  selectRoot: {
    marginBottom: "1rem",
    width: '135px'
  },
  filterArea: {
    marginTop: 0,
    maxWidth: '70%',
    //height: 45,
    paddingTop: 10
  },
  fieldSet: {
    border: "1px solid #B3BABC",
    backgroundColor: "#e0e0e0",
    padding: "0.16em 0.2em",
    display: "inline-block",
    position: "relative",
    verticalAlign: 'top'
    //bottom: "0.4em"
  },
  daterefresh: {
    "font-family": "Roboto,Helvetica,Arial,sans-serif",
    "line-height": "1.5",
    "letter-spacing": "0.00938em",
    "margin-left": "10px",
    "font-size": "13px",
    "color": "#757588",
    "margin-top": "0.75em",
    "font-weight": "bold"
  },
  dataRefreshError: {
    "font-family": "Roboto,Helvetica,Arial,sans-serif",
    "line-height": "1.5",
    "letter-spacing": "0.00938em",
    "margin-left": "10px",
    "font-size": "13px",
    "color": "#e73232",
    "margin-top": "0.75em",
    "font-weight": "bold"
  }
}));


const FieldInput = withStyles(theme => ({
  root: {
    "label + &": {
      marginTop: theme.spacing(3)
    }
  },
  input: {
    borderRadius: 0,
    position: "relative",
    backgroundColor: theme.palette.common.white,
    border: "1px solid #ced4da",
    fontSize: 16,
    //width: "auto",
    padding: "5px 10px",
    transition: theme.transitions.create(["border-color", "box-shadow"]),
    // Use the system font instead of the default Roboto font.
    fontFamily: [
      "-apple-system",
      "BlinkMacSystemFont",
      '"Segoe UI"',
      "Roboto",
      '"Helvetica Neue"',
      "Arial",
      "sans-serif",
      '"Apple Color Emoji"',
      '"Segoe UI Emoji"',
      '"Segoe UI Symbol"'
    ].join(","),
    "&:focus": {
      borderColor: theme.palette.primary.main
    }
  }
}))(InputBase);

function HeaderResultProviderComponent({
  filterFields,
  removeResultFilter,
  setFilterValue,
  fetchResultsOnFilterChange,
  resultOfFilteredText,
  showHideHeaderContent,
  handleError,
  metadata
}) {
  React.useEffect(() => {
    let filterFieldType = filterFields.map(field => field.type);
    if (filterFieldType.includes('mpin')) {
      let removedFields = state.customFieldList.filter(filter => filter.type !== "ptiMpin")
      setState({ ...state, customFieldList: removedFields })
    }
    if (filterFieldType.includes('ptiMpin')) {
      let removedFields = state.customFieldList.filter(filter => filter.type !== "mpin")
      setState({ ...state, customFieldList: removedFields })
    }
    if (filterFieldType.includes("maid")) {
      let removedFields = state.customFieldList.filter(filter => filter.type !== "baid")
      setState({ ...state, customFieldList: removedFields })
    }
    if (filterFieldType.includes("baid")) {
      let removedFields = state.customFieldList.filter(filter => filter.type !== "maid")
      setState({ ...state, customFieldList: removedFields })
    }
    let dependentField = filterFields.filter(p => p.type == "lastGroupName" || p.type == "firstName" || p.type == "middleName" || p.type == "telephone" ||
      p.type == "taxId" || p.type == "ssn" || p.type == "npi" || p.type == "mpin" || p.type == "maid" || p.type == "baid" || p.type == "ptiMpin")
    let uhcid = filterFields.filter(p => p.type == "uhcid")
    if (state.dependentError == true && dependentField.length >= 1) {
      setState({ ...state, dependentError: false })
    }
    else {
      if (uhcid.length != 0) {
        if (uhcid[0].value.length >= 11) {
          setState({ ...state, dependentError: false })
        }
      }
    }
  }, [filterFields])
  const classes = useStyles();
  const history = useHistory();
  let isCallSubmitBtn2 = false;
  if (filterFields && filterFields.length === 0) {
    history.push("/providers/search-provider");
    handleError('speciality', '')
    handleError('sequence', '')
    handleError('div', '')
  }
  const filterFieldType = filterFields.map(field => field.type);
  const [state, setState] = React.useState({
    addFilter: true,
    npi: false,
    ssn: false,
    ssnWildCard: false,
    telephone: false,
    baid: false,
    maid: false,
    uhcid: false,
    mpin: false,
    ptimpin: false,
    zipcode: false,
    taxid: false,
    firstname: false,
    firstnameWild: false,
    lastGroupName: false,
    lastGroupNameWild: false,
    middleName: false,
    middleNameWild: false,
    statecode: false,
    pfxsfx: false,
    newFilter: {},
    isCallSubmitBtn: false,
    customFieldList: fieldList
      .filter(
        field => filterFieldType.indexOf(field.type) === -1 && !field.isDisabled
      )
      .sort((a, b) => (a.label < b.label ? -1 : 1)),
    triggerSearchCall: false,
    dependentError: false,
    currentCST: ''
  });
  const removeFilter = (event, filter) => {
    removeResultFilter(filter.type);
    if (filter.type == 'mpin' || filter.type == 'mpin') {
      let fields = state.customFieldList
      fields.push({ type: "ptiMpin", label: "PTI MPIN", isDisabled: false })
      fields.push({ type: "mpin", label: "MPIN", isDisabled: false })
      setState({
        ...state, customFieldList: fields.sort((a, b) =>
          a.label < b.label ? -1 : 1
        ), triggerSearchCall: true
      })
    }
    else if (filter.type == "baid") {
      let fields = state.customFieldList

      fields.push({ type: "baid", label: "BAID", isDisabled: false })
      setState({
        ...state, customFieldList: fields.sort((a, b) =>
          a.label < b.label ? -1 : 1
        ), triggerSearchCall: true
      })
    }
    else if (filter.type == "maid") {
      let fields = state.customFieldList
      fields.push({ type: "maid", label: "MAID", isDisabled: false })

      setState({
        ...state, customFieldList: fields.sort((a, b) =>
          a.label < b.label ? -1 : 1
        ), triggerSearchCall: true
      })
    }
    else {
      if (filter.type == "uhcid") {
        handleError('speciality', '')
        handleError('sequence', '')
        handleError('div', '')
      }
      setState({
        ...state,
        triggerSearchCall: true,
        customFieldList: [...state.customFieldList, filter].sort((a, b) =>
          a.label < b.label ? -1 : 1
        )
      });
    }
  };
  let handleAddFilterBtn = (event, value) => {
    setState({
      ...state,
      addFilter: value
    });
  };
  const handleSelectFilter = event => {
    setState({
      ...state,
      isCallSubmitBtn: false,
      newFilter: fieldList.find(field => field.type === event.target.value),
      customFieldList: state.customFieldList.filter(
        field => field.type !== event.target.value
      )
    });
  };
  const setNewFilterValue = event => {

    let label = state.newFilter.label;
    let value = event.target.value;
    state.newFilter.value = value;
    let states = {};
    switch (label) {
      case "SSN":
        states = handleInputChangeForSSN(label, value)
        break;
      case "NPI":
        states = handleInputChangeForNPI(label, value)
        break;
      case "Telephone":
        states = handleInputChangeForTELEPHONE(label, value)
        break;
      case "BAID":
        states = handleInputChangeForBAID(label, value)
        break;
      case "MAID":
        states = handleInputChangeForMAID(label, value)
        break;

      case "TAXID":
        states = handleInputChangeForTAXID(label, value)
        break;
      case "Last/Group Name":
        states = handleInputChangeForLastGroupName(label, value)
        break;
      case "Middle Name":
        states = handleInputChangeForMiddleName(label, value)
        break;
      case "First Name":
        states = handleInputChangeForFirstname(label, value)
        break;
      case "MPIN":
        states = handleInputChangeForMPIN(label, value)
        break;

      case "PTI MPIN":
        states = handleInputChangeForPTIMPIN(label, value)
        break;
      case "Zip Code":
        states = handleInputChangeForzipcode(label, value)
        break;
      case "State":
        states = handleInputChangeForstate(label, value)
        break;
      case "UHCID":
        states = handleInputChangeUHCID(label, value)
        break;
      case "PFX/SFX":
        states = handleInputChangePFXSFX(label, value)
        break;


    }
    if (states.flag) {
      setFilterValue(state.newFilter.value, state.newFilter.type);
      setState({
        ...state,
        addFilter: false,
        ssn: states.ssn,
        npi: states.npi,
        telephone: states.telephone,
        ssnWildCard: states.ssnWildCard,
        ptimpin: states.ptimpin,
        baid: states.baid,
        maid: states.maid,
        taxid: states.taxid,
        zipcode: states.zipcode,
        lastGroupName: states.lastGroupName,
        lastGroupNameWild: states.lastGroupNameWild,
        middleName: states.middleName,
        middleNameWild: states.middleNameWild,
        firstname: states.firstname,
        firstnameWild: states.firstnameWild,
        mpin: states.main,
        statecode: states.statecode,
        uhcid: states.uhcid,
        pfxsfx: states.pfxsfx,

        newFilter: {},
        triggerSearchCall: true,
      });
    }
    else {
      setState({
        ...state,
        isCallSubmitBtn: true,
        ssn: states.ssn,
        npi: states.npi,
        telephone: states.telephone,
        ssnWildCard: states.ssnWildCard,
        uhcid: states.uhcid,
        baid: states.baid,
        maid: states.maid,
        taxid: states.taxid,
        zipcode: states.zipcode,
        lastGroupName: states.lastGroupName,
        lastGroupNameWild: states.lastGroupNameWild,
        firstname: states.firstname,
        firstnameWild: states.firstnameWild,
        middleName: states.middleName,
        middleNameWild: states.middleNameWild,
        mpin: states.main,
        statecode: states.statecode,
        pfxsfx: states.pfxsfx,
        newFilter: {
          ...state.newFilter,
          value: event.target.value,

        }
      });
    }
  };

  function setNewFilterValueclose() {
    let labelToBeAddedBack = "";
    let typeToBeAddedBack = ""
    let updatedCustomFieldList = state.customFieldList;
    if (state.newFilter.type != "") {
      labelToBeAddedBack = state.newFilter.label;
      typeToBeAddedBack = state.newFilter.type
      updatedCustomFieldList.push({
        label: labelToBeAddedBack,
        type: typeToBeAddedBack,
        isDisabled: false
      })
      updatedCustomFieldList.sort(function (a, b) {
        var x = a['type']; var y = b['type'];
        return ((x < y) ? -1 : ((x > y) ? 1 : 0));
      });
    }

    setState({
      ...state,
      isCallSubmitBtn: true,
      customFieldList: updatedCustomFieldList,
      newFilter: {}
    });
  };

  const submitNewFilter = (label) => event => {

    if (event.key === 'Enter' && event.target.value != '') {
      let flag = false;
      let ssnState = false;
      let lastgroupnameState = false;
      let middlenameState = false;
      let firstnameState = false;
      let npiState = false;
      let baidState = false;
      let mpinState = false;
      let ptimpinState = false;
      let maidState = false;
      let uhcidState = false;
      let taxidState = false;
      let zipcodeState = false;
      let statecodeState = false;
      let TelephoneState = false;
      let PFXSFXstate = false;
      if (label == "SSN" && state.newFilter.value != null && state.newFilter.value.length < 9) {
        ssnState = true;
        setState({ ...state, ssn: true })
        if (state.newFilter.value.length == 0) {
          ssnState = false;
          setState({ ...state, ssn: false })
        }
      }
      if (label == "SSN" && state.newFilter.value != null && state.newFilter.value.length == 9) {
        flag = true;
        ssnState = false;
        setState({ ...state, ssn: false })
      }

      if (label == "Last/Group Name" && state.newFilter.value != null && state.newFilter.value.length > 0) {
        let value = event.target.value;
        event.target.value = value;
        state.newFilter.value = value;
        lastgroupnameState = true;
        setState({ ...state, lastGroupName: true })
        if (state.newFilter.value.length == 0) {
          lastgroupnameState = false;
          setState({ ...state, lastGroupName: false })
        }
      }
      if (label == "Last/Group Name" && state.newFilter.value != null && state.newFilter.value.length > 0) {
        flag = true;
        lastgroupnameState = false;
        setState({ ...state, lastGroupName: false })
      }

      if (label == "BAID" && state.newFilter.value != null && state.newFilter.value.length < 9) {
        let value = event.target.value;
        if (value.length > 0) {
          for (let i = value.length; i < 9; i++) {
            value = '0' + value;
          }
        }
        event.target.value = value;
        state.newFilter.value = value;
        baidState = true;
        setState({ ...state, baid: true })
        if (state.newFilter.value.length == 0) {
          baidState = false;
          setState({ ...state, baid: false })
        }
      }
      if (label == "BAID" && state.newFilter.value != null && state.newFilter.value.length == 9) {
        flag = true;
        baidState = false;
        setState({ ...state, baid: false })
      }









      if (label == "Middle Name" && state.newFilter.value != null && state.newFilter.value.length > 0) {
        let value = event.target.value;
        event.target.value = value;
        state.newFilter.value = value;
        middlenameState = true;
        setState({ ...state, middleName: true })
        if (state.newFilter.value.length == 0) {
          middlenameState = false;
          setState({ ...state, middleName: false })
        }
      }
      if (label == "Middle Name" && state.newFilter.value != null && state.newFilter.value.length > 0) {
        flag = true;
        middlenameState = false;
        setState({ ...state, middleName: false })
      }



      if (label == "First Name" && state.newFilter.value != null && state.newFilter.value.length > 0) {
        let value = event.target.value;
        event.target.value = value;
        state.newFilter.value = value;
        firstnameState = true;
        setState({ ...state, firstname: true })
        if (state.newFilter.value.length == 0) {
          firstnameState = false;
          setState({ ...state, firstname: false })
        }
      }
      if (label == "First Name" && state.newFilter.value != null && state.newFilter.value.length > 0) {
        flag = true;
        firstnameState = false;
        setState({ ...state, firstname: false })
      }

      if (label == "UHCID" && state.newFilter.value != null && state.newFilter.value.length > 0) {
        let value = event.target.value;
        event.target.value = value;
        state.newFilter.value = value;
        uhcidState = true;
        if (value.length >= 11) {
          value = value.replace(/[^a-zA-Z0-9]/g, "")
          handleError('speciality', value.substr(0, 4))
          handleError('sequence', value.substr(4, 7))
          handleError('div', value.substr(11, 3))
          value = mask(value)
          state.newFilter.value = value.toUpperCase();
        }
        if (value.length <= 4) {
          let isnum = /^\d+$/.test(value)
          if (isnum) {
            for (let i = value.length; i < 4; i++) {
              value = '0' + value;
            }
            state.newFilter.value = value
            handleError('speciality', value)
          }
          else {
            if (value.length == 3) {
              state.newFilter.value = value
            }
          }
        }
        if (value.length >= 6 && value.length <= 12) {
          value = value.split('-')
          let value1 = value[0]
          let value2 = value[1]
          for (let i = value2.length; i < 7; i++) {
            value2 = '0' + value2;
            handleError('sequence', value2)
          }
          value = value1 + '-' + value2
          state.newFilter.value = value
        }
        setState({ ...state, uhcid: true })
        if (state.newFilter.value.length == 0) {
          uhcidState = false;
          setState({ ...state, uhcid: false })
        }
      }
      if (label == "UHCID" && state.newFilter.value != null && state.newFilter.value.length > 0) {
        flag = true;
        uhcidState = false;
        setState({ ...state, uhcid: false })
      }

      if (label == "State" && state.newFilter.value != null && state.newFilter.value.length > 0) {
        statecodeState = true;
        setState({ ...state, statecode: true })
        if (state.newFilter.value.length == 0) {
          statecodeState = false;
          setState({ ...state, statecode: false })
        }
      }
      if (label == "State" && state.newFilter.value != null && state.newFilter.value.length > 0) {
        flag = true;
        statecodeState = false;
        setState({ ...state, statecode: false })
        if (state.newFilter.value.length < 2) {
          statecodeState = false;
          setState({ ...state, statecode: true })
          flag = false
        }
      }



      if (label == "NPI" && state.newFilter.value != null && state.newFilter.value.length < 10) {
        npiState = true;
        setState({ ...state, npi: true })
        if (state.newFilter.value.length == 0) {
          npiState = false;
          setState({ ...state, npi: false })
        }
      }
      if (label == "NPI" && state.newFilter.value != null && state.newFilter.value.length == 10) {
        flag = true;
        npiState = false;
        setState({ ...state, npi: false })
      }



      if (label == "MPIN" && state.newFilter.value != null && state.newFilter.value.length > 0) {
        //  let value = event.target.value;
        //   for(let i = value.length; i < 9; i++ ) {
        //     value = '0' + value;
        //   }
        //   event.target.value=value;
        //  state.newFilter.value=value;
        mpinState = true;
        setState({ ...state, mpin: true })
        if (state.newFilter.value.length == 0) {
          mpinState = false;
          setState({ ...state, mpin: false })
        }
      }
      if (label == "MPIN" && state.newFilter.value != null && state.newFilter.value.length > 0) {
        flag = true;
        mpinState = false;
        setState({ ...state, mpin: false })
      }

      if (label == "PTI MPIN" && state.newFilter.value != null && state.newFilter.value.length > 0) {
        //  let value = event.target.value;
        //   for(let i = value.length; i < 9; i++ ) {
        //     value = '0' + value;
        //   }
        //   event.target.value=value;
        //  state.newFilter.value=value;
        mpinState = true;
        setState({ ...state, ptimpin: true })
        if (state.newFilter.value.length == 0) {
          ptimpinState = false;
          setState({ ...state, ptimpin: false })
        }
      }
      if (label == "PTI MPIN" && state.newFilter.value != null && state.newFilter.value.length > 0) {
        flag = true;
        ptimpinState = false;
        setState({ ...state, ptimpin: false })
      }



      if (label == "TAXID" && state.newFilter.value != null && state.newFilter.value.length < 9) {
        let value = event.target.value;
        if (value.length >= 5) {
          for (let i = value.length; i < 9; i++) {
            value = '0' + value;
          }
          event.target.value = value;
        }
        state.newFilter.value = value;
        taxidState = true;
        setState({ ...state, taxid: true })
        if (state.newFilter.value.length == 0) {
          taxidState = false;
          setState({ ...state, taxid: false })
        }
      }
      if (label == "TAXID" && state.newFilter.value != null && state.newFilter.value.length == 9) {
        flag = true;
        taxidState = false;
        setState({ ...state, taxid: false })
      }


      if (label == "Zip Code" && state.newFilter.value != null && state.newFilter.value.length < 5) {
        let value = event.target.value;
        if (value !== '') {
          for (let i = value.length; i < 5; i++) {
            value = '0' + value;
          }
          event.target.value = value;
        }
        state.newFilter.value = value;
        zipcodeState = true;
        setState({ ...state, zipcode: true })
        if (state.newFilter.value.length == 0) {
          setState = false;
          setState({ ...state, zipcode: false })
        }
      }
      if (label == "Zip Code" && state.newFilter.value != null && state.newFilter.value.length == 5) {
        flag = true;
        zipcodeState = false;
        setState({ ...state, zipcode: false })
      }

      if (label == "MAID" && state.newFilter.value != null && state.newFilter.value.length < 9) {
        let value = event.target.value;
        if (value.length > 0) {
          for (let i = value.length; i < 9; i++) {
            value = '0' + value;
          }
        }
        event.target.value = value;
        state.newFilter.value = value;
        maidState = true;
        setState({ ...state, maid: true })
        if (state.newFilter.value.length == 0) {
          maidState = false;
          setState({ ...state, maid: false })
        }
      }
      if (label == "MAID" && state.newFilter.value != null && state.newFilter.value.length == 9) {
        flag = true;
        baidState = false;
        setState({ ...state, maid: false })
      }

      if (label == "Telephone" && state.newFilter.value != null && state.newFilter.value.length < 14) {
        TelephoneState = true;
        setState({ ...state, telephone: true })
        if (state.newFilter.value.length == 0) {
          TelephoneState = false;
          setState({ ...state, telephone: false })
        }
      }
      if (label == "Telephone" && state.newFilter.value != null && state.newFilter.value.length == 14) {
        flag = true;
        TelephoneState = false;
        setState({ ...state, telephone: false })
      }
      if (label == "PFX/SFX" && state.newFilter.value != null && state.newFilter.value.length < 7) {
        PFXSFXstate = true;
        let value = event.target.value
        if (value.length >= 3) {
          value = value.split(' ')
          let tempValue = value[0]
          value = value[1]
          for (let i = value.length; i < 5; i++) {
            value = '0' + value;
          }
          value = tempValue + ' ' + value
          state.newFilter.value = value
        } else {
          if (value.length <= 2) {
            state.newFilter.value = value
            flag = true
            PFXSFXstate = false;
            setState({ ...state, pfxsfx: false })
          }
        }
        setState({ ...state, pfxsfx: true })
        if (state.newFilter.value.length == 0) {
          PFXSFXstate = false;
          setState({ ...state, pfxsfx: false })
        }
      }
      if (label == "PFX/SFX" && state.newFilter.value != null && state.newFilter.value.length == 7) {
        flag = true;
        PFXSFXstate = false;
        setState({ ...state, pfxsfx: false })
      }

      if (flag) {

        setFilterValue(state.newFilter.value, state.newFilter.type);

        setState({
          ...state,
          addFilter: false,
          ssn: ssnState,
          npi: npiState,
          baid: baidState,
          maid: maidState,
          mpin: mpinState,
          ptimpin: ptimpinState,
          taxid: taxidState,
          statecode: statecodeState,
          zipcode: zipcodeState,
          lastGroupName: lastgroupnameState,
          middlenameState: middlenameState,
          firstname: firstnameState,
          telephone: TelephoneState,
          uhcid: uhcidState,
          pfxsfx: PFXSFXstate,
          newFilter: {},
          triggerSearchCall: flag,
        });
      }
    }
  };
  if (state.triggerSearchCall) {
    setState({
      ...state,
      triggerSearchCall: false
    });
    let dependentField = filterFields.filter(p => p.type == "lastGroupName" || p.type == "firstName" || p.type == "middleName" || p.type == "telephone" || p.type == "taxId" ||
      p.type == "ssn" || p.type == "npi" || p.type == "mpin" || p.type == "maid" || p.type == "baid" || p.type == "ptiMpin")
    let uhcid = filterFields.filter(p => p.type == "uhcid")
    if (dependentField.length >= 1) {
      fetchResultsOnFilterChange();
    }
    else {
      if (uhcid.length != 0) {
        if (uhcid[0].value.length >= 11) {
          fetchResultsOnFilterChange();
        }
        else {
          if (state.dependentError == false) {
            setState({ ...state, dependentError: true })
          }
        }
      }
      else {
        if (state.dependentError == false) {
          setState({ ...state, dependentError: true })
        }
      }
    }
  }

  let submitFieldSendField = () => {
    return (
      state.newFilter.label == "SSN" ?
        <FormControl error={state.ssn || state.ssnWildCard}   >
          <FieldInput aria-describedby="input-ssn-id" onChange={setNewFilterValue} onBlur={submitNewFilter('SSN')} id="ssn-id" inputComponent={SSNMask} />
          <FormHelperText error style={{ display: state.ssn ? 'block' : 'none' }}>
            Exact search requires 9 characters
      </FormHelperText>
          <FormHelperText error style={{ display: state.ssnWildCard ? 'block' : 'none' }}>
            Wildcard search requires 4 digits
      </FormHelperText>
        </FormControl> : state.newFilter.label == "NPI" ?
          (
            <FormControl variant="outlined" fullWidth error={state.npi}>
              <FieldInput
                style={{ width: '310px' }}
                id="npi-id"
                classes={{ input: classes.customInput, disabled: classes.disabled }}

                onChange={setNewFilterValue}
                aria-describedby="input-npi-id"
                //placeholder="##########"
                inputComponent={NpiMask}
                onKeyPress={submitNewFilter('NPI')}
              />
              <FormHelperText error style={{ display: state.npi ? 'block' : 'none' }}>
                10 Digits required
  </FormHelperText>
            </FormControl>
          ) : state.newFilter.label == "Telephone" ? (

            <FormControl variant="outlined" fullWidth error={state.telephone}>
              <FieldInput
                id="telephone-id"
                classes={{ input: classes.customInput, disabled: classes.disabled }}
                onChange={setNewFilterValue}
                aria-describedby="input-telephone"
                placeholder="(###) ###-####"
                inputComponent={PhoneMask}
                onKeyPress={submitNewFilter('Telephone')}
              />
              <FormHelperText error style={{ display: state.telephone ? 'block' : 'none' }}>
                10 Digits required
  </FormHelperText>
            </FormControl>
          ) : state.newFilter.label == "BAID" ? (
            <FormControl variant="outlined" fullWidth error={state.baid}>
              <FieldInput
                id="baid-id"
                classes={{ input: classes.customInput, disabled: classes.disabled }}

                inputComponent={BaidMask}
                onChange={setNewFilterValue}
                aria-describedby="input-baid-id"
                onKeyPress={submitNewFilter('BAID')}
              //placeholder="##########"
              // disabled={isFieldDisabled('baid')}
              />

            </FormControl>
          ) : state.newFilter.label == "MAID" ? (
            <FormControl variant="outlined" fullWidth error={state.maid}>
              <FieldInput
                id="baid-id"
                classes={{ input: classes.customInput, disabled: classes.disabled }}

                inputComponent={MaidMask}
                onChange={setNewFilterValue}
                aria-describedby="input-maid-id"
                onKeyPress={submitNewFilter('MAID')}
              //placeholder="##########"
              // disabled={isFieldDisabled('baid')}
              />

            </FormControl>
          ) : state.newFilter.label == "TAXID" ? (
            <FormControl variant="outlined" fullWidth error={state.taxid}>
              <FieldInput
                id="tax-id"
                classes={{ input: classes.customInput, disabled: classes.disabled }}

                onChange={setNewFilterValue}
                aria-describedby="input-tax-id"
                inputComponent={TaxMask}

                onKeyPress={submitNewFilter('TAXID')}
              />
              <FormHelperText error style={{ display: state.taxId ? 'block' : 'none' }}>
                Tax Id can have only 9 numeric characters
                </FormHelperText>

            </FormControl>
          ) : state.newFilter.label == "Last/Group Name" ? (
            <FormControl variant="outlined" fullWidth error={state.lastGroupName || state.lastGroupNameWild}>
              <FieldInput
                id="last-group-name"
                classes={{ input: classes.customInput, disabled: classes.disabled }}

                onChange={setNewFilterValue}
                aria-describedby="input-last-or-group-name"
                onKeyPress={submitNewFilter('Last/Group Name')}
              //placeholder="##########"
              // disabled={isFieldDisabled('baid')}
              />
              <FormHelperText error style={{ display: state.lastGroupName ? 'block' : 'none' }}>
                Unsupported character combinations:  ",|
            </FormHelperText>
              <FormHelperText error style={{ display: state.lastGroupNameWild ? 'block' : 'none' }}>
                * Wildcard requires 5 character minimum to execute.
            </FormHelperText>
            </FormControl>
          ) : state.newFilter.label == "First Name" ? (
            <FormControl variant="outlined" fullWidth error={state.firstName || state.firstNameWild}>
              <FieldInput
                id="first-name"
                classes={{ input: classes.customInput, disabled: classes.disabled }}
                onChange={setNewFilterValue}
                aria-describedby="input-first-name"
                onKeyPress={submitNewFilter('First Name')}
              //placeholder="##########"
              // disabled={isFieldDisabled('baid')}
              />
              <FormHelperText error style={{ display: state.firstName ? 'block' : 'none' }}>
                Unsupported character combinations:  ",|
            </FormHelperText>
              <FormHelperText error style={{ display: state.firstNameWild ? 'block' : 'none' }}>
                * Wildcard requires 5 character minimum to execute.
            </FormHelperText>

            </FormControl>
          ) : state.newFilter.label == "MPIN" ? (
            <FormControl variant="outlined" fullWidth error={state.mpin}>
              <FieldInput
                id="mpin-id"
                classes={{ input: classes.customInput, disabled: classes.disabled }}

                onChange={setNewFilterValue}
                aria-describedby="input-mpin-id"
                inputComponent={MpinMask}

                onKeyPress={submitNewFilter('MPIN')}
              //placeholder="##########"
              // disabled={isFieldDisabled('baid')}
              />

            </FormControl>
          ) : state.newFilter.label == "PTI MPIN" ? (
            <FormControl variant="outlined" fullWidth error={state.ptimpin}>
              <FieldInput
                id="ptiMpin-id"
                classes={{ input: classes.customInput, disabled: classes.disabled }}

                inputComponent={PTIMpinMask}
                onChange={setNewFilterValue}
                onKeyPress={submitNewFilter('PTI MPIN')}
              // disabled={isFieldDisabled('ptiMpin')}
              />
            </FormControl>
          ) : state.newFilter.label == "Middle Name" ? (
            <FormControl variant="outlined" fullWidth error={state.middleName || state.middleNameWild}>
              <FieldInput
                id="middle-name"
                classes={{ input: classes.customInput, disabled: classes.disabled }}

                onChange={setNewFilterValue}
                aria-describedby="input-middle-name"
                onKeyPress={submitNewFilter('Middle Name')}
              //placeholder="##########"
              // disabled={isFieldDisabled('baid')}
              />
              <FormHelperText error style={{ display: state.middleName ? 'block' : 'none' }}>
                Unsupported character combinations:  ",|
          </FormHelperText>
              <FormHelperText error style={{ display: state.middleNameWild ? 'block' : 'none' }}>
                * Wildcard requires 5 character minimum to execute.
            </FormHelperText>
            </FormControl>
          ) : state.newFilter.label == "Zip Code" ? (
            <FormControl variant="outlined" fullWidth error={state.zipcode}>
              <FieldInput
                id="zip-code"
                classes={{ input: classes.customInput, disabled: classes.disabled }}
                onChange={setNewFilterValue}
                aria-describedby="input-zip-code"
                //placeholder="#####"
                inputComponent={ZipMask}
                onKeyPress={submitNewFilter('Zip Code')}
              //onKeyDown ={handleClick}
              />

              <FormHelperText error style={{ display: state.zipcode ? 'block' : 'none' }}>
                Zip Code is dependent field
</FormHelperText>
            </FormControl>
          ) : state.newFilter.label == "State" ? (
            <FormControl variant="outlined" fullWidth error={state.statecode}>
              <FieldInput
                id="state-name"
                classes={{ input: classes.customInput, disabled: classes.disabled }}
                onChange={setNewFilterValue}
                aria-describedby="input-State"
                inputComponent={StateMask}
                // placeholder="#####"
                onKeyPress={submitNewFilter('State')}
              //onKeyDown ={handleClick}
              />
              <FormHelperText error style={{ display: state.statecode ? 'block' : 'none' }}>
                2 Characters required
            </FormHelperText>
            </FormControl>
          ) : state.newFilter.label == "UHCID" ? (
            <FormControl variant="outlined" fullWidth error={state.uhcid}>
              <FieldInput
                id="uhc-id"
                classes={{ input: classes.customInput, disabled: classes.disabled }}
                //value={uhcid}
                onChange={setNewFilterValue}
                aria-describedby="input-uhc-id"
                placeholder="####-#######-DIV"
                onKeyPress={submitNewFilter('UHCID')}
                inputComponent={UhcidMaskInResult}
              />
            </FormControl>
          ) : state.newFilter.label == "PFX/SFX" ? (
            <FormControl variant="outlined" fullWidth error={state.pfxsfx}>
              <FieldInput
                id="pfxsfx"
                classes={{ input: classes.customInput, disabled: classes.disabled }}
                //value={uhcid}
                onChange={setNewFilterValue}
                placeholder="# ######"
                onKeyPress={submitNewFilter('PFX/SFX')}
                inputComponent={PrefixSuffixMask}
              />
            </FormControl>
          )
                                    : <FieldInput onChange={setNewFilterValue} onBlur={submitNewFilter} />
    );
  };
  const handleInputChangeForMiddleName = (label, value) => {
    let states = { middleNameWild: false, middleName: false, flag: false };
    value = value.split('')
    if (value.includes('*')) {
      if (value.length < 5) {
        states.middleNameWild = true;
        states.middleName = false;
        setState({ middleNameWild: true, middleName: false })
      }
      else {
        states.middleNameWild = false;
        states.middleName = false;
        states.flag = true;
        setState({ middleNameWild: false, middleName: false })
      }
      //handleUniversalChanges(prop,value.join(''))
    }
    else {
      if (value.length == 20 || value.length == 0) {
        states.middleName = false;
        if (value.length == 20) {
          states.flag = true;
        }
      }
      //handleUniversalChanges(prop,value)
    }
    return states;
  }
  const handleInputChangeForLastGroupName = (label, value) => {
    let states = { lastGroupNameWild: false, lastGroupName: false, flag: false };
    value = value.split('')
    if (value.includes('*')) {
      if (value.length < 5) {
        states.lastGroupNameWild = true;
        states.lastGroupName = false;
        setState({ lastGroupNameWild: true, lastGroupName: false })
      }
      else {
        states.lastGroupNameWild = false;
        states.lastGroupName = false;
        states.flag = true;
        setState({ lastGroupNameWild: false, lastGroupName: false })
      }
      //handleUniversalChanges(prop,value.join(''))
    }
    else {
      if (value.length == 65 || value.length == 0) {
        states.lastGroupName = false;
        if (value.length == 65) {
          states.flag = true;
        }
      }
      //handleUniversalChanges(prop,value)
    }
    return states;
  }
  const handleInputChangeForFirstname = (label, value) => {
    let states = { firstnameWild: false, firstname: false, flag: false };
    value = value.split('')
    if (value.includes('*')) {
      if (value.length < 5) {
        states.firstnameWild = true;
        states.firstname = false;
        setState({ firstnameWild: true, firstname: false })
      }
      else {
        states.firstnameWild = false;
        states.firstname = false;
        states.flag = true;
        setState({ firstnameWild: false, firstname: false })
      }
      //handleUniversalChanges(prop,value.join(''))
    }
    else {
      if (value.length == 20 || value.length == 0) {
        states.firstname = false;
        if (value.length == 20) {
          states.flag = true;
        }
      }
      //handleUniversalChanges(prop,value)
    }
    return states;
  }
  const handleInputChangeForSSN = (label, value) => {
    let states = { ssnWildCard: false, ssn: false, flag: false };
    value = value.split('')
    if (value.includes('*')) {
      if (value.length < 5) {
        states.ssnWildCard = true;
        states.ssn = false;
        setState({ ssnWildCard: true, ssn: false })
      }
      else {
        states.ssnWildCard = false;
        states.ssn = false;
        states.flag = true;
        setState({ ssnWildCard: false, ssn: false })
      }
      //handleUniversalChanges(prop,value.join(''))
    }
    else {
      if (value.length == 9 || value.length == 0) {
        states.ssn = false;
        if (value.length == 9) {
          states.flag = true;
        }
      }
      //handleUniversalChanges(prop,value)
    }
    return states;
  }
  const handleInputChangeForBAID = (label, value) => {
    let states = { baid: false, flag: false };
    if (value.length == 9) {
      states.baid = false;
      states.flag = true;
    }
    return states;
  }
  const handleInputChangeForMPIN = (label, value) => {
    let states = { mpin: false, flag: false };
    if (value.length == 9) {
      states.mpin = false;
      states.flag = true;
    }
    return states;
  }
  const handleInputChangeForPTIMPIN = (label, value) => {
    let states = { ptimpin: false, flag: false };
    if (value.length == 9) {
      states.ptimpin = false;
      states.flag = true;
    }
    return states;
  }
  const handleInputChangeForTAXID = (label, value) => {
    let states = { taxid: false, flag: false };
    if (value.length == 9) {
      states.taxid = false;
      states.flag = true;
    }
    return states;
  }
  const handleInputChangeForzipcode = (label, value) => {
    let states = { zipcode: false, flag: false };
    if (value.length == 5) {
      states.zipcode = false;
      states.flag = true;
    }
    return states;
  }
  const handleInputChangeForstate = (label, value) => {

    // console.log("********************");
    // console.log(label, value);
    // console.log("********************");

    let states = { statecode: false, flag: false };
    if (value.length == 20) {
      states.statecode = false;
      states.flag = true;
    }
    return states;
  }
  const handleInputChangeUHCID = (label, value) => {
    let states = { uhcid: false, flag: false };
    if (value.length == 16) {
      states.uhcid = false;
      states.flag = true;
      let uhcvalue = value
      uhcvalue = value.replace(/[^a-zA-Z0-9]/g, "")
      handleError('speciality', uhcvalue.substr(0, 4))
      handleError('sequence', uhcvalue.substr(4, 7))
      handleError('div', uhcvalue.substr(11, 3))
    }
    return states;
  }
  const handleInputChangePFXSFX = (label, value) => {
    let states = { pfxsfx: false, flag: false };
    if (value.length == 8) {
      states.pfxsfx = false;
      states.flag = true;
    }
    return states;
  }
  const handleInputChangeForMAID = (label, value) => {
    let states = { maid: false, flag: false };
    if (value.length == 9) {
      states.maid = false;
      states.flag = true;
    }
    return states;
  }
  const handleInputChangeForTELEPHONE = (label, value) => {
    let states = { telephone: false, flag: false };
    if (value.length == 14) {
      states.telephone = false;
      states.flag = true;
    }
    return states;
  }
  const handleInputChangeForNPI = (label, value) => {
    let states = { npi: false, flag: false };
    if (value.length == 10 || value.length == 0) {
      states.npi = false;
      if (value.length == 10) {
        states.flag = true;
      }
    }
    return states;
  }
  const getZipvalue = (zipvalue) => {
    let value = zipvalue
    for (let i = value.length; i < 5; i++) {
      value = '0' + value;
    }
    return value
  }
  const getStateValue = (state) => {
    // console.log(state)
    // console.log("last char ", state.charAt(state.length - 1))
    // state = state.slice(1, state.charAt(state.length - 1) == "," ? -1 : '')
    if (state.charAt(state.length - 1) == ",")
      state = state.substring(0, state.length - 1) //state.slice(1, -1);
    // console.log("with Result ", state)
    return state
  }

  const getTime = () => {
    var finalTime = null;
    if (metadata.lastRefreshed !== 0 && metadata.lastRefreshed !== null && metadata.lastRefreshed !== undefined) {
      var dateFormat = metadata.lastRefreshed;
      console.log("last refreshed date",metadata.lastRefreshed.split(' '))
      // const timeFormat = dateFormat.replace(/[- )(]/g, '');
      // const time = timeFormat.substr(-12);
      // const str = time.slice(0, -4);
      const maxDate = Moment(dateFormat).format('MM-DD-YYYY');
      finalTime = (maxDate + " " + metadata.lastRefreshed.split(' ')[1]);
      // console.log("FinalTime", finalTime);
    }
    return finalTime
  }
  const mask = (rawValue) => {
    let maskUhcid = [/[0-9]/, /[0-9]/, /[0-9]/, /[0-9]/, "-", /[0-9]/, /[0-9]/, /[0-9]/, /[0-9]/, /[0-9]/, /[0-9]/, /[0-9]/, "-", /[a-zA-Z]/, /[a-zA-Z]/, /[a-zA-Z]/]
    return conformToMask(rawValue, maskUhcid, { guide: false }).conformedValue
  }
  const alertLastRefreshed =()=>{
    if (metadata.lastRefreshed !== 0 && metadata.lastRefreshed !== null && metadata.lastRefreshed !== undefined && metadata['Current CST Time'] !==0 && metadata['Current CST Time'] !== null && metadata['Current CST Time'] !== undefined) {
      let diff = Moment(`${metadata['Current CST Time'].split(' ')[0]}`,'YYYY-MM-DD').diff(`${metadata.lastRefreshed.split(' ')[0]}`,'days')
      if(diff >2){
        return true
      }
      else{
          if(diff > 1){
            if(Moment(`${metadata['Current CST Time'].split(' ')[0]+' '+metadata['Current CST Time'].split(' ')[1]}`, 'YYYY-MM-DD HH:mm:ss').isAfter(`${metadata['Current CST Time'].split(' ')[0]} 07:00:00`,'YYYY-MM-DD HH:mm:ss')){
            return true
            }
            else{
              return false
            }
          }
          else{
            return false
          }
      }
    }
  }
  //console.log('cst time =====>',metadata['Current CST Time'])
  return (
    <div className={classes.root}>
      <div style={{ display: showHideHeaderContent ? "block" : "none" }}>
        <div style={{ display: 'flex' }}>
          <span style={{ display: 'inline-block', width: 1362, paddingTop: '18px' }} >{resultOfFilteredText}</span>
          <Breadcrumbs style={{ paddingTop: 10, position: 'absolute', right: '20px' }}
            separator={<NavigateNextIcon classes={{ root: classes.customLink }} />}
            aria-label="link-levels"
          >
            {/* <span style={{paddingBottom: 0,display:'inline-block',width:1320}} >{resultOfFilteredText}</span> */}
            <Link
              classes={{ root: classes.customLink }}
              href="/providers/search-provider"
            >
              Search
        </Link>
            <Link
              classes={{ root: classes.customLink }}
              href="/providers/result-provider"
            >
              Results
        </Link>
          </Breadcrumbs>
        </div>
        <div className={classes.filterArea} style={{ display: 'flex', paddingTop: 0 }}>
          <div style={{ display: 'inline-block', width: 1240, paddingTop: '18px' }}>
            {filterFields.map(filter => (
              <Chip
                className={classes.customChip}
                key={filter.type}
                //label={`${filter.label}:  ${filter.value}`}
                label={filter.label == 'Zip Code' ? `${filter.label}:${getZipvalue(filter.value)}` : filter.label == 'State' ? `${filter.label}:${getStateValue(filter.value)}` : `${filter.label}:  ${filter.value}`}
                onDelete={event => removeFilter(event, filter)}
                deleteIcon={<ClearIcon />}
              />
            ))}
            {Object.keys(state.newFilter).length === 0 ? (
              state.addFilter ? (
                <FormControl style={{ marginTop: "-15px" }}>
                  <InputLabel htmlFor="age-native-simple" style={{ width: 118 }}> + Add search criteria</InputLabel>
                  <Select
                    native
                    className={classes.selectRoot}
                    value={state.newFilter.label}
                    onChange={handleSelectFilter}
                  >
                    <option></option>
                    {state.customFieldList.map(field => (
                      <option value={field.type} key={field.type}>
                        {field.label}
                      </option>
                    ))}
                  </Select>
                </FormControl>
              ) : (
                  <FormControl style={{ marginTop: "-15px" }}>
                    <InputLabel htmlFor="age-native-simple"> + Add search criteria</InputLabel>
                    <Select
                      native
                      className={classes.selectRoot}
                      value={state.newFilter.label}
                      onChange={handleSelectFilter}
                    >
                      <option></option>
                      {state.customFieldList.map(field => (
                        <option value={field.type} key={field.type}>
                          {field.label}
                        </option>
                      ))}
                    </Select>
                  </FormControl>
                )
            ) : (
                <>
                  <div style={{ display: 'inline-block', verticalAlign: 'top' }}>
                    <Typography className={classes.fieldSet} component="div">
                      {state.newFilter.label}:
            </Typography>
                    <FormControl>{submitFieldSendField()}</FormControl>
                    <Typography className={classes.fieldSet} component="div" onClick={setNewFilterValueclose}  >
                      x
            </Typography>
                  </div>
                </>
              )}
          </div>
          {alertLastRefreshed() ?
            <Tooltip title={<div style={{
              backgroundColor: "white",
              color: "black",
              width: "180px"
            }}>
              <br />
              <div style={{ marginLeft: "10px" }}>
                <span >
                  Data refreshed delayed. Next <br />update To Be Determined
                            </span>
              </div>
              <br />
            </div>} placement="top">
              <span className={classes.dataRefreshError} style={{ position: 'absolute', right: '20px', display: metadata.lastRefreshed !== 0 && metadata.lastRefreshed !== null && metadata.lastRefreshed !== undefined ? '' : 'none' }}>
                Last refreshed: {getTime()} CST
          </span>
            </Tooltip> :
            <span className={classes.daterefresh} style={{ position: 'absolute', right: '20px', display: metadata.lastRefreshed !== 0 && metadata.lastRefreshed !== null && metadata.lastRefreshed !== undefined ? '' : 'none' }}>
              Last refreshed: {getTime()} CST
          </span>
          }
        </div>
        <FormHelperText error style={{ display: state.dependentError ? 'block' : 'none' }}>
          Independent field required, no change in result
        </FormHelperText>
      </div>
    </div>
  );
}
HeaderResultProviderComponent.propTypes = {
  filterFields: PropTypes.arrayOf(PropTypes.any),
  removeResultFilter: PropTypes.func.isRequired,
  setFilterValue: PropTypes.func.isRequired,
  fetchResultsOnFilterChange: PropTypes.func.isRequired,
  resultOfFilteredText: PropTypes.func.isRequired,
  showHideHeaderContent: PropTypes.bool,
  metadata: PropTypes.any
};
export default HeaderResultProviderComponent;
