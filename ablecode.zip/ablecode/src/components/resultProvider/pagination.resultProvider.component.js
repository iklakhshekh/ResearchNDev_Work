/* eslint-disable */
import React from "react";
import PropTypes from "prop-types";

import { makeStyles } from "@material-ui/core/styles";
import Typography from "@material-ui/core/Typography";
import FormControl from "@material-ui/core/FormControl";
import Select from "@material-ui/core/Select";
import MenuItem from "@material-ui/core/MenuItem";
import OutlinedInput from "@material-ui/core/OutlinedInput";
import KeyboardArrowDownIcon from "@material-ui/icons/KeyboardArrowDown";
import Button from "@material-ui/core/Button";
import ChevronLeftIcon from "@material-ui/icons/ChevronLeft";
import ChevronRightIcon from "@material-ui/icons/ChevronRight";
import ListIcon from '@material-ui/icons/List';
// import TableSortLabel from "@material-ui/core/TableSortLabel";
import ReactExport from 'react-data-export';
// import Icon from "@material-ui/core/Icon";
// import SaveIcon from "@material-ui/icons/Save";
import CloudDownloadIcon from "@material-ui/icons/CloudDownload";
import Card from '@material-ui/core/Card';
import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import FormLabel from '@material-ui/core/FormLabel';

const ExcelFile = ReactExport.ExcelFile;
const ExcelSheet = ReactExport.ExcelFile.ExcelSheet;


const useStyles = makeStyles(() => ({
  root: {
    display: "flex",
   // padding: "1rem 0",
    width: "100%",
    position: "sticky",
    bottom: 0,
    backgroundColor: "#FFFFFF"
  },
  subRoot: {
    display: "block",
    padding: "1rem 0"
  },
  subRootNone: {
    display: "none",
    padding: "1rem 0"
  },

  gap: {
    flexGrow: 1
  },
  inputPad: {
    padding: "10px",
    width: "2rem",
    textAlign: "center"
  },
  text: {
    margin: "0.5rem",
    marginTop: "0.7rem"
  },
  pageNavBtn: {
    minWidth: "55px",
    margin: "0 5px"
  },
  radioButton: {
    flexDirection: 'row'
  }
}));

function PaginationResultProviderComponent({
  ExportData = [],
  currentPage,
  onPageChange,
  totalPages,
  itemsPerPageOptions,
  itemsPerPage,
  totalRows,
  onRowsPerPageChange,
  isDisplayPagination,
  handleTaxIdChange,
  handleAddressChange,
  handleMPINChange
}) {
  const classes = useStyles();
  const [state, setState] = React.useState({
    inputPage: currentPage,
    inputError: false,
    isOpen: false,
  });
  const [valueOfMPIN, setvalueOfMPIN] = React.useState('All')
  const [valueOfTaxId, setvalueOfTaxId] = React.useState('All')
  const [valueOfAddress, setvalueOfAddress] = React.useState('All')
  let renderAuthNextButton = () => {
    if (parseInt(currentPage) == totalPages) {
      return (
        <Button
          variant="outlined"
          color="primary"
          disabled="true"
          className={classes.pageNavBtn}
          onClick={event => onPageInputChange(event, parseInt(currentPage) + 1)}
        >
          <ChevronRightIcon />
        </Button>
      );
    } else {
      return (
        <Button
          variant="outlined"
          color="primary"
          className={classes.pageNavBtn}
          onClick={event => onPageInputChange(event, parseInt(currentPage) + 1)}
        >
          <ChevronRightIcon />
        </Button>
      );
    }
  };
  let renderAuthPreviousButton = () => {
    if (parseInt(currentPage) == 1) {
      return (
        <Button
          variant="outlined"
          color="primary"
          disabled="true"
          className={classes.pageNavBtn}
          onClick={event => onPageInputChange(event, parseInt(currentPage) - 1)}
        >
          <ChevronLeftIcon />
        </Button>
      );
    } else {
      return (
        <Button
          variant="outlined"
          color="primary"
          className={classes.pageNavBtn}
          onClick={event => onPageInputChange(event, parseInt(currentPage) - 1)}
        >
          <ChevronLeftIcon />
        </Button>
      );
    }
  };

  function onPageInputChange(event, page) {
    if (page) {
      // page = page > totalPages ? totalPages : page;
      // page = page < 1 ? currentPage : page;
      localStorage.setItem("currentPage", page);
      setState({
        ...state,
        inputPage: page,
        inputError: false
      });
      onPageChange(page);
    } else {
      if (event.target.value) {
        if (!isNaN(event.target.value)) {
          let value = parseInt(event.target.value);
          value = value > totalPages ? totalPages : value;
          value = value < 1 ? currentPage : value;
          setState({
            ...state,
            inputPage: value,
            inputError: false
          });
          onPageChange(value);
        }
      } else if (event.target.value === "") {
        setState({
          ...state,
          inputPage: event.target.value,
          inputError: true
        });
      }
    }
  }
  function getOddOption(inputValue, allowedValue) {
    const availableIndex = allowedValue.indexOf(inputValue);
    if (availableIndex === -1) {
      return (
        <MenuItem key={inputValue} value={inputValue}>
          {inputValue}
        </MenuItem>
      );
    }
  }
  const toggle = () => {
    setState({ isOpen: !state.isOpen })
    setvalueOfMPIN('All')
    setvalueOfTaxId('All')
    setvalueOfAddress('All')
  }
  const handleChangeForMPIN = (event) => {
    setvalueOfMPIN(event.target.value)
    const Mpin = event.target.value
    if (Mpin == "All") {
      handleMPINChange("All")
    } else if (Mpin == "Active") {
      handleMPINChange("Y")
    }
    else if (Mpin == "Inactive") {
      handleMPINChange("N")
    }
  };
  const handleChangeForTaxId = (event) => {
    setvalueOfTaxId(event.target.value)
    const TaxId = event.target.value
    if (TaxId == "All") {
      handleTaxIdChange("All")
    } else if (TaxId == "Active") {
      handleTaxIdChange("Y")
    }
    else if (TaxId == "Inactive") {
      handleTaxIdChange("N")
    }
  };
  const handleChangeForAddress = (event) => {
    setvalueOfAddress(event.target.value)
    const AddressValue = event.target.value
    if (AddressValue == "All") {
      handleAddressChange('All')
    } else if (AddressValue == "Active") {
      handleAddressChange("Y")
    }
    else if (AddressValue == "Inactive") {
      handleAddressChange("N")
    }
  };
  function getDateTimeString(){
    var timeString = new Date().getHours() + ":"+new Date().getMinutes();
    var date = new Date();
    var H = +timeString.substr(0, 2);
    
    var h = (H % 12) || 12;
    if(h.toString().length==1)
    h='0'+h;
    var ampm = H < 12 ? "AM" : "PM";
    timeString = h + (timeString.substr(2, 3).length==2?'0':'')+ timeString.substr(2, 3) + ampm;
    var datePart = (date.getMonth().toString().length==1?'0':'')+ date.getMonth() +'-'+
    (date.getDate().toString().length==1?'0':'')+date.getDate()+'-'+date.getFullYear();
    return datePart+"_"+ timeString;
    }
const filename="ABLE Search Results_"+getDateTimeString()+"_CST";

  return (
    <div className={classes.root}>
      <div
        className={
          isDisplayPagination ? classes.subRootNone : classes.subRoot
        }
      >
        <Typography component="span" className={classes.text}>
          Displaying
        </Typography>
        <FormControl style={{marginTop:"-6px"}} variant="outlined">
          <Select
            id="items-per-page-dropdown"
            value={itemsPerPage}
            onChange={onRowsPerPageChange}
            classes={{ outlined: classes.inputPad }}
            IconComponent={KeyboardArrowDownIcon}
          >
            {getOddOption(itemsPerPage, itemsPerPageOptions)}
            {itemsPerPageOptions.map(len => (
              <MenuItem key={len} value={len}>
                {len}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
        <Typography component="span" className={classes.text}>
          of {totalRows}
        </Typography>
      </div>
      <div className={classes.gap}>
        <div style={{ textAlign: "center", marginTop: "20px" }}>
        


        <ExcelFile filename={filename} style={{ paddingRight: 10 }}  element={<Button
              variant="contained"
              color="primary"
              size="small"
              className={classes.button}
              startIcon={<CloudDownloadIcon />}
            >
              Export Results
            </Button>
          }>
                    <ExcelSheet  dataSet={ExportData} name="MPIM-TIN-Address"/>
                   
                </ExcelFile>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <Button
            variant="contained"
            color="primary"
            size="small"
            className={classes.button}
            startIcon={<ListIcon />}
            onClick={toggle}
          >
            Result Options
            </Button>
        </div>

      </div>
      <div style={{ display: state.isOpen ? "block" : "none", alignContent: 'center'}}>
        <Card style={{ width: 400}} >
          <FormControl component="fieldset" style={{ marginLeft: 55 }}>
            <span style={{ display: 'flex' }}>
              <FormLabel style={{ lineHeight: 3, marginRight: 20 }}>TaxID</FormLabel>
              <RadioGroup aria-label="TaxID" name="TaxID1" value={valueOfTaxId} onChange={handleChangeForTaxId} row>
                <FormControlLabel value="All" control={<Radio size='small' color='default' />} label="All" />
                <FormControlLabel value="Active" control={<Radio size='small' color='default' />} label="Active" />
                <FormControlLabel value="Inactive" control={<Radio size='small' color='default' />} label="Inactive" />
              </RadioGroup>
            </span>
            <span style={{ display: 'flex' }}>
              <FormLabel style={{ lineHeight: 3, marginRight: 5 }}>Address</FormLabel>
              <RadioGroup aria-label="Address" name="Address1" value={valueOfAddress} onChange={handleChangeForAddress} row>
                <FormControlLabel value="All" control={<Radio size='small' color='default' />} label="All" />
                <FormControlLabel value="Active" control={<Radio size='small' color='default' />} label="Active" />
                <FormControlLabel value="Inactive" control={<Radio size='small' color='default' />} label="Inactive" />
              </RadioGroup>
            </span>
            <span style={{ display: 'flex' }}>
              <FormLabel style={{ lineHeight: 3, marginRight: 20 }}>MPIN</FormLabel>
              <RadioGroup aria-label="MPIN" name="MPIN1" value={valueOfMPIN} onChange={handleChangeForMPIN} row>
                <FormControlLabel value="All" control={<Radio size='small' color='default' />} label="All" />
                <FormControlLabel value="Active" control={<Radio size='small' color='default' />} label="Active" />
                <FormControlLabel value="Inactive" control={<Radio size='small' color='default' />} label="Inactive" />
              </RadioGroup>
            </span>
          </FormControl>
        </Card>
      </div>
      <div
        className={
          isDisplayPagination ? classes.subRootNone : classes.subRoot
        }
      >
        <Typography component="span" className={classes.text}>
          Page
        </Typography>
        <OutlinedInput
          classes={{ input: classes.inputPad }}
          value={state.inputPage}
          error={state.inputError}
          onChange={onPageInputChange}
        />
        <Typography component="span" className={classes.text}>
          of {totalPages}
        </Typography>
        {renderAuthPreviousButton()}

        {renderAuthNextButton()}
      </div>
    </div>
  );
}

PaginationResultProviderComponent.propTypes = {
  currentPage: PropTypes.number,
  totalPages: PropTypes.number,
  onPageChange: PropTypes.func,
  itemsPerPageOptions: PropTypes.arrayOf(PropTypes.number),
  itemsPerPage: PropTypes.number,
  totalRows: PropTypes.number,
  onRowsPerPageChange: PropTypes.func,
  ExportData: PropTypes.number,
  handleTaxIdChange: PropTypes.func,
  handleAddressChange: PropTypes.func,
  handleMPINChange: PropTypes.func
};

export default PaginationResultProviderComponent;
