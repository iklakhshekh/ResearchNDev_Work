/* eslint-disable */
import React from "react";
import PropTypes from "prop-types";

import { makeStyles } from "@material-ui/core/styles";
import Divider from "@material-ui/core/Divider";
// import Link from "@material-ui/core/Link";
// import HeaderResultProviderComponent from "./header.resultProvider.component";
import TableResultProviderComponent from "./table.resultProvider.component";
import ErrorComponent from "./error"

const useStyles = makeStyles(() => ({
  root: {
    backgroundColor: "#FFFFFF"
  }
}));

function ResultProviderComponent({
  fetchingResults,
  filterFields,
  resultList,
  removeResultFilter,
  setFilterValue,
  fetchResultsOnFilterChange,
  setSelectedMPIN, resultOfFilteredText,
  fetchResultsOnPageChange,
  metadata,
  fetchResultsOnExportExcel,
  handleError,
  errorDetails
}) {

  // if (resultList != undefined && resultList.length) {
  //   filterFields.filter(obj => {
  //     if (obj.type == "zip") {
  //       resultList = resultList.filter(function (el) {
  //         return (
  //           el.professionalInformation.address.postalAddress.zip == obj.value
  //         );
  //       });
  //       let x = resultList
  //     }
  //   });
  // }
  if (resultList != undefined && resultList.length) {
    filterFields.filter(obj => {
      if (obj.type == "telephone") {
        resultList = resultList.filter(function (el) {
          const telephoneRemove = obj.value.replace(/[- )(]/g, '');
          //const telePho = telephoneRemove.substr(-7);
          return (
            el.addressinfo[0].telephoneinfo.filter(t => t.tel_nbr == telephoneRemove)
          );
        });
      }
    });
  }
  if (metadata.excelData != undefined && metadata.excelData.length) {
    filterFields.filter(obj => {
      if (obj.type == "telephone") {
        metadata.excelData = metadata.excelData.filter(function (el) {
          const telephoneRemove = obj.value.replace(/[- )(]/g, '');
          //const telePho = telephoneRemove.substr(-7);
          return (
            el.addressinfo[0].telephoneinfo.filter(t => t.tel_nbr == telephoneRemove)
          );
        });
      }
    });
  }

  const classes = useStyles();
  return (
    <div className={classes.root}>
      {/* <HeaderResultProviderComponent
        filterFields={filterFields}
        removeResultFilter={removeResultFilter}
        setFilterValue={setFilterValue}
        fetchResultsOnFilterChange={fetchResultsOnFilterChange}
      /> */}
      {
        
        // metadata.metadata.messege == "No Response from Backend" && metadata.metadata.messege !== undefined ?
          // <ErrorComponent></ErrorComponent> :
          <TableResultProviderComponent
            stickyHeader
            resultList={resultList}
            fetchingResults={fetchingResults}
            setSelectedMPIN={setSelectedMPIN}
            resultOfFilteredText={resultOfFilteredText}
            filterFields={filterFields}
            removeResultFilter={removeResultFilter}
            setFilterValue={setFilterValue}
            fetchResultsOnFilterChange={fetchResultsOnFilterChange}
            fetchResultsOnPageChange={fetchResultsOnPageChange}
            metadata={metadata}
            fetchResultsOnExportExcel={fetchResultsOnExportExcel}
            errorDetails={errorDetails}
            handleError={handleError}
          />
      }
    </div>
  );
}

ResultProviderComponent.propTypes = {
  filterFields: PropTypes.arrayOf(PropTypes.any),
  resultList: PropTypes.arrayOf(PropTypes.any),
  removeResultFilter: PropTypes.func.isRequired,
  setFilterValue: PropTypes.func.isRequired,
  fetchingResults: PropTypes.bool.isRequired,
  fetchResultsOnFilterChange: PropTypes.func.isRequired,
  setSelectedMPIN: PropTypes.func.isRequired,
  resultOfFilteredText: PropTypes.func.isRequired,
  start: PropTypes.any,
  count: PropTypes.any,
  errorDetails: PropTypes.any
};

export default ResultProviderComponent;
