/* eslint-disable */
import React from "react";
import PropTypes from "prop-types";
import loder from "../../assets/loderdata.gif";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import Paper from "@material-ui/core/Paper";
import { makeStyles } from "@material-ui/core/styles";
import Typography from "@material-ui/core/Typography";
// import ToggleButton from "@material-ui/lab/ToggleButton";
// import ListIcon from "@material-ui/icons/List";
import Grid from "@material-ui/core/Grid";
import Tooltip from "@material-ui/core/Tooltip";
// import FilterListIcon from "@material-ui/icons/FilterList";
import Autocomplete from "@material-ui/lab/Autocomplete";
import TextField from "@material-ui/core/TextField";
import Chip from "@material-ui/core/Chip";
import { getAddressType } from "../../utils/fields.constant";
// import { getCosmosStatusType } from "../../utils/fields.constant";
import { getTeleStatusType } from "../../utils/fields.constant";
import { getgender } from "../../utils/fields.constant";
import PaginationResultProviderComponent from "./pagination.resultProvider.component";
import Pagination from "./Pagination";
import { useHistory } from "react-router-dom";
import Checkbox from "@material-ui/core/Checkbox";
import CheckBoxOutlineBlankIcon from "@material-ui/icons/CheckBoxOutlineBlank";
import CheckBoxIcon from "@material-ui/icons/CheckBox";
import ReactExport from 'react-data-export';
import TableSortLabel from "@material-ui/core/TableSortLabel";
import Button from "@material-ui/core/Button";
import Icon from "@material-ui/core/Icon";
import SaveIcon from "@material-ui/icons/Save";
import CloudDownloadIcon from "@material-ui/icons/CloudDownload";
import ExpandLessIcon from '@material-ui/icons/ExpandLess';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore'

import RemoveIcon from "@material-ui/icons/RemoveCircleOutlineSharp";
import Header from "../resultProvider/header.resultProvider.component";
import responsePojo from './ResponsePojo';
const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;
const checkedIcon = <CheckBoxIcon fontSize="small" />;
import CloseIcon from '@material-ui/icons/Close';
import SettingsIcon from '@material-ui/icons/Settings';
const addressandpone = (
  <div>
    {" "}
    ADDRESS-TYPE
    <br /> MASTER-ID{" "}
  </div>
);
const pscseq = (
  <div>
    {" "}
    P/S-C
    <br />
    SEQ
  </div>
);
const billSeqLvl = (
  <div>
    {" "}
    BILL
    <br />
    SEQ
  </div>
);
const MPIN = (
  <div>
    {" "}
    MPIN
  </div>
);
const mpinType = (
  <div>
    {" "}
    MPIN
    <br />
    TYPE
  </div>
);
const NPI = (
  <div>
    {" "}
    NPI
  </div>
);
const addressTelephoneLvl = (
  <div>
    {" "}
    ADDRESS/TELEPHONE
  </div>
);
const taxIdType = (
  <div>
    {" "}
    TAXID/
    <br /> TYPE{" "}
    {" "}
  </div>
);
const prefixSuffixLvl = (
  <div>
    {" "}
    PREFIX
    <br /> SUFFIX{" "}
    {" "}
  </div>
);
const providerNameLvl = (
  <div>
    {" "}
    NAME
  </div>
);

const uhcIdLvl = (
  <div>
    {" "}
    UHCID
  </div>
);

const useStyles = makeStyles(() => ({
  customWidth: {
    maxWidth: 500,
  },
  noMaxWidth: {
    maxWidth: 'none',
  },
  root: {
    margin: "0rem -7px  0rem 3px",
    width: "100%"
  },
  container: {
    maxHeight: 600,
    "& table:first-child": {
      "& tr": {
        "& td:first-child, th:first-child": {
          position: "sticky",
          left: 0,
          zIndex: 0
        },
        "& th:first-child": {
          zIndex: 999
        },
        "& td:nth-child(2), th:nth-child(2)": {
          position: "sticky",
          left: "120px",
          zIndex: 0,
          borderRightStyle: "groove"
        },
        "& th:nth-child(2)": {
          zIndex: 999
        }
      }
    }
  },

  CellText: {
    verticalAlign: "top",
    fontSize: "11px"
  },
  headerText: {
    color: "#757588",
    fontWeight: "bold",
    marginTop: "0.75em"
  },
  ListBtn: {
    textAlign: "end"
  },
  tableY: {
    position: "relative",
    backgroundColor: "black",
    fontSize: 12,
    maxHeight: "80vh"
  },
  tableN: {
    backgroundColor: "gray",
    fontSize: 12,
    maxHeight: "80vh"
  },
  myBackgroundColor: {
    color: "black"
  },
  myBackgroundColor1: {
    color: "red"
  },
  nameColumn: {
    borderRight: "2px solid #CCCCCC"
  },
  tele: {},
  toggleBtn: {
    marginRight: "1rem"
  },
  filterList: {
    float: "right"
  },
  rowHeight: {
    //minHeight: '35px'
  },
  customWidthName: {
    maxWidth: '320px'
  }

}));


function TableResultProviderComponent({
  resultList,
  fetchingResults,
  setSelectedMPIN,
  filterFields,
  removeResultFilter,
  setFilterValue,
  fetchResultsOnFilterChange,
  fetchResultsOnPageChange,
  metadata,
  fetchResultsOnExportExcel,
  handleError,
  errorDetails
}) {
  //console.log('meta data in table---->',resultList)
  if (localStorage.getItem("currentPage") <= 1) window.localStorage.clear();
  const classes = useStyles();

  const itemsPerPageOptions = [3, 5, 10];
  let _counter = 0;
  const [state, setState] = React.useState({
    isLoading: true,
    providerList: [],
    providerPageList: [],
    addressList: [],
    primaryAddressIndicator: [],
    billSequenceList: [],
    mpinList: [],
    mpinTypeList: [],
    npiList: [],
    taxIdTypes: [],
    prefixSuffixList: [],
    providerNameList: [],
    addressTelephoneList: [],
    uhcIdList: [],
    addColumnList: [],
    selectedAddress: {},
    selectedprimaryAddressIndicator: {},
    selectedColumn: {},
    selectedBillSequence: {},
    selectedMPIN: {},
    selectedMPINType: {},
    selectedNpi: {},
    selectedTaxIdTypes: {},
    selectedPrefixSuffix: {},
    selectedProviderNameList: {},
    selectedAddressTelephoneList: {},
    selectedUhcid: {},
    isListed: false,
    isFilter: false,
    itemsPerPage: itemsPerPageOptions[0],
    currentPage: localStorage.getItem("currentPage")
      ? localStorage.getItem("currentPage")
      : 1,
    totalCount: 0,
    totalPages: 0,
    val: [],
    chipPsVal: [],
    isDisplayPagination: false,
    pageOfItems: [], //per page items to show here
    staticPageOfItems: [],
    staticPageOfItems_copy: [], //we are using static data (after filter removed)
    pageLoader: false, //pageloader using for next click button in pagination
    nameFilterStatus: false,
    mpinFilterStatus: false,
    mpinTypeFilterStatus: false,
    npiFilterStatus: false,
    taxIdFilterStatus: false,
    presuffFilterStatus: false,
    adressTelephoneFilterStatus: false,
    masterAdressFilterStatus: false,
    pscSeqFilterStatus: false,
    billSeqFilterStatus: false,
    uhcIdFilterStatus: false,
  });

  function new_counter() {
    _counter = _counter + 1;
    return _counter;

  }
  const [header, setHeader] = React.useState(true) //state for displaying header
  const [isExportFileLoadIssue, setIsExportFileLoadIssue] = React.useState(true)
  // console.log("resultList", resultList);
  // console.log("fetchingResults", fetchingResults);
  const onChangePage = list =>
    setState({
      ...state,
      pageOfItems: list.pageOfItemsFormatted,
      isLoading: false,
      pageLoader: false,
      staticPageOfItems: list.staticPageOfItems,
      staticPageOfItems_copy: list.staticPageOfItems,
      addressList: list.getAddressListFormatted,
      primaryAddressIndicator: list.primaryAddressIndicator,
      billSequenceList: list.billSequenceFun,
      mpinList: list.mpinListFun,
      mpinTypeList: list.mpinTypeListFun,
      npiList: list.npiListFun,
      taxIdTypes: list.taxIdTypeListFun,
      prefixSuffixList: list.prefixSuffixListFun,
      providerNameList: list.providerNameListFun,
      addressTelephoneList: list.addressAndTelephoneListFun,
      uhcIdList: list.uhcidInfoFun

    });
  let x = state
  const chipValPs = state.chipPsVal.map((option, index) => {
    //remove chip Icon from p/s-c
    // This is to handle new options added by the user (allowed by freeSolo prop).
    const label = option.title || option;
    return (
      <Chip
        key={label}
        label={label}
        deleteIcon={<RemoveIcon />}
        onDelete={() => {
          setState(state.chipPsVal.filter(entry => entry !== option));
        }}
      />
    );
  });
  //converting a number to number with commas for every 3 digits
  function numberWithCommas(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  }

  const valHtml = state.val.map((option, index) => {
    const label = option.title || option;
    return (
      <Chip
        key={label}
        label={label}
        deleteIcon={<RemoveIcon />}
        onDelete={() => {
          setState(state.val.filter(entry => entry !== option));
        }}
      />
    );
  });

  let history = useHistory();
  function _renderRow(props) {
    setSelectedMPIN(props);
    history.push("/providers/provider-Details");
    // return (
    //  <DetailsRow
    //   {...props}
    //   onDoubleClick={event => handlerowClick(event, props)}
    //  />
    //);
  }
  const handlerowClick = (event, value) => {
    setSelectedMPIN(value);
    history.push("/providers/provider-Details");
  };


  function _style(props) {
    resultList.filter(function (resultList) {
      let newProps = "";
      if (resultList.professionalInformation.activeCode == "Y") {
        newProps = { ...props, className: "myBackgroundColor" };
      } else {
        newProps = { ...props, className: "myBackgroundColor1" };
      }
      return newProps;
    });
  }
  function getTotalPages(totalItems, itemsPerPage) {
    return totalItems % itemsPerPage === 0
      ? parseInt(totalItems / itemsPerPage)
      : parseInt(totalItems / itemsPerPage + 1);
  }

  let getDisplayPagination = totalItems => {
    if (totalItems > 1) return false;
    else return true;
  };

  const onFilterAddressprimaryAddressIndicator = (event, address) => {
    metadata.searchParams.isHeaderFilterApplied = true;
    let responseList = [];
    if (address && address.length > 0) {
      responseList = state.staticPageOfItems.filter(o => {
        return Object.keys(address).every(k => {
          return address.some(f => {
            return (
              o.addressinfo[0].pri_cd + "-" + o.addressinfo[0].corsp_adr_ind ===
              f.primaryAddressIndicator
            );
          });
        });
      });
      handleError('resetfilter', true)
    } else {
      responseList = state.staticPageOfItems;
    }
    if (state.selectedAddress != undefined) {
      responseList = responseList.filter(o => {
        return Object.keys(state.selectedAddress).every(k => {
          return state.selectedAddress.some(f => {
            return (
              o.addressinfo[0].pri_cd + "-" + o.addressinfo[0].corsp_adr_ind ===
              f.primaryAddressIndicator
            );
          });
        });
      });
    }

    const transformedProviderList = responsePojo(responseList, metadata.searchParams);
    setState({
      ...state,
      pageOfItems: transformedProviderList,
      nameFilterStatus: address.length > 0 ? true : false,
      mpinFilterStatus: address.length > 0 ? true : false,
      mpinTypeFilterStatus: address.length > 0 ? true : false,
      npiFilterStatus: address.length > 0 ? true : false,
      taxIdFilterStatus: address.length > 0 ? true : false,
      presuffFilterStatus: address.length > 0 ? true : false,
      adressTelephoneFilterStatus: address.length > 0 ? true : false,
      masterAdressFilterStatus: address.length > 0 ? true : false,
      billSeqFilterStatus: address.length > 0 ? true : false,
      uhcIdFilterStatus: address.length > 0 ? true : false,
    });
  };


  const onFilterAddressMultiple = (event, address) => {
    metadata.searchParams.isHeaderFilterApplied = true;
    let responseList = [];
    if (address && address.length > 0) {
      responseList = state.staticPageOfItems.filter(o => {
        return Object.keys(address).every(k => {
          return address.some(f => {
            return (
              o.adr_typ_cd ===
              f.addressTypeCode
            );
          });
        });
      });
      handleError('resetfilter', true)
    } else {
      responseList = state.staticPageOfItems;
    }
    if (
      state.selectedprimaryAddressIndicator &&
      state.selectedprimaryAddressIndicator.length > 0
    ) {
      responseList = responseList.filter(o => {
        return Object.keys(state.selectedprimaryAddressIndicator).every(k => {
          return state.selectedprimaryAddressIndicator.some(f => {
            return (
              o.addressinfo[0].corsp_adr_ind ===
              f.primaryAddressIndicator
            );
          });
        });
      });
    }
    const transformedProviderList = responsePojo(responseList, metadata.searchParams);
    setState({
      ...state,
      pageOfItems: transformedProviderList,
      nameFilterStatus: address.length > 0 ? true : false,
      mpinFilterStatus: address.length > 0 ? true : false,
      mpinTypeFilterStatus: address.length > 0 ? true : false,
      npiFilterStatus: address.length > 0 ? true : false,
      taxIdFilterStatus: address.length > 0 ? true : false,
      presuffFilterStatus: address.length > 0 ? true : false,
      adressTelephoneFilterStatus: address.length > 0 ? true : false,
      pscSeqFilterStatus: address.length > 0 ? true : false,
      billSeqFilterStatus: address.length > 0 ? true : false,
      uhcIdFilterStatus: address.length > 0 ? true : false,
    });
  };

  const onFilterBillSequence = (event, address) => {
    metadata.searchParams.isHeaderFilterApplied = true;
    let billSequence = ""
    let responseList = [];
    if (address && address.length > 0) {
      responseList = state.staticPageOfItems.filter(o => {
        billSequence = o.addressinfo[0].bill_postal_information.bill_seq_num !== undefined ? "" + o.addressinfo[0].bill_postal_information.bill_seq_num : "";
        return Object.keys(address).every(k => {
          return address.some(f => {
            return (
              billSequence ===
              f.billSequence
            );
          });
        });
      });
      handleError('resetfilter', true)
    } else {
      responseList = state.staticPageOfItems;
    }
    if (
      state.selectedBillSequence &&
      state.selectedBillSequence.length > 0
    ) {
      responseList = responseList.filter(o => {
        billSequence = o.addressinfo[0].bill_postal_information.bill_seq_num !== undefined ? "" + o.addressinfo[0].bill_postal_information.bill_seq_num : "";
        return Object.keys(state.selectedBillSequence).every(k => {
          return state.selectedBillSequence.some(f => {
            return (
              billSequence ===
              f.billSequence
            );
          });
        });
      });
    }
    const transformedProviderList = responsePojo(responseList, metadata.searchParams);
    setState({
      ...state,
      pageOfItems: transformedProviderList,
      nameFilterStatus: address.length > 0 ? true : false,
      mpinFilterStatus: address.length > 0 ? true : false,
      mpinTypeFilterStatus: address.length > 0 ? true : false,
      npiFilterStatus: address.length > 0 ? true : false,
      taxIdFilterStatus: address.length > 0 ? true : false,
      presuffFilterStatus: address.length > 0 ? true : false,
      adressTelephoneFilterStatus: address.length > 0 ? true : false,
      masterAdressFilterStatus: address.length > 0 ? true : false,
      pscSeqFilterStatus: address.length > 0 ? true : false,
      uhcIdFilterStatus: address.length > 0 ? true : false,
    });
  }

  const onFilterMPIN = (event, address) => {
    metadata.searchParams.isHeaderFilterApplied = true;
    let responseList = [];
    if (address && address.length > 0) {
      responseList = state.staticPageOfItems.filter(o => {
        return Object.keys(address).every(k => {
          return address.some(f => {
            return (
              "" + o.prov_id ===
              f.mpin
            );
          });
        });
      });
      handleError('resetfilter', true)
    } else {
      responseList = state.staticPageOfItems;
    }
    if (
      state.selectedMPIN &&
      state.selectedMPIN.length > 0
    ) {
      responseList = responseList.filter(o => {
        return Object.keys(state.selectedMPIN).every(k => {
          return state.selectedMPIN.some(f => {
            return (
              "" + o.prov_id ===
              f.mpin
            );
          });
        });
      });
    }
    const transformedProviderList = responsePojo(responseList, metadata.searchParams);
    setState({
      ...state,
      pageOfItems: transformedProviderList,
      nameFilterStatus: address.length > 0 ? true : false,
      mpinTypeFilterStatus: address.length > 0 ? true : false,
      npiFilterStatus: address.length > 0 ? true : false,
      taxIdFilterStatus: address.length > 0 ? true : false,
      presuffFilterStatus: address.length > 0 ? true : false,
      adressTelephoneFilterStatus: address.length > 0 ? true : false,
      masterAdressFilterStatus: address.length > 0 ? true : false,
      pscSeqFilterStatus: address.length > 0 ? true : false,
      billSeqFilterStatus: address.length > 0 ? true : false,
      uhcIdFilterStatus: address.length > 0 ? true : false,
    });
  }

  const onFilterMPINType = (event, address) => {
    metadata.searchParams.isHeaderFilterApplied = true;
    let responseList = [];
    if (address && address.length > 0) {
      responseList = state.staticPageOfItems.filter(o => {
        return Object.keys(address).every(k => {
          return address.some(f => {
            return (
              o.providerinformation[0].mpin_type ===
              f.mpinType
            );
          });
        });
      });
      handleError('resetfilter', true)
    } else {
      responseList = state.staticPageOfItems;
    }
    if (
      state.selectedMPINType &&
      state.selectedMPINType.length > 0
    ) {
      responseList = responseList.filter(o => {
        return Object.keys(state.selectedMPINType).every(k => {
          return state.selectedMPINType.some(f => {
            return (
              o.providerinformation[0].mpin_type ===
              f.mpinType
            );
          });
        });
      });
    }
    const transformedProviderList = responsePojo(responseList, metadata.searchParams);
    setState({
      ...state,
      pageOfItems: transformedProviderList,
      nameFilterStatus: address.length > 0 ? true : false,
      mpinFilterStatus: address.length > 0 ? true : false,
      npiFilterStatus: address.length > 0 ? true : false,
      taxIdFilterStatus: address.length > 0 ? true : false,
      presuffFilterStatus: address.length > 0 ? true : false,
      adressTelephoneFilterStatus: address.length > 0 ? true : false,
      masterAdressFilterStatus: address.length > 0 ? true : false,
      pscSeqFilterStatus: address.length > 0 ? true : false,
      billSeqFilterStatus: address.length > 0 ? true : false,
      uhcIdFilterStatus: address.length > 0 ? true : false,
    });
  }

  const onFilterNpi = (event, address) => {
    metadata.searchParams.isHeaderFilterApplied = true;
    let responseList = [];
    if (address && address.length > 0) {
      responseList = state.staticPageOfItems.filter(o => {
        return Object.keys(address).every(k => {
          return address.some(f => {
            if (o.providerinformation[0].npiinfo !== undefined && o.providerinformation[0].npiinfo.length > 0) {
              return (
                o.providerinformation[0].npiinfo[0].npi_id ===
                f.npi
              );
            }
          });
        });
      });
      handleError('resetfilter', true)
    } else {
      responseList = state.staticPageOfItems;
    }
    if (
      state.selectedNpi &&
      state.selectedNpi.length > 0
    ) {
      responseList = responseList.filter(o => {
        return Object.keys(state.selectedNpi).every(k => {
          return state.selectedNpi.some(f => {
            if (o.providerinformation[0].npiinfo !== undefined && o.providerinformation[0].npiinfo.length > 0) {
              return (
                o.providerinformation[0].npiinfo[0].npi_id ===
                f.npi
              );
            }
          });
        });
      });
    }
    const transformedProviderList = responsePojo(responseList, metadata.searchParams);
    setState({
      ...state,
      pageOfItems: transformedProviderList,
      nameFilterStatus: address.length > 0 ? true : false,
      mpinFilterStatus: address.length > 0 ? true : false,
      mpinTypeFilterStatus: address.length > 0 ? true : false,
      taxIdFilterStatus: address.length > 0 ? true : false,
      presuffFilterStatus: address.length > 0 ? true : false,
      adressTelephoneFilterStatus: address.length > 0 ? true : false,
      masterAdressFilterStatus: address.length > 0 ? true : false,
      pscSeqFilterStatus: address.length > 0 ? true : false,
      billSeqFilterStatus: address.length > 0 ? true : false,
      uhcIdFilterStatus: address.length > 0 ? true : false,
    });
  }

  const onFilterTaxIdTypes = (event, address) => {
    metadata.searchParams.isHeaderFilterApplied = true;
    let responseList = [];
    if (address && address.length > 0) {
      responseList = state.staticPageOfItems.filter(o => {
        return Object.keys(address).every(k => {
          return address.some(f => {
            // if (o.providerinformation[0].npiinfo !== undefined && o.providerinformation[0].npiinfo.length > 0) {
            return (
              o.tax_id_typ_cd + "-" + o.tax_id_nbr ===
              f.taxIdType
            );
            // }
          });
        });
      });
      handleError('resetfilter', true)
    } else {
      responseList = state.staticPageOfItems;
    }
    if (
      state.selectedTaxIdTypes &&
      state.selectedTaxIdTypes.length > 0
    ) {
      responseList = responseList.filter(o => {
        return Object.keys(state.selectedTaxIdTypes).every(k => {
          return state.selectedTaxIdTypes.some(f => {
            // if (o.providerinformation[0].npiinfo !== undefined && o.providerinformation[0].npiinfo.length > 0) {
            return (
              o.taxidinfo[0].tax_id_typ_cd + "-" + o.tax_id_nbr ===
              f.taxIdType
            );
            // }
          });
        });
      });
    }
    const transformedProviderList = responsePojo(responseList, metadata.searchParams);
    setState({
      ...state,
      pageOfItems: transformedProviderList,
      nameFilterStatus: address.length > 0 ? true : false,
      mpinFilterStatus: address.length > 0 ? true : false,
      mpinTypeFilterStatus: address.length > 0 ? true : false,
      npiFilterStatus: address.length > 0 ? true : false,
      presuffFilterStatus: address.length > 0 ? true : false,
      adressTelephoneFilterStatus: address.length > 0 ? true : false,
      masterAdressFilterStatus: address.length > 0 ? true : false,
      pscSeqFilterStatus: address.length > 0 ? true : false,
      billSeqFilterStatus: address.length > 0 ? true : false,
      uhcIdFilterStatus: address.length > 0 ? true : false,
    });
  }

  const onFilterPrefixSuffix = (event, address) => {
    metadata.searchParams.isHeaderFilterApplied = true;
    let responseList = [];
    if (address && address.length > 0) {
      responseList = state.staticPageOfItems.filter(o => {
        return Object.keys(address).every(k => {
          return address.some(f => {
            // if (o.providerinformation[0].npiinfo !== undefined && o.providerinformation[0].npiinfo.length > 0) {
            return (
              o.addressinfo[0].tops_tin_prfx_cd + "-" + addZerosforZip(o.addressinfo[0].tops_tin_sufx_cd) ===
              f.prefixSuffix
            );
            // }
          });
        });
      });
      handleError('resetfilter', true)
    } else {
      responseList = state.staticPageOfItems;
    }
    if (
      state.selectedPrefixSuffix &&
      state.selectedPrefixSuffix.length > 0
    ) {
      responseList = responseList.filter(o => {
        return Object.keys(state.selectedPrefixSuffix).every(k => {
          return state.selectedPrefixSuffix.some(f => {
            // if (o.providerinformation[0].npiinfo !== undefined && o.providerinformation[0].npiinfo.length > 0) {
            return (
              o.addressinfo[0].tops_tin_prfx_cd + "-" + addZerosforZip(o.addressinfo[0].tops_tin_sufx_cd) ===
              f.prefixSuffix
            );
            // }
          });
        });
      });
    }
    const transformedProviderList = responsePojo(responseList, metadata.searchParams);
    setState({
      ...state,
      pageOfItems: transformedProviderList,
      nameFilterStatus: address.length > 0 ? true : false,
      mpinFilterStatus: address.length > 0 ? true : false,
      mpinTypeFilterStatus: address.length > 0 ? true : false,
      npiFilterStatus: address.length > 0 ? true : false,
      taxIdFilterStatus: address.length > 0 ? true : false,
      adressTelephoneFilterStatus: address.length > 0 ? true : false,
      masterAdressFilterStatus: address.length > 0 ? true : false,
      pscSeqFilterStatus: address.length > 0 ? true : false,
      billSeqFilterStatus: address.length > 0 ? true : false,
      uhcIdFilterStatus: address.length > 0 ? true : false,
    });
  }

  const onFilterProviderName = (event, address) => {
    metadata.searchParams.isHeaderFilterApplied = true;
    let responseList = [];
    if (address && address.length > 0) {
      responseList = state.staticPageOfItems.filter(o => {
        let comma = o.providerinformation[0].prov_typ_cd == "P" ? ", " : " ";
        let space = o.providerinformation[0].nm_sufx_cd !== "" ? " " : "";
        return Object.keys(address).every(k => {
          return address.some(f => {
            // if (o.providerinformation[0].npiinfo !== undefined && o.providerinformation[0].npiinfo.length > 0) {
            return (
              o.providerinformation[0].lst_nm + space + o.providerinformation[0].nm_sufx_cd + comma + o.providerinformation[0].fst_nm + " " + o.providerinformation[0].mdl_nm ===
              f.providerName
            );
            // }
          });
        });
      });
      handleError('resetfilter', true)
    } else {
      responseList = state.staticPageOfItems;
    }
    if (
      state.selectedProviderNameList &&
      state.selectedProviderNameList.length > 0
    ) {
      responseList = responseList.filter(o => {
        return Object.keys(state.selectedProviderNameList).every(k => {
          return state.selectedProviderNameList.some(f => {
            // if (o.providerinformation[0].npiinfo !== undefined && o.providerinformation[0].npiinfo.length > 0) {
            return (
              o.providerinformation[0].lst_nm + o.providerinformation[0].nm_sufx_cd + ", " + o.providerinformation[0].fst_nm + " " + o.providerinformation[0].mdl_nm ===
              f.providerName
            );
            // }
          });
        });
      });
    }
    const transformedProviderList = responsePojo(responseList, metadata.searchParams);
    setState({
      ...state,
      pageOfItems: transformedProviderList,
      mpinFilterStatus: address.length > 0 ? true : false,
      mpinTypeFilterStatus: address.length > 0 ? true : false,
      npiFilterStatus: address.length > 0 ? true : false,
      taxIdFilterStatus: address.length > 0 ? true : false,
      presuffFilterStatus: address.length > 0 ? true : false,
      adressTelephoneFilterStatus: address.length > 0 ? true : false,
      masterAdressFilterStatus: address.length > 0 ? true : false,
      pscSeqFilterStatus: address.length > 0 ? true : false,
      billSeqFilterStatus: address.length > 0 ? true : false,
      uhcIdFilterStatus: address.length > 0 ? true : false,
    });
  }

  const onFilterAddressTelephone = (event, address) => {
    metadata.searchParams.isHeaderFilterApplied = true;
    let responseList = [];
    let addressInfoObj;
    let addressInfoData;
    let addressInfoSlct;
    let addressInfoSlctData;
    if (address && address.length > 0) {
      responseList = state.staticPageOfItems.filter(o => {
        addressInfoObj = getFilterAddress(o.addressinfo);
        addressInfoData = addressInfoObj[0].postaladdressinfo.adr_ln_1_txt + " " +
          addressInfoObj[0].postaladdressinfo.cty_nm + " " +
          addressInfoObj[0].postaladdressinfo.st_cd + " " +
          addZerosforZip(addressInfoObj[0].postaladdressinfo.zip_cd) + " " +
          addZeros(addressInfoObj[0].postaladdressinfo.zip_pls_4_cd) + " " +
          addressInfoObj[0].telephoneinfo[0].tel_use_typ_cd + "-" +
          addressInfoObj[0].telephoneinfo[0].tel_nbr
        // addressInfoObj[0].telephoneinfo[0].area_cd +
        // addressInfoObj[0].telephoneinfo[0].tel_nbr.substring(0, 3) +
        // addressInfoObj[0].telephoneinfo[0].tel_nbr.substring(3)
        return Object.keys(address).every(k => {
          return address.some(f => {
            return (
              addressInfoData ===
              f.addressTelephone
            );
            // }
          });
        });
      });
      handleError('resetfilter', true)
    } else {
      responseList = state.staticPageOfItems;
    }
    if (
      state.selectedAddressTelephoneList &&
      state.selectedAddressTelephoneList.length > 0
    ) {
      responseList = responseList.filter(o => {
        addressInfoSlct = getFilterAddress(o.addressinfo);
        addressInfoSlctData = addressInfoSlct[0].postaladdressinfo.adr_ln_1_txt + " " +
          addressInfoSlct[0].postaladdressinfo.cty_nm + " " +
          addressInfoSlct[0].postaladdressinfo.st_cd + " " +
          addZerosforZip(addressInfoSlct[0].postaladdressinfo.zip_cd) + " " +
          addZeros(addressInfoSlct[0].postaladdressinfo.zip_pls_4_cd) + " " +
          addressInfoSlct[0].telephoneinfo[0].tel_use_typ_cd + "-" +
          addressInfoSlct[0].telephoneinfo[0].tel_nbr
        // addressInfoSlct[0].telephoneinfo[0].area_cd +
        // addressInfoSlct[0].telephoneinfo[0].tel_nbr.substring(0, 3) +
        // addressInfoSlct[0].telephoneinfo[0].tel_nbr.substring(3)
        return Object.keys(state.selectedAddressTelephoneList).every(k => {
          return state.selectedAddressTelephoneList.some(f => {
            return (
              addressInfoSlctData ===
              f.addressTelephone
            );
            // }
          });
        });
      });
    }
    const transformedProviderList = responsePojo(responseList, metadata.searchParams);
    setState({
      ...state,
      pageOfItems: transformedProviderList,
      nameFilterStatus: address.length > 0 ? true : false,
      mpinFilterStatus: address.length > 0 ? true : false,
      mpinTypeFilterStatus: address.length > 0 ? true : false,
      npiFilterStatus: address.length > 0 ? true : false,
      taxIdFilterStatus: address.length > 0 ? true : false,
      presuffFilterStatus: address.length > 0 ? true : false,
      masterAdressFilterStatus: address.length > 0 ? true : false,
      pscSeqFilterStatus: address.length > 0 ? true : false,
      billSeqFilterStatus: address.length > 0 ? true : false,
      uhcIdFilterStatus: address.length > 0 ? true : false,
    });
  }

  function getFilterAddress(addressInfo) {
    if (addressInfo.length > 1) {
      addressInfo = addressInfo.filter(adObj => adObj.address_flag === "A");
      if (addressInfo.length <= 0)
        addressInfo = addressInfo.addressinfo
    }
    // addressInfo.telephoneinfo = addressInfo.telephoneinfo
    let telephoneObj
    let telephoneinfo = addressInfo[0].telephoneinfo;
    // if (params.telephone !== "") {
    //   telephoneObj = telephoneinfo.filter(teleObj => teleObj.tel_nbr === params.telephone)
    // } else {
    // telephoneObj = telephoneinfo.filter(teleObj => teleObj.pri_cd === "P")
    // }
    if (metadata.searchParams.telephone !== "") {
      telephoneObj = telephoneinfo.filter(teleObj => teleObj.tel_nbr === metadata.searchParams.telephone)
    } else {
      telephoneObj = telephoneinfo.filter(teleObj => teleObj.pri_cd === "P")
    }
    addressInfo[0].telephoneinfo = telephoneObj
    return addressInfo
  }

  const onFilterUhcID = (event, address) => {
    metadata.searchParams.isHeaderFilterApplied = true;
    let responseList = [];
    if (address && address.length > 0) {
      responseList = state.staticPageOfItems.filter(o => {
        return Object.keys(address).every(k => {
          return address.some(f => {
            if (o.addressinfo[0].uhcidinfo !== undefined && o.addressinfo[0].uhcidinfo.length > 0) {

              return (
                "" + o.addressinfo[0].uhcidinfo.filter(item => item.uhc_id === f.uhcId)
              );
            }
          });
        });
      });
      handleError('resetfilter', true)
    } else {
      responseList = state.staticPageOfItems;
    }
    if (
      state.selectedUhcid &&
      state.selectedUhcid.length > 0
    ) {
      responseList = responseList.filter(o => {
        return Object.keys(state.selectedUhcid).every(k => {
          return state.selectedUhcid.some(f => {
            if (o.addressinfo[0].uhcidinfo !== undefined && o.addressinfo[0].uhcidinfo.length > 0) {
              return (
                "" + o.addressinfo[0].uhcidinfo.filter(item => item.uhc_id === f.uhcId)
              );
            }
          });
        });
      });
    }
    const transformedProviderList = responsePojo(responseList, metadata.searchParams);
    setState({
      ...state,
      pageOfItems: transformedProviderList,
      nameFilterStatus: address.length > 0 ? true : false,
      mpinFilterStatus: address.length > 0 ? true : false,
      mpinTypeFilterStatus: address.length > 0 ? true : false,
      npiFilterStatus: address.length > 0 ? true : false,
      taxIdFilterStatus: address.length > 0 ? true : false,
      presuffFilterStatus: address.length > 0 ? true : false,
      adressTelephoneFilterStatus: address.length > 0 ? true : false,
      masterAdressFilterStatus: address.length > 0 ? true : false,
      pscSeqFilterStatus: address.length > 0 ? true : false,
      billSeqFilterStatus: address.length > 0 ? true : false,
    });
  }

  const clearAllFilters = () => {
    setState({
      ...state,
      selectedAddress: {},
      selectedprimaryAddressIndicator: {},
      selectedColumn: {},
      selectedBillSequence: {},
      selectedMPIN: {},
      selectedMPINType: {},
      selectedNpi: {},
      selectedTaxIdTypes: {},
      selectedPrefixSuffix: {},
      selectedProviderNameList: {},
      selectedAddressTelephoneList: {},
      nameFilterStatus: false,
      mpinFilterStatus: false,
      mpinTypeFilterStatus: false,
      npiFilterStatus: false,
      taxIdFilterStatus: false,
      presuffFilterStatus: false,
      adressTelephoneFilterStatus: false,
      masterAdressFilterStatus: false,
      pscSeqFilterStatus: false,
      billSeqFilterStatus: false
    })

    const transformedProviderList = responsePojo(state.staticPageOfItems, metadata.searchParams);
    setState({
      ...state,
      pageOfItems: transformedProviderList
    });


    document.getElementById("filter-addres1").nextElementSibling.children[0].click()
    document.getElementById("filter-addres4").nextElementSibling.children[0].click()
    document.getElementById("filter-addres5").nextElementSibling.children[0].click()
    document.getElementById("filter-addres6").nextElementSibling.children[0].click()
    document.getElementById("filter-addres7").nextElementSibling.children[0].click()
    document.getElementById("filter-addres8").nextElementSibling.children[0].click()
    document.getElementById("filter-addres10").nextElementSibling.children[0].click()
    document.getElementById("filter-addres11").nextElementSibling.children[0].click()
    document.getElementById("filter-addres13").nextElementSibling.children[0].click()
    document.getElementById("filter-addres14").nextElementSibling.children[0].click()
    document.getElementById("filter-addres2").nextElementSibling.children[0].click()


    document.getElementById("filter-addres2").blur()
    metadata.searchParams.isHeaderFilterApplied = false


  }
  //console.log("sssssssssss------>",document.getElementById("filter-addres1"))
  const filteredContentWithOneParameter = (mpinValue, taxidValue, addressValue) => {
    let responseList = [];
    responseList = state.staticPageOfItems.filter(o => {
      return (
        mpinValue !== '' ? o.providerinformation[0].mpin_flag === mpinValue : true &&
          taxidValue !== '' ? o.taxidinfo[0].mpin_tin_flag === taxidValue : true &&
            addressValue !== '' ? o.addressinfo[0].address_flag === addressValue : true
      );
    });
    const transformedProviderList = responsePojo(responseList, metadata.searchParams);
    setState({
      ...state,
      pageOfItems: transformedProviderList,
    });
  }

  const filteredContentWithThreeParameters = (mpinValue, taxidValue, addressValue) => {
    let responseList = [];
    responseList = state.staticPageOfItems.filter(o => {
      return (
        o.providerinformation[0].mpin_flag === mpinValue &&
        o.taxidinfo[0].mpin_tin_flag === taxidValue &&
        o.addressinfo[0].address_flag === addressValue
      );
    });
    const transformedProviderList = responsePojo(responseList, metadata.searchParams);
    setState({
      ...state,
      pageOfItems: transformedProviderList,
    });
  }

  const filteredContentWithTaxidAddress = (taxidValue, addressValue) => {
    let responseList = [];
    responseList = state.staticPageOfItems.filter(o => {
      return (
        o.taxidinfo[0].mpin_tin_flag === taxidValue &&
        o.addressinfo[0].address_flag === addressValue
      );
    });
    const transformedProviderList = responsePojo(responseList, metadata.searchParams);
    setState({
      ...state,
      pageOfItems: transformedProviderList,
    });
  }

  const filteredContentWithMpinAddress = (mpinValue, addressValue) => {
    let responseList = [];
    responseList = state.staticPageOfItems.filter(o => {
      return (
        o.providerinformation[0].mpin_flag === mpinValue &&
        o.addressinfo[0].address_flag === addressValue
      );
    });
    const transformedProviderList = responsePojo(responseList, metadata.searchParams);
    setState({
      ...state,
      pageOfItems: transformedProviderList,
    });
  }

  const filteredContentWithMpinTaxid = (mpinValue, taxidValue) => {
    let responseList = [];
    responseList = state.staticPageOfItems.filter(o => {
      return (
        o.providerinformation[0].mpin_flag === mpinValue &&
        o.taxidinfo[0].mpin_tin_flag === taxidValue
      );
    });
    const transformedProviderList = responsePojo(responseList, metadata.searchParams);
    setState({
      ...state,
      pageOfItems: transformedProviderList,
    });
  }

  const handleResultFilterChange = (filter1, value1, filter2, value2, filter3, value3) => {
    clearAllFilters()
    if (filter1 == 'MPIN' && value2 == 'All' && value3 == 'All') {
      if (value1 == 'A' || value1 == 'I') {
        filteredContentWithOneParameter(value1, '', '')
      }
    }
    if (value1 == 'All' && filter2 == 'TAXID' && value3 == 'All') {
      if (value2 == 'A' || value2 == 'I') {
        filteredContentWithOneParameter('', value2, '')
      }
    }
    if (value1 == 'All' && value2 == 'All' && filter3 == 'ADDRESS') {
      if (value3 == 'A' || value3 == 'I') {
        filteredContentWithOneParameter('', '', value3)
      }
    }
    if (value1 == 'All' && value2 !== 'All' && value3 !== 'All') {
      filteredContentWithTaxidAddress(value2, value3)
    }
    if (value1 !== 'All' && value2 == 'All' && value3 !== 'All') {
      filteredContentWithMpinAddress(value1, value3)
    }
    if (value1 !== 'All' && value2 !== 'All' && value3 == 'All') {
      filteredContentWithMpinTaxid(value1, value2)
    }
    if (value1 !== 'All' && value2 !== 'All' && value3 !== 'All') {
      filteredContentWithThreeParameters(value1, value2, value3)
    }
    if (value1 == 'All' && value2 == 'All' && value3 == 'All') {
      const transformedProviderList = responsePojo(state.staticPageOfItems, metadata.searchParams);
      setState({
        ...state,
        pageOfItems: transformedProviderList
      });
    }
  }

  const addZeros = (value) => {
    if (value.length !== 0) {
      for (let i = value.length; i < 4; i++) {
        value = '0' + value;
      }
      return value
    }
  }

  const addZerosforZip = (value) => {
    if (value.length !== 0) {
      for (let i = value.length; i < 5; i++) {
        value = '0' + value;
      }
      return value
    }
  }
  const multiDataSet_with_search_param = [
    {
      columns: [
        {
          title: "MPIN",
          width: { wpx: 50 },
          style: {
            font: { sz: "8", color: { rgb: "FFFFFF" }, bold: true, name: "Roboto" },
            fill: { fgColor: { rgb: "504E66" } }
          }
        },
        {
          title: "PTIMPIN",
          width: { wpx: 45 },
          style: {
            font: { sz: "8", color: { rgb: "FFFFFF" }, bold: true, name: "Roboto" },
            fill: { fgColor: { rgb: "504E66" } }
          }
        },
        {
          title: "MAID",
          width: { wpx: 35 },
          style: {
            font: { sz: "8", color: { rgb: "FFFFFF" }, bold: true, name: "Roboto" },
            fill: { fgColor: { rgb: "504E66" } }
          }
        },
        {
          title: "BAID",
          width: { wpx: 35 },
          style: {
            font: { sz: "8", color: { rgb: "FFFFFF" }, bold: true, name: "Roboto" },
            fill: { fgColor: { rgb: "504E66" } }
          }
        },
        {
          title: "UHC ID",
          width: { wpx: 40 },
          style: {
            font: { sz: "8", color: { rgb: "FFFFFF" }, bold: true, name: "Roboto" },
            fill: { fgColor: { rgb: "504E66" } }
          }
        },
        {
          title: "TAX ID",
          width: { wpx: 40 },
          style: {
            font: { sz: "8", color: { rgb: "FFFFFF" }, bold: true, name: "Roboto" },
            fill: { fgColor: { rgb: "504E66" } }
          }
        },
        {
          title: "SSN",
          width: { wpx: 35 },
          style: {
            font: { sz: "8", color: { rgb: "FFFFFF" }, bold: true, name: "Roboto" },
            fill: { fgColor: { rgb: "504E66" } }
          }
        },
        {
          title: "NPI",
          width: { wpx: 35 },
          style: {
            font: { sz: "8", color: { rgb: "FFFFFF" }, bold: true, name: "Roboto" },
            fill: { fgColor: { rgb: "504E66" } }
          }
        },
        {
          title: "PFX/SFX",
          width: { wpx: 45 },
          style: {
            font: { sz: "8", color: { rgb: "FFFFFF" }, bold: true, name: "Roboto" },
            fill: { fgColor: { rgb: "504E66" } }
          }
        },
        {
          title: "Last Group Name",
          width: { wpx: 100 },
          style: {
            font: { sz: "8", color: { rgb: "FFFFFF" }, bold: true, name: "Roboto" },
            fill: { fgColor: { rgb: "504E66" } }
          }
        },
        {
          title: "First Name",
          width: { wpx: 100 },
          style: {
            font: { sz: "8", color: { rgb: "FFFFFF" }, bold: true, name: "Roboto" },
            fill: { fgColor: { rgb: "504E66" } }
          }
        },
        {
          title: "Middle Name",
          width: { wpx: 100 },
          style: {
            font: { sz: "8", color: { rgb: "FFFFFF" }, bold: true, name: "Roboto" },
            fill: { fgColor: { rgb: "504E66" } }
          }
        },
        {
          title: "Telephone",
          width: { wpx: 55 },
          style: {
            font: { sz: "8", color: { rgb: "FFFFFF" }, bold: true, name: "Roboto" },
            fill: { fgColor: { rgb: "504E66" } }
          }
        },
        {
          title: "State",
          width: { wpx: 40 },
          style: {
            font: { sz: "8", color: { rgb: "FFFFFF" }, bold: true, name: "Roboto" },
            fill: { fgColor: { rgb: "504E66" } }
          }
        },
        {
          title: "ZIP Code",
          width: { wpx: 55 },
          style: {
            font: { sz: "8", color: { rgb: "FFFFFF" }, bold: true, name: "Roboto" },
            fill: { fgColor: { rgb: "504E66" } }
          }
        },
        {
          title: "Last Refreshed",
          width: { wpx: 160 },
          style: {
            font: { sz: "8", color: { rgb: "FFFFFF" }, bold: true, name: "Roboto" },
            fill: { fgColor: { rgb: "504E66" } }
          }
        },
      ],
      data: []
    }
  ];

  const getTime = () => {
    var finalTime = null;
    if (metadata.lastRefreshed !== 0 && metadata.lastRefreshed !== null && metadata.lastRefreshed !== undefined) {
      var dateFormat = metadata.lastRefreshed;
      // console.log("last refreshed date",metadata.lastRefreshed)
      const timeFormat = dateFormat.replace(/[- )(]/g, '');
      const time = timeFormat.substr(-12);
      const str = time.slice(0, -4);
      const maxDate = Moment(dateFormat).format('MM-DD-YYYY');
      finalTime = (maxDate + " " + str);
      // console.log("FinalTime", finalTime);
    }
    return finalTime
  }

  if (metadata.excelData !== undefined && metadata.excelData.length > 0) {
    let exportExcelData = responsePojo(metadata.excelData, metadata.searchParams)
    var _listObj_wiath_param = [];
    exportExcelData.forEach(obj => {

      obj.addressDetails.forEach(function (ad) {
        // console.log("Metadata here Export 22 --1 33333 ===== ", ad)

        var _name = false;
        var _mpin = false;
        // var _npi = {row.npi };
        var mpin = {
          value: metadata.searchParams.mpin,
          style: {
            font: {
              sz: "7",
              name: "Roboto",
              bold: false

            },
            alignment: {
              vertical: "top"
            },
            border: {
              right: { style: "thin", color: "black" },
              top: { style: "thin", color: { rgb: _name ? "FFFFFF" : "" } }
            }
          }
        };
        var ptiMpin = {
          value: metadata.searchParams.ptiMpin,
          style: {
            font: {
              sz: "7",
              name: "Roboto",
              bold: false

            },
            alignment: {
              vertical: "top"
            },
            border: {
              right: { style: "thin", color: "black" },
              top: { style: "thin", color: { rgb: _name ? "FFFFFF" : "" } }
            }
          }
        };
        var maid = {
          value: metadata.searchParams.maid,
          style: {
            font: {
              sz: "7",
              name: "Roboto",
              bold: false

            },
            alignment: {
              vertical: "top"
            },
            border: {
              right: { style: "thin", color: "black" },
              top: { style: "thin", color: { rgb: _name ? "FFFFFF" : "" } }
            }
          }
        };
        var baid = {
          value: metadata.searchParams.baid,
          style: {
            font: {
              sz: "7",
              name: "Roboto",
              bold: false

            },
            alignment: {
              vertical: "top"
            },
            border: {
              right: { style: "thin", color: "black" },
              top: { style: "thin", color: { rgb: _name ? "FFFFFF" : "" } }
            }
          }
        };
        var uhcid = {
          value: metadata.searchParams.uhcid, //+ obj.addressDetails.filter((obj) => obj.corpOwnerFlag == "Y").length >= 1 ? "***" : "",
          style: {
            font: {
              sz: "7",
              name: "Roboto",
              bold: false

            },
            alignment: {
              vertical: "top"
            },
            border: {
              right: { style: "thin", color: "black" },
              top: { style: "thin", color: { rgb: _name ? "FFFFFF" : "" } }
            }
          }
        };
        var taxId = {
          value: metadata.searchParams.taxId,
          style: {
            font: {
              sz: "7",
              name: "Roboto",
              bold: false

            },
            alignment: {
              vertical: "top"
            },
            border: {
              right: { style: "thin", color: "black" },
              top: { style: "thin", color: { rgb: _name ? "FFFFFF" : "" } }
            }
          }
        };
        var ssn = {
          value: metadata.searchParams.ssn, //+ obj.addressDetails.filter((obj) => obj.corpOwnerFlag == "Y").length >= 1 ? "***" : "",
          style: {
            font: {
              sz: "7",
              name: "Roboto",
              bold: false

            },
            alignment: {
              vertical: "top"
            },
            border: {
              right: { style: "thin", color: "black" },
              top: { style: "thin", color: { rgb: _name ? "FFFFFF" : "" } }
            }
          }
        };
        var npi = {
          value: metadata.searchParams.npi,
          style: {
            font: {
              sz: "7",
              name: "Roboto",
              bold: false

            },
            alignment: {
              vertical: "top"
            },
            border: {
              right: { style: "thin", color: "black" },
              top: { style: "thin", color: { rgb: _name ? "FFFFFF" : "" } }
            }
          }
        };
        var pfxsfx = {
          value: metadata.searchParams.pfxsfx,
          style: {
            font: {
              sz: "7",
              name: "Roboto",
              bold: false

            },
            alignment: {
              vertical: "top"
            },
            border: {
              right: { style: "thin", color: "black" },
              top: { style: "thin", color: { rgb: _name ? "FFFFFF" : "" } }
            }
          }
        };
        var lastGroupName = {
          value: metadata.searchParams.lastGroupName,
          style: {
            font: {
              sz: "7",
              name: "Roboto",
              bold: false

            },
            alignment: {
              vertical: "top"
            },
            border: {
              right: { style: "thin", color: "black" },
              top: { style: "thin", color: { rgb: _name ? "FFFFFF" : "" } }
            }
          }
        };
        var firstName = {
          value: metadata.searchParams.firstName,
          style: {
            font: {
              sz: "7",
              name: "Roboto",
              bold: false

            },
            alignment: {
              vertical: "top"
            },
            border: {
              right: { style: "thin", color: "black" },
              top: { style: "thin", color: { rgb: _name ? "FFFFFF" : "" } }
            }
          }
        };
        var middleName = {
          value: metadata.searchParams.middleName,
          style: {
            font: {
              sz: "7",
              name: "Roboto",
              bold: false

            },
            alignment: {
              vertical: "top"
            },
            border: {
              right: { style: "thin", color: "black" },
              top: { style: "thin", color: { rgb: _name ? "FFFFFF" : "" } }
            }
          }
        };
        var telephone = {
          value: metadata.searchParams.telephone !== "" ? metadata.searchParams.telephone : "", //+ obj.addressDetails.filter((obj) => obj.corpOwnerFlag == "Y").length >= 1 ? "***" : "",
          style: {
            font: {
              sz: "7",
              name: "Roboto",
              bold: false

            },
            alignment: {
              vertical: "top"
            },
            border: {
              right: { style: "thin", color: "black" },
              top: { style: "thin", color: { rgb: _name ? "FFFFFF" : "" } }
            }
          }
        };
        var state = {
          value: metadata.searchParams.state,
          style: {
            font: {
              sz: "7",
              name: "Roboto",
              bold: false

            },
            alignment: {
              vertical: "top"
            },
            border: {
              right: { style: "thin", color: "black" },
              top: { style: "thin", color: { rgb: _name ? "FFFFFF" : "" } }
            }
          }
        };
        var zip = {
          value: metadata.searchParams.zip, //+ obj.addressDetails.filter((obj) => obj.corpOwnerFlag == "Y").length >= 1 ? "***" : "",
          style: {
            font: {
              sz: "7",
              name: "Roboto",
              bold: false

            },
            alignment: {
              vertical: "top"
            },
            border: {
              right: { style: "thin", color: "black" },
              top: { style: "thin", color: { rgb: _name ? "FFFFFF" : "" } }
            }
          }
        };
        var lastRefreshed = {
          value: metadata.metadata.lastRefreshed + " CST",//getTime() + "CST", //metadata.metadata.lastRefreshed,
          style: {
            font: {
              sz: "7",
              name: "Roboto",
              bold: false
            },
            alignment: {
              vertical: "top"
            },
            border: {
              right: { style: "thin", color: "black" },
              top: { style: "thin", color: { rgb: _name ? "FFFFFF" : "" } }
            }
          }
        };
        if (_listObj_wiath_param.length == 0) {
          _listObj_wiath_param.push(mpin);
          _listObj_wiath_param.push(ptiMpin);
          _listObj_wiath_param.push(maid);
          _listObj_wiath_param.push(baid);
          _listObj_wiath_param.push(uhcid);
          _listObj_wiath_param.push(taxId);
          _listObj_wiath_param.push(ssn);
          _listObj_wiath_param.push(npi);
          _listObj_wiath_param.push(pfxsfx);
          _listObj_wiath_param.push(lastGroupName);
          _listObj_wiath_param.push(firstName);
          _listObj_wiath_param.push(middleName);
          _listObj_wiath_param.push(telephone);
          _listObj_wiath_param.push(state);
          _listObj_wiath_param.push(zip);
          _listObj_wiath_param.push(lastRefreshed);
          multiDataSet_with_search_param[0].data.push(_listObj_wiath_param);
        }
        else {

        }





      });
    });


  }



  const csvData = [];
  const multiDataSet = [
    {
      columns: [
        {
          title: "Name",
          width: { wpx: 100 },
          style: {
            font: { sz: "8", color: { rgb: "FFFFFF" }, bold: true, name: "Roboto" },
            fill: { fgColor: { rgb: "504E66" } }
          }
        }, //pixels width
        {
          title: "Gender",
          width: { wpx: 40 },
          style: {
            font: { sz: "8", color: { rgb: "FFFFFF" }, bold: true, name: "Roboto" },
            fill: { fgColor: { rgb: "504E66" } }
          }
        },
        {
          title: "DOB",
          width: { wpx: 50 },
          style: {
            font: { sz: "8", color: { rgb: "FFFFFF" }, bold: true, name: "Roboto" },
            fill: { fgColor: { rgb: "504E66" } }
          }
        }, //pixels width

        {
          title: "MPIN",
          width: { wpx: 50 },
          style: {
            font: { sz: "8", color: { rgb: "FFFFFF" }, bold: true, name: "Roboto" },
            fill: { fgColor: { rgb: "504E66" } }
          }
        }, //char width
        {
          title: "MPIN Type",
          width: { wpx: 50 },
          style: {
            font: { sz: "8", color: { rgb: "FFFFFF" }, bold: true, name: "Roboto" },
            fill: { fgColor: { rgb: "504E66" } }
          }
        },
        {
          title: "Degree",
          width: { wpx: 50 },
          style: {
            font: { sz: "8", color: { rgb: "FFFFFF" }, bold: true, name: "Roboto" },
            fill: { fgColor: { rgb: "504E66" } }
          }
        },
        {
          title: "Services",
          width: { wpx: 65 },
          style: {
            font: { sz: "8", color: { rgb: "FFFFFF" }, bold: true, name: "Roboto" },
            fill: { fgColor: { rgb: "504E66" } }
          }
        },
        {
          title: "NPI",
          width: { wpx: 55 },
          style: {
            font: { sz: "8", color: { rgb: "FFFFFF" }, bold: true, name: "Roboto" },
            fill: { fgColor: { rgb: "504E66" } }
          }
        },

        {
          title: "TAX",
          width: { wpx: 20 },
          style: {
            font: { sz: "8", color: { rgb: "FFFFFF" }, bold: true, name: "Roboto" },
            fill: { fgColor: { rgb: "504E66" } }
          }
        },
        {
          title: "ID/Type",
          width: { wpx: 53 },
          style: {
            font: { sz: "8", color: { rgb: "FFFFFF" }, bold: true, name: "Roboto" },
            fill: { fgColor: { rgb: "504E66" } }
          }
        },
        {
          title: "Corp MPIN/Name",
          width: { wpx: 95 },
          style: {
            font: { sz: "8", color: { rgb: "FFFFFF" }, bold: true, name: "Roboto" },
            fill: { fgColor: { rgb: "504E66" } }
          }
        },
        {
          title: "Prefix/Suffix",
          width: { wpx: 60 },
          style: {
            font: { sz: "8", color: { rgb: "FFFFFF" }, bold: true, name: "Roboto" },
            fill: { fgColor: { rgb: "504E66" } }
          }
        },
        {
          title: "Address/Telephone",
          width: { wch: 20 },
          style: {
            font: { sz: "8", color: { rgb: "FFFFFF" }, bold: true, name: "Roboto" },
            fill: { fgColor: { rgb: "504E66" } }
          }
        },
        {
          title: "Address Type",
          width: { wch: 8 },
          style: {
            font: { sz: "8", color: { rgb: "FFFFFF" }, bold: true, name: "Roboto" },
            fill: { fgColor: { rgb: "504E66" } }
          }
        },
        {
          title: "Master Id",
          width: { wch: 7 },
          style: {
            font: { sz: "8", color: { rgb: "FFFFFF" }, bold: true, name: "Roboto" },
            fill: { fgColor: { rgb: "504E66" } }
          }
        },

        {
          title: "P/S-C",
          width: { wpx: 40 },
          style: {
            font: { sz: "8", color: { rgb: "FFFFFF" }, bold: true, name: "Roboto" },
            fill: { fgColor: { rgb: "504E66" } }
          }
        },
        {
          title: "Seq",
          width: { wpx: 35 },
          style: {
            font: { sz: "8", color: { rgb: "FFFFFF" }, bold: true, name: "Roboto" },
            fill: { fgColor: { rgb: "504E66" } }
          }
        },
        {
          title: "Bill Seq",
          width: { wpx: 40 },
          style: {
            font: { sz: "8", color: { rgb: "FFFFFF" }, bold: true, name: "Roboto" },
            fill: { fgColor: { rgb: "504E66" } }
          }
        },
        {
          title: "BAID",
          width: { wpx: 50 },
          style: {
            font: { sz: "8", color: { rgb: "FFFFFF" }, bold: true, name: "Roboto" },
            fill: { fgColor: { rgb: "504E66" } }
          }
        },
        {
          title: "UHCID",
          width: { wpx: 40 },
          style: {
            font: { sz: "8", color: { rgb: "FFFFFF" }, bold: true, name: "Roboto" },
            fill: { fgColor: { rgb: "504E66" } }
          }
        },
      ],
      data: []
    }
  ];

  function changeDateFormat(inputDate) {  // expects Y-m-d
    // var splitDate = inputDate.split('-');
    // if (splitDate.count == 0) {
    //   return null;
    // }

    // var year = splitDate[0];
    // var month = splitDate[1];
    // var day = splitDate[2];

    // return month + '/' + day + '/' + year;
    let dob = ""
    if (inputDate !== "")
      dob = "##/##/" + inputDate.substring(0, 4)
    return dob
  }


  if (metadata.excelData !== undefined && metadata.excelData.length > 0) {
    // multiDataSet[0].data.push([]);
    // let exportExcelData = responsePojo(metadata.excelData, metadata.searchParams)
    let exportExcelData;
    exportExcelData = [];
    exportExcelData = responsePojo(metadata.excelData, metadata.searchParams)
    exportExcelData.forEach(obj => {
      obj.addressDetails.forEach(function (ad) {
        var _listObj = [];
        var _name = false;
        var _mpin = false;
        // var _npi = {row.npi }
        let dobWithFormat = changeDateFormat(obj.dob)
        let uhcID = "";
        if (metadata.searchParams.uhcid !== '' && (ad.addressinfo.additionalUhcidFlag === "Y" || ad.addressinfo.additionalUhcidFlag === "N"))
          uhcID = ad.addressinfo.uhcidInfo + "*";
        else if (metadata.searchParams.uhcid !== '' && ad.addressinfo.additionalUhcidFlag == "")
          uhcID = ad.addressinfo.uhcidInfo;
        let mpinName = obj.addressDetails.filter((filterObj) => filterObj.corpOwnerFlag == "Y").length >= 1 ? obj.name + "***" : obj.name;
        multiDataSet[0].data.filter(a => {
          if (a[0].value === mpinName) {
            _name = true;
          }
          if (a[0].value === obj.mpin) {
            _mpin = true;
          }
        });
        var name = {
          value: mpinName, //obj.name,// obj.addressDetails.filter((filterObj) => filterObj.corpOwnerFlag == "Y").length >= 1 ? obj.name + "***" : obj.name,
          style: {
            font: {
              sz: "7",
              name: "Roboto",
              bold: false,
              color: {
                rgb: _name
                  ? "FFFFFF"
                  : obj.activeCode === "I"
                    ? "58cde8"
                    : "060606"
              }
            },
            alignment: {
              vertical: "top"
            },
            border: {
              right: { style: "thin", color: "black" },
              top: { style: "thin", color: { rgb: _name ? "FFFFFF" : "" } }
            }
          }
        };
        _listObj.push(name);

        var genderType = {
          value: getgender(obj.gender),
          style: {
            font: {
              sz: "7",
              name: "Roboto",
              bold: false,
              // color: {rgb: _name ? "FFFFFF" : "060606"}
              color: {
                rgb: _name
                  ? "FFFFFF"
                  : obj.activeCode === "I"
                    ? "58cde8"
                    : "060606"
              }
            },
            alignment: {
              vertical: "top"
            },

            border: {
              right: {
                style: "thin",
                color: { rgb: _name ? "FFFFFF" : "FFFFFF" }
              },
              top: { style: "thin", color: { rgb: _name ? "FFFFFF" : "" } }
            }
          }
        };
        _listObj.push(genderType);
        var dob = {
          value: dobWithFormat, //obj.dob.substring(0, 4),
          style: {
            font: {
              sz: "7",
              name: "Roboto",
              bold: false,
              color: {
                rgb: _name
                  ? "FFFFFF"
                  : obj.activeCode === "I"
                    ? "58cde8"
                    : "060606"
              }
            },
            alignment: {
              vertical: "top"
            },

            border: {
              right: {
                style: "thin",
                color: { rgb: _name ? "FFFFFF" : "FFFFFF" }
              },
              top: { style: "thin", color: { rgb: _name ? "FFFFFF" : "" } }
            }
          }
        };
        _listObj.push(dob);
        var mpin = {
          value: obj.mpin,
          style: {
            font: {
              sz: "7",
              name: "Roboto",
              bold: false,
              // color: {rgb: _name ? "FFFFFF" : "060606"}
              color: {
                rgb: _name
                  ? "FFFFFF"
                  : obj.activeCode === "I"
                    ? "58cde8"
                    : "060606"
              }
            },
            alignment: {
              vertical: "top"
            },

            border: {
              right: {
                style: "thin",
                color: { rgb: _name ? "FFFFFF" : "FFFFFF" }
              },
              top: { style: "thin", color: { rgb: _name ? "FFFFFF" : "" } }
            }
          }
        };
        _listObj.push(mpin);
        var mpinType = {
          value: obj.mpinType,
          style: {
            font: {
              sz: "7",
              name: "Roboto",
              bold: false,
              color: {
                rgb: _name
                  ? "FFFFFF"
                  : obj.activeCode === "I"
                    ? "58cde8"
                    : "060606"
              }
            },
            alignment: {
              vertical: "top"
            },

            border: {
              right: {
                style: "thin",
                color: { rgb: _name ? "FFFFFF" : "FFFFFF" }
              },
              top: { style: "thin", color: { rgb: _name ? "FFFFFF" : "" } }
            }
          }
        };
        _listObj.push(mpinType);

        var degree = {
          value: obj.primaryDegreeCode,
          style: {
            font: {
              sz: "7",
              name: "Roboto",
              bold: false,
              color: {
                rgb: _name
                  ? "FFFFFF"
                  : obj.activeCode === "I"
                    ? "58cde8"
                    : "060606"
              }
            },
            alignment: {
              vertical: "top"
            },

            border: {
              right: {
                style: "thin",
                color: { rgb: _name ? "FFFFFF" : "FFFFFF" }
              },
              top: { style: "thin", color: { rgb: _name ? "FFFFFF" : "" } }
            }
          }
        };
        _listObj.push(degree);
        var services = {
          value: obj.services,
          style: {
            font: {
              sz: "7",
              name: "Roboto",
              bold: false,
              color: {
                rgb: _name
                  ? "FFFFFF"
                  : obj.activeCode === "I"
                    ? "58cde8"
                    : "060606"
              }
            },
            alignment: {
              vertical: "top"
            },

            border: {
              right: {
                style: "thin",
                color: { rgb: _name ? "FFFFFF" : "FFFFFF" }
              },
              top: { style: "thin", color: { rgb: _name ? "FFFFFF" : "" } }
            }
          }
        };
        _listObj.push(services);
        var npi = {
          value: obj.npi == 0 ? "" : obj.additionalNpiFlag !== "" ? obj.npi + "*" : obj.additionalNpiFlag === "" ? obj.npi : "",
          style: {
            font: {
              sz: "7",
              name: "Roboto",
              bold: false,
              color: {
                rgb: _name
                  ? "FFFFFF"
                  : obj.activeCode == "A" && obj.npiFlag == "A"
                    ? "060606"
                    : "58cde8"
              }
            },
            alignment: {
              vertical: "top"
            },
            border: {
              right: { style: "thin", color: "black" },
              top: { style: "thin", color: { rgb: _name ? "FFFFFF" : "" } }
            }
          }
        };
        _listObj.push(npi);
        var taxIdType = {
          value: ad.taxtIdTypeCode + "-",
          style: {
            font: {
              sz: "7",
              name: "Roboto",
              bold: true,
              color: {
                rgb: !ad.isTextIdVisible
                  ? "FFFFFF"
                  : ad.taxIdStatus === "I" || obj.activeCode === "I"
                    ? "58cde8"
                    : "0000ff"
              }
            },
            alignment: {
              wrapText: true,
              vertical: "top"
            },
            border: {
              right: {
                style: "thin",
                color: { rgb: _name ? "FFFFFF" : "FFFFFF" }
              },
              top: { style: "thin", color: { rgb: _name ? "FFFFFF" : "" } }
            }
          }
        };
        _listObj.push(taxIdType);
        // let taxId = ""
        var taxIdType = {
          value: ad.corpOwnerFlag === "Y" ? ad.taxtId + "*" : ad.taxtId,
          style: {
            font: {
              sz: "7",
              name: "Roboto",
              bold: true,
              color: {
                rgb: !ad.isTextIdVisible
                  ? "FFFFFF"
                  : ad.taxIdStatus === "I" || obj.activeCode === "I"
                    ? "58cde8"
                    : "060606"
              }
            },
            alignment: {
              vertical: "top"
            },
            border: {
              right: {
                style: "thin",
                color: { rgb: _name ? "FFFFFF" : "FFFFFF" }
              },
              top: { style: "thin", color: { rgb: _name ? "FFFFFF" : "" } }
            }
          }
        };
        _listObj.push(taxIdType);
        var cropmpin = {
          value: ad.corpMpin + " " + ad.corpMpinName,
          style: {
            font: {
              sz: "7",
              name: "Roboto",
              bold: false,
              color: {
                rgb: !ad.isTextIdVisible
                  ? "FFFFFF"
                  : obj.activeCode === "I"
                    ? "58cde8"
                    : "060606"
              }
            },
            alignment: {
              vertical: "top"
            },
            border: {
              right: { style: "thin", color: "black" },
              top: { style: "thin", color: { rgb: _name ? "FFFFFF" : "" } }
            }
          }
        };
        _listObj.push(cropmpin);

        var prefSuff = {
          value:
            ad.addressinfo.topsTinSuffix !== "" && ad.addressinfo.topsTinSuffix !== undefined
              ? ad.addressinfo.topsTinPrefix + "-" + ad.addressinfo.topsTinSuffix
              : "",
          style: {
            font: {
              sz: "7",
              name: "Roboto",
              bold: false,
              color: {
                rgb: ad.taxIDstatus === "I" || obj.activeCode === "I" || ad.addressinfo.addressStatus === "I"
                  ? "58cde8"
                  : "060606"
              }
            },
            alignment: {
              wrapText: true,
              vertical: "top"
            },
            border: {
              right: { style: "thin", color: "black" },
              top: {
                style: "thin",
                color: {
                  rgb:
                    ad.addressinfo.topsTinPrefix == "" &&
                      ad.addressinfo.topsTinSuffix == ""
                      ? "FFFFFF"
                      : ""
                }
              }
            }
          }
        };
        _listObj.push(prefSuff);

        var addTel = {
          value: ad.addressinfo.postaladdressinfo.adr_ln_1_txt
            + '\n' + ad.addressinfo.postaladdressinfo.cty_nm
            + ', ' + ad.addressinfo.postaladdressinfo.st_cd
            + ' ' + addZerosforZip(ad.addressinfo.postaladdressinfo.zip_cd)
            + ' - ' + addZeros(ad.addressinfo.postaladdressinfo.zip_pls_4_cd)
            + '\n' + (ad.addressinfo.telephoneObj ? ad.addressinfo.telephoneObj.tel_use_typ_cd
              + ' - ' + '(' + ad.addressinfo.telephoneObj.tel_nbr.substr(0, 3) + ') '
              + ad.addressinfo.telephoneObj.tel_nbr.substr(3, 3)
              + '-' + ad.addressinfo.telephoneObj.tel_nbr.substr(6, 4)
              + (ad.addressinfo.telephoneObj.ext_nbr !== "0" ? " EXT:" + addZeros(ad.addressinfo.telephoneObj.ext_nbr) : "") + '\n' : ''),
          style: {
            font: {
              sz: "7",
              name: "Roboto",
              bold: false,
              color: {
                rgb:
                  ad.taxIDstatus === "I" ||
                    obj.activeCode === "I" ||
                    ad.addressinfo.addressStatus === "I"
                    ? "58cde8"
                    : "060606"
              }
            },
            alignment: {
              wrapText: true,
              vertical: 'top'
            },
            border: {
              bottom: { style: "thin", color: "black" },
              left: { style: "thin", color: "black" },
              top: { style: "thin", color: "black" }
            }
          }
        };
        _listObj.push(addTel);

        var addTypeMstId = {
          value: getAddressType(ad.addressinfo.addressTypeCode),
          style: {
            font: {
              sz: "7",
              name: "Roboto",
              bold: false,
              color: {
                rgb:
                  ad.taxIdStatus === "I" ||
                    obj.activeCode === "I" ||
                    ad.addressinfo.addressStatus === "I"
                    ? "58cde8"
                    : "060606"
              }
            },
            alignment: {
              wrapText: true,
              vertical: "top"
            },
            border: {
              bottom: { style: "thin", color: "black" },
              left: { style: "thin", color: "black" },
              top: { style: "thin", color: "black" }
            }
          }
        };
        _listObj.push(addTypeMstId);

        var addaddressId = {
          value: ad.addressinfo.addressId,
          style: {
            font: {
              sz: "7",
              name: "Roboto",
              bold: false,
              color: {
                rgb:
                  ad.taxIDstatus === "I" ||
                    obj.activeCode === "I" ||
                    ad.addressinfo.addressStatus === "I"
                    ? "58cde8"
                    : "060606"
              }
            },
            alignment: {
              wrapText: true,
              vertical: "top"
            },
            border: {
              bottom: { style: "thin", color: "black" },
              left: { style: "thin", color: "black" },
              top: { style: "thin", color: "black" }
            }
          }
        };
        _listObj.push(addaddressId);

        var psSeq = {
          value: ad.addressinfo.addressIndicator === "P" ? ad.addressinfo.addressIndicator + " -" + ad.addressinfo.addressCorrespondence : ad.addressinfo.addressIndicator + " -" + ad.addressinfo.addressCorrespondence,
          style: {
            font: {
              sz: "7",
              name: "Roboto",
              bold:
                ad.addressinfo.addressCorrespondence == "P" || ad.addressinfo.addressIndicator == "P"
                  ? true
                  : false,
              color: {
                rgb:
                  ad.taxIDstatus === "I" ||
                    obj.activeCode === "I" ||
                    ad.addressinfo.addressStatus === "I"
                    ? "58cde8"
                    : "060606"
              }
            },
            alignment: {
              wrapText: true,
              vertical: "top"
            },
            border: {
              bottom: { style: "thin", color: "black" },
              left: { style: "thin", color: "black" },
              top: { style: "thin", color: "black" }
            }
          }
        };
        _listObj.push(psSeq);

        var seq = {
          value: ad.addressinfo.epqAddressSequence,
          style: {
            font: {
              sz: "7",
              name: "Roboto",
              bold: false,
              color: {
                rgb:
                  ad.taxIDstatus === "I" ||
                    obj.activeCode === "I" ||
                    ad.addressinfo.addressStatus === "I"
                    ? "58cde8"
                    : "060606"
              }
            },
            alignment: {
              wrapText: true,
              vertical: "top"
            },
            border: {
              bottom: { style: "thin", color: "black" },
              left: { style: "thin", color: "black" },
              top: { style: "thin", color: "black" }
            }
          }
        };
        _listObj.push(seq);

        var billSeq = {
          value: ad.addressinfo.billSequence,
          style: {
            font: {
              sz: "7",
              name: "Roboto",
              bold: false,
              color: {
                rgb:
                  ad.taxIDstatus === "I" ||
                    obj.activeCode === "I" ||
                    ad.addressinfo.addressStatus === "I"
                    ? "58cde8"
                    : "060606"
              }
            },
            alignment: {
              wrapText: true,
              vertical: "top"
            },
            border: {
              bottom: { style: "thin", color: "black" },
              left: { style: "thin", color: "black" },
              top: { style: "thin", color: "black" }
            }
          }
        };
        _listObj.push(billSeq);

        var baid = {
          value: ad.addressinfo.billAddressId,
          style: {
            font: {
              sz: "7",
              name: "Roboto",
              bold: false,
              color: {
                rgb:
                  ad.taxIDstatus === "I" ||
                    obj.activeCode === "I" ||
                    ad.addressinfo.addressStatus === "I"
                    ? "58cde8"
                    : "060606"
              }
            },
            alignment: {
              vertical: "top"
            },
            border: {
              bottom: { style: "thin", color: "black" },
              left: { style: "thin", color: "black" },
              top: { style: "thin", color: "black" }
            }
          }
        };
        _listObj.push(baid);
        var UHCID = {
          value: uhcID,
          style: {
            font: {
              sz: "7",
              name: "Roboto",
              bold: false,
              color: {
                rgb:
                  ad.taxIDstatus === "I" ||
                    obj.activeCode === "I" ||
                    ad.addressinfo.addressStatus === "I" ||
                    ad.addressinfo.uhcidFlag === "I"
                    ? "58cde8"
                    : "060606"
              }
            },
            alignment: {
              wrapText: true,
              vertical: "top"
            },
            border: {
              bottom: { style: "thin", color: "black" },
              left: { style: "thin", color: "black" },
              top: { style: "thin", color: "black" }
            }
          }
        };
        _listObj.push(UHCID);
        multiDataSet[0].data.push(_listObj);

      });
    });
  }
  let rCount = 0;
  let pCount = 0;
  rCount =
    resultList == undefined ? 0 : resultList.length > 0 ? metadata.metadata.total : 0
  pCount =
    // resultList.length > 0 || resultList.length == undefined
    // ? resultList.length
    // : 0;
    resultList == undefined ? 0 : resultList.length > 0 ? metadata.metadata.total : 0
  //console.log("rcount,pcount-------",rCount,pCount)
  function getResultText() {
    return (
      <Grid container>
        <Grid item xs>
          <br />

          <Typography
            style={{ marginLeft: "10px", fontSize: "13px", marginTop: "15px" }}
            className={classes.headerText}
          >
            {rCount && pCount > 0
              ? rCount && metadata.metadata.total >= 5000
                ? " Too many records returned, please refine your search criteria"
                : numberWithCommas(pCount) + " Records found for your search criteria"
              : metadata.isFetching
                ? ""
                : <div style={{ display: fetchingResults ? "none" : "block" }}>No records found for your search criteria</div>}
          </Typography>
        </Grid>
      </Grid>
    );
  }
  const hideHeaderContent = () => {
    header == true ? setHeader(false) : setHeader(true)
  }
  if (fetchingResults !== state.isLoading) {
    if (resultList == undefined) {
      setState({
        ...state,
        isLoading: false,
        pageLoader: true
      });
    }
  }
  //console.log("page items in state",state.pageOfItems)
  return (
    <div className={classes.root}>
      <Header
        filterFields={filterFields}
        removeResultFilter={removeResultFilter}
        setFilterValue={setFilterValue}
        fetchResultsOnFilterChange={fetchResultsOnFilterChange}
        resultOfFilteredText={getResultText()}
        showHideHeaderContent={header}
        metadata={metadata.metadata}
        handleError={handleError}
      ></Header>
      <Grid
        container
        style={{ display: state.isFilter ? "block" : "none" }}
      ></Grid>
      {fetchingResults == true ? (
        <div
          style={{
            width: "100%",
            height: "100",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            color: "#48ce1c"
          }}
        >
          <br /> <br /> <br /> <br />
          <img src={loder} alt="loder" height="50" width="50" />
        </div>
      ) : (""
        )}
      {/* {state.pageLoader == false || state.isLoading == true? (
        <div
          style={{
            width: "100%",
            height: "100",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            color: "#48ce1c"
          }}
        >
          <br /> <br /> <br /> <br />
          <img src={loder} alt="loder" height="50" width="50" />
        </div>
      ) : (
        ""
      )} */}
      <React.Fragment>
        {header ?
          <div title='show less'>
            <ExpandLessIcon

              color='primary'
              style={{ cursor: 'pointer', float: 'right', marginRight: '10px' }}
              onClick={hideHeaderContent}
              title={'show less'}
            />
          </div>
          :
          <div title='show more'>
            <ExpandMoreIcon
              color='primary'
              style={{ cursor: 'pointer', float: 'right', marginRight: '10px' }}
              onClick={hideHeaderContent}
              title={'show more'}
            />
          </div>
        }
        <div style={{ clear: 'both' }}></div>
        <div style={{ borderTop: "1px solid rgb(237, 235, 233)", paddingTop: 0, display: rCount !== 0 ? "block" : "none" }}>
          {/* 
        {    d
            resultList[0].activeCode == "N" ? */}

          {rCount && rCount > 0 && !state.isLoading ? (
            <Paper style={{ width: "99%" }} className={classes.root}>
              {/* //isExportFileLoadIssue */}
              <div style={{ display: metadata.isHeavyData && isExportFileLoadIssue ? '' : 'none', textAlign: 'right', paddingLeft: '32em' }}>
                <div style={{ maxWidth: "41%", marginBottom: "2px", border: "1px solid blue" }}>
                  <div style={{ textAlign: 'right', height: '10px' }}> <button style={{ border: 'none', background: 'none' }} onClick={() => setIsExportFileLoadIssue(false)}> <CloseIcon /></button></div>
                  <div style={{ textAlign: 'left', paddingLeft: '3px', fontSize: '18px', marginBottom: '2px', color: 'blue' }} > < SettingsIcon /> &nbsp; IT fix scheduled for Export File load issue.</div>
                </div>
              </div>
              <TableContainer
                className={classes.container}
                style={{ height: header ? 480 : 575 }}
              >
                {/*<CSVLink data={data} filename={"my-file.csv"} className="btn btn-primary" target="_blank" >Download me</CSVLink>;*/}

                <Table
                  className={classes.container}
                  size="small"
                  stickyHeader
                  aria-label="sticky table"
                  style={{ marginTop: 0 }}
                >
                  <TableHead className={classes.headerText}>
                    <TableRow>
                      <TableCell style={{ width: "17%", backgroundColor: '#DADBDC' }}>
                        <Tooltip classes={{ tooltip: classes.customWidth }} title={<div style={{
                          backgroundColor: "white",
                          color: "black",
                          // width: "300px"
                        }}>
                          <br />
                          <div style={{ marginLeft: "10px" }}>
                            <span >
                              *** Appears at the end of provider name if MPIN is the corporate owner for one or more of the
                              TaxID(s) loaded to it.  A single asterisk (*) will appear at the end of the MPIN's TaxID(s) for which they are the corporate owner.
                        </span>
                          </div>
                          <br />
                        </div>} placement="top">
                          <Autocomplete
                            multiple
                            size="small"
                            limitTags={1}
                            id="filter-addres10"
                            options={state.providerNameList}
                            disabled={state.nameFilterStatus}
                            disableCloseOnSelect={true}
                            getOptionSelected={(option, value) => option.providerName === value.providerName}
                            onChange={(event, newValue2) =>
                              onFilterProviderName(
                                event,
                                newValue2
                              )
                            }
                            getOptionLabel={option =>
                              option.providerName
                            }
                            renderTags={() => { }}
                            renderOption={(option, { selected }) => (
                              <React.Fragment>
                                <Checkbox
                                  size="small"
                                  icon={icon}
                                  checkedIcon={checkedIcon}
                                  style={{ marginRight: '0px', fontSize: "1px" }}
                                  checked={selected}
                                />
                                {option.providerName}
                              </React.Fragment>
                            )}

                            style={{ width: '80px', paddingLeft: '20px', paddingRight: "0%", fontSize: 8, marginTop: "-21px" }}
                            renderInput={params => (
                              <TextField  {...params} label={providerNameLvl} />
                            )}
                          />
                        </Tooltip>
                      </TableCell>
                      <TableCell style={{ backgroundColor: '#DADBDC' }}>
                        <Tooltip title={<div style={{
                          backgroundColor: "white",
                          color: "black",
                          width: "250px"
                        }}>
                          <br />
                          <div style={{ marginLeft: "10px" }}>
                            <span >
                              * Appears at the end of MPIN if active hold exists.  Hoover mouse over asterisk for hold code details.
                            </span>
                          </div>
                          <br />
                        </div>} placement="top">
                          <Autocomplete
                            multiple
                            size="small"
                            limitTags={1}
                            id="filter-addres4"
                            options={state.mpinList}
                            disabled={state.mpinFilterStatus}
                            disableCloseOnSelect={true}
                            getOptionSelected={(option, value) => option.mpin === value.mpin}
                            onChange={(event, newValue2) =>
                              onFilterMPIN(
                                event,
                                newValue2
                              )
                            }
                            getOptionLabel={option =>
                              option.mpin
                            }
                            renderTags={() => { }}
                            renderOption={(option, { selected }) => (
                              <React.Fragment>
                                <Checkbox
                                  size="small"
                                  icon={icon}
                                  checkedIcon={checkedIcon}
                                  style={{ marginRight: 0, fontSize: 8 }}
                                  checked={selected}
                                />
                                {option.mpin}
                              </React.Fragment>
                            )}
                            style={{ width: 70, fontSize: 8, marginTop: "-21px" }}
                            renderInput={params => (
                              <TextField {...params} label={MPIN} />
                            )}
                          />
                        </Tooltip>
                      </TableCell>
                      <TableCell style={{ backgroundColor: '#DADBDC' }}>
                        <Tooltip title={<div style={{
                          backgroundColor: "white",
                          color: "black",
                          width: "250px"
                        }}>
                          <br />
                          <div style={{ marginLeft: "10px" }}>
                            <span >
                              Hover over 3 character MPIN Type value for full description.
                            </span>
                          </div>
                          <br />
                        </div>} placement="top">
                          <Autocomplete
                            multiple
                            size="small"
                            limitTags={1}
                            id="filter-addres5"
                            options={state.mpinTypeList}
                            disabled={state.mpinTypeFilterStatus}
                            disableCloseOnSelect={true}
                            getOptionSelected={(option, value) => option.mpinType === value.mpinType}
                            onChange={(event, newValue2) =>
                              onFilterMPINType(
                                event,
                                newValue2
                              )
                            }
                            getOptionLabel={option =>
                              option.mpinType
                            }
                            renderTags={() => { }}
                            renderOption={(option, { selected }) => (
                              <React.Fragment>
                                <Checkbox
                                  size="small"
                                  icon={icon}
                                  checkedIcon={checkedIcon}
                                  style={{ marginRight: 0, fontSize: 8 }}
                                  checked={selected}
                                />
                                {option.mpinType}
                              </React.Fragment>
                            )}
                            style={{ width: 70, fontSize: 8, marginTop: "-21px" }}
                            renderInput={params => (
                              <TextField {...params} label={mpinType} />
                            )}
                          />
                        </Tooltip>
                      </TableCell>
                      <TableCell style={{ backgroundColor: '#DADBDC' }}>
                        <Tooltip classes={{ tooltip: classes.customWidth }} title={<div style={{
                          backgroundColor: "white",
                          color: "black",
                          // width: "300px"
                        }}>
                          <br />
                          <div style={{ marginLeft: "10px" }}>
                            <span >
                              ABLE result only displays a single NPI.  If search parameter(s):<br />
                            	• Excludes NPI, "primary" NPI from NDB Main Screen is returned.<br />
                              • Includes NPI, searched NPI is returned and displayed.<br />
                              An * will appear if additional NPI's exist.  See Profile screen for more NPI details.<br />
                            </span>
                          </div>
                          <br />
                        </div>} placement="top">
                          <Autocomplete
                            multiple
                            size="small"
                            limitTags={1}
                            id="filter-addres6"
                            options={state.npiList}
                            disabled={state.npiFilterStatus}
                            disableCloseOnSelect={true}
                            getOptionSelected={(option, value) => option.npi === value.npi}
                            onChange={(event, newValue2) =>
                              onFilterNpi(
                                event,
                                newValue2
                              )
                            }
                            getOptionLabel={option =>
                              option.npi
                            }
                            renderTags={() => { }}
                            renderOption={(option, { selected }) => (
                              <React.Fragment>
                                <Checkbox
                                  size="small"
                                  icon={icon}
                                  checkedIcon={checkedIcon}
                                  style={{ marginRight: 0, fontSize: 8 }}
                                  checked={selected}
                                />
                                {option.npi}
                              </React.Fragment>
                            )}
                            style={{ width: 73, fontSize: 8, marginTop: "-21px" }}
                            renderInput={params => (
                              <TextField {...params} label={NPI} />
                            )}
                          />
                        </Tooltip>
                      </TableCell>
                      <TableCell style={{ backgroundColor: '#DADBDC' }}>
                        <Tooltip title={<div style={{
                          backgroundColor: "white",
                          color: "black",
                          width: "250px"
                        }}>
                          <br />
                          <div style={{ marginLeft: "10px" }}>
                            <span >
                              <b>(S)</b>SN:  Social Security Number<br />
                              <b>(T)</b>axID: Tax Identification<br />
                              <b style={{ color: "#1c0eef" }}>*</b> Appears at the end of Tax ID for which MPIN is the Corporate Owner of.
                            </span>
                          </div>
                          <br />
                        </div>} placement="top">
                          <Autocomplete
                            multiple
                            size="small"
                            limitTags={1}
                            id="filter-addres7"
                            options={state.taxIdTypes}
                            disabled={state.taxIdFilterStatus}
                            disableCloseOnSelect={true}
                            getOptionSelected={(option, value) => option.taxIdType === value.taxIdType}
                            onChange={(event, newValue2) =>
                              onFilterTaxIdTypes(
                                event,
                                newValue2
                              )
                            }
                            getOptionLabel={option =>
                              option.taxIdType
                            }
                            renderTags={() => { }}
                            renderOption={(option, { selected }) => (
                              <React.Fragment>
                                <Checkbox
                                  size="small"
                                  icon={icon}
                                  checkedIcon={checkedIcon}
                                  style={{ marginRight: 0, fontSize: 8 }}
                                  checked={selected}
                                />
                                {option.taxIdType}
                              </React.Fragment>
                            )}
                            style={{ width: 70, fontSize: 8, marginTop: "-21px" }}
                            renderInput={params => (
                              <TextField {...params} label={taxIdType} />
                            )}
                          />
                        </Tooltip>
                      </TableCell>
                      <TableCell style={{ backgroundColor: '#DADBDC' }}>
                        <Tooltip title={<div style={{
                          backgroundColor: "white",
                          color: "black",
                          width: "250px"
                        }}>
                          <br />
                          <div style={{ marginLeft: "10px" }}>
                            <span >
                              <b>Prefix:</b>  1 Digit which distinguishes between SSN or Tax ID &nbsp;number used to bill claims<br />
                              <b>Suffix:</b>  5 Digit system generated sequence assigned &nbsp;to MPIN-TIN-Prefix
                            </span>
                          </div>
                          <br />
                        </div>} placement="top">
                          <Autocomplete
                            multiple
                            size="medium"
                            limitTags={1}
                            id="filter-addres8"
                            options={state.prefixSuffixList}
                            disabled={state.presuffFilterStatus}
                            disableCloseOnSelect={true}
                            getOptionSelected={(option, value) => option.prefixSuffix === value.prefixSuffix}
                            onChange={(event, newValue2) =>
                              onFilterPrefixSuffix(
                                event,
                                newValue2
                              )
                            }
                            getOptionLabel={option =>
                              option.prefixSuffix
                            }
                            renderTags={() => { }}
                            renderOption={(option, { selected }) => (
                              <React.Fragment>
                                <Checkbox
                                  size="small"
                                  icon={icon}
                                  checkedIcon={checkedIcon}
                                  style={{ marginRight: 0, fontSize: 8 }}
                                  checked={selected}
                                />
                                {option.prefixSuffix}
                              </React.Fragment>
                            )}
                            style={{ width: 70, fontSize: 8, marginTop: "-20px" }}
                            renderInput={params => (
                              <TextField {...params} label={prefixSuffixLvl} />
                            )}
                          />
                        </Tooltip>
                      </TableCell>
                      <TableCell style={{ backgroundColor: '#DADBDC' }}>
                        <Tooltip title={<div style={{
                          backgroundColor: "white",
                          color: "black",
                          width: "250px"
                        }}>
                          <br />
                          <div style={{ marginLeft: "10px" }}>
                            <span >
                              Hoover cursor over Address Selection Number for Quick View of additional and/or scrolled offscreen details.
                            </span>
                          </div>
                          <br />
                        </div>} placement="top">
                          <Autocomplete
                            multiple
                            size="medium"
                            limitTags={1}
                            id="filter-addres11"
                            options={state.addressTelephoneList}
                            disabled={state.adressTelephoneFilterStatus}
                            disableCloseOnSelect={true}
                            getOptionSelected={(option, value) => option.addressTelephone === value.addressTelephone}
                            onChange={(event, newValue2) =>
                              onFilterAddressTelephone(
                                event,
                                newValue2
                              )
                            }
                            getOptionLabel={option =>
                              option.addressTelephone
                            }
                            renderTags={() => { }}
                            renderOption={(option, { selected }) => (
                              <React.Fragment>
                                <Checkbox
                                  size="small"
                                  icon={icon}
                                  checkedIcon={checkedIcon}
                                  style={{ marginRight: 0, fontSize: 8 }}
                                  checked={selected}
                                />
                                {option.addressTelephone}
                              </React.Fragment>
                            )}
                            style={{ width: 210, fontSize: 8, marginTop: "-20px" }}
                            renderInput={params => (
                              <TextField {...params} label={addressTelephoneLvl} />
                            )}
                          />
                        </Tooltip>
                      </TableCell>
                      <TableCell style={{ backgroundColor: '#DADBDC' }}>
                        <Tooltip title={<div style={{
                          backgroundColor: "white",
                          color: "black",
                          width: "250px"
                        }}>

                          <div style={{ marginleft: "7pt" }}>

                            <span >

                              &nbsp;&nbsp;<b>BILL:</b>      Billing<br />
                             &nbsp;&nbsp;<b>COMB:</b> Combination (Billing & Place of Service)<br />
                             &nbsp;&nbsp;<b>PLSV:</b>    Place of Service<br />
                             &nbsp;&nbsp;<b>CRED:</b>   Credentialing<br />
                             &nbsp;&nbsp;<b>MAIL:</b> Mailing
                </span>

                          </div>


                        </div>} placement="top">
                          <Autocomplete
                            multiple
                            size="small"
                            limitTags={1}
                            id="filter-addres1"
                            options={state.addressList}
                            //   defaultValue={state.addressList}
                            disabled={state.masterAdressFilterStatus}
                            disableCloseOnSelect={true}
                            //getOptionSelected = {(option, value) => option.addressTelephone === value.addressTelephone}
                            onChange={(event, newValue) =>
                              onFilterAddressMultiple(event, newValue)
                            }
                            getOptionLabel={option => option.addressId ? `${getAddressType(option.addressTypeCode)}` : ''}
                            renderTags={() => { }}
                            renderOption={(option, { selected }) => (
                              <React.Fragment>
                                <Checkbox
                                  size="small"
                                  icon={icon}
                                  checkedIcon={checkedIcon}
                                  style={{ marginRight: 0, fontSize: 8 }}
                                  checked={selected}
                                />
                                {getAddressType(option.addressTypeCode)}
                              </React.Fragment>
                            )}
                            style={{
                              width: 120,
                              fontSize: 8,
                              marginTop: "-21px"
                            }}
                            renderInput={params => (
                              <TextField
                                {...params}
                                fullWidth
                                label={addressandpone}
                              />
                            )}
                          />
                        </Tooltip>
                      </TableCell>
                      <TableCell style={{ backgroundColor: '#DADBDC' }}>
                        <Tooltip title={<div style={{
                          backgroundColor: "white",
                          color: "black",
                          width: "250px"
                        }}>
                          <br />
                          <div style={{ marginLeft: "10px" }}>
                            <span >
                              <b>P/S:</b>      Primary/Secondary Address<br />
                              <b>C:</b>Correspondence Type<br />
                              <b>Seq:</b>     Address Sequence<br />
                              <b> * </b>Appears at the end of P/S-C if Non-UHN Contract Org Primary indicator varies.
                            </span>
                          </div>
                          <br />
                        </div>} placement="top">
                          <Autocomplete
                            multiple
                            size="small"
                            limitTags={1}
                            id="filter-addres13"
                            options={state.primaryAddressIndicator}
                            disabled={state.pscSeqFilterStatus}
                            disableCloseOnSelect={true}
                            getOptionSelected={(option, value) => option.primaryAddressIndicator === value.primaryAddressIndicator}
                            onChange={(event, newValue2) =>
                              onFilterAddressprimaryAddressIndicator(
                                event,
                                newValue2
                              )
                            }
                            getOptionLabel={option =>
                              option.primaryAddressIndicator
                            }
                            renderTags={() => { }}
                            renderOption={(option, { selected }) => (
                              <React.Fragment>
                                <Checkbox
                                  size="small"
                                  icon={icon}
                                  checkedIcon={checkedIcon}
                                  style={{ marginRight: 0, fontSize: 8 }}
                                  checked={selected}
                                />
                                {option.primaryAddressIndicator}
                              </React.Fragment>
                            )}
                            style={{ width: 70, fontSize: 8, marginTop: "-21px" }}
                            renderInput={params => (
                              <TextField {...params} label={pscseq} />
                            )}
                          />
                        </Tooltip>
                      </TableCell>
                      <TableCell style={{ backgroundColor: '#DADBDC' }}>
                        <Tooltip title={<div style={{
                          backgroundColor: "white",
                          color: "black",
                          width: "250px"
                        }}>
                          <br />
                          <div style={{ marginLeft: "10px" }}>
                            <span >
                              Bill Sequence affiliates each address to specific <br />MPIN billing/combination address record.
                            </span>
                          </div>
                          <br />
                        </div>} placement="top">
                          <Autocomplete
                            multiple
                            size="small"
                            limitTags={1}
                            id="filter-addres2"
                            disableCloseOnSelect={true}
                            options={state.billSequenceList}
                            disabled={state.billSeqFilterStatus}
                            getOptionSelected={(option, value) => option.billSequence === value.billSequence}
                            onChange={(event, newValue2) =>
                              onFilterBillSequence(
                                event,
                                newValue2
                              )
                            }
                            getOptionLabel={option =>
                              option.billSequence
                            }
                            renderTags={() => { }}
                            renderOption={(option, { selected }) => (
                              <React.Fragment>
                                <Checkbox
                                  size="small"
                                  icon={icon}
                                  checkedIcon={checkedIcon}
                                  style={{ marginRight: 0, fontSize: 8 }}
                                  checked={selected}
                                />
                                {addZeros(option.billSequence)}
                              </React.Fragment>
                            )}
                            style={{ width: 70, fontSize: 8, marginTop: "-21px" }}
                            renderInput={params => (
                              <TextField {...params} label={billSeqLvl} />
                            )}
                          />
                        </Tooltip>
                      </TableCell>
                      <TableCell style={{ display: metadata.searchParams.uhcid !== '' ? "" : "none", backgroundColor: '#DADBDC' }}>
                        <Tooltip title={<div style={{
                          backgroundColor: "white",
                          color: "black",
                          width: "250px"
                        }}>
                          <br />
                          <div style={{ marginLeft: "10px" }}>
                            <span >
                              11 Digit United Healthcare Identification (UHCID) is <br />a two-part NDB provider number leveraged to
                              identify provider in COSMOS within a DIV:
                            </span>
                          </div>
                          <br />
                        </div>} placement="top">
                          <Autocomplete
                            multiple
                            size="small"
                            limitTags={1}
                            id="filter-addres14"
                            options={state.uhcIdList}
                            disabled={state.uhcIdFilterStatus}
                            disableCloseOnSelect={true}
                            getOptionSelected={(option, value) => option.uhcId === value.uhcId}
                            onChange={(event, newValue2) =>
                              onFilterUhcID(
                                event,
                                newValue2
                              )
                            }
                            getOptionLabel={option =>
                              option.uhcId
                            }
                            renderTags={() => { }}
                            renderOption={(option, { selected }) => (
                              <React.Fragment>
                                <Checkbox
                                  size="small"
                                  icon={icon}
                                  checkedIcon={checkedIcon}
                                  style={{ marginRight: 0, fontSize: 8 }}
                                  checked={selected}
                                />
                                {option.uhcId}
                              </React.Fragment>
                            )}
                            style={{ width: 110, fontSize: 8, marginTop: "-21px", "max-width": "140px !important" }}
                            renderInput={params => (
                              <TextField {...params} label={uhcIdLvl} />
                            )}
                          />
                        </Tooltip>
                      </TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {state.pageOfItems.length > 0 ? (
                      state.pageOfItems.map(row => (
                        <TableRow
                          hover
                          key={row.providerId}
                          onDoubleClick={() => {
                            _renderRow(row);
                          }}
                        >
                          <TableCell
                            className={classes.CellText}
                            style={{
                              //borderRightStyle: "groove",
                              // backgroundColor: "white"
                            }}
                          >
                            <div className={classes.CellText}>
                              <div>
                                {row.activeCode == "A" ? (
                                  <React.Fragment><span style={{ color: "black" }}>{row.name}</span> <span>{row.addressDetails.filter((obj) => obj.corpOwnerFlag == "Y").length >= 1 ? <b style={{ color: "#1c0eef" }}>***</b> : ""}</span></React.Fragment>
                                ) : (
                                    <React.Fragment><span style={{ color: "#58cde8" }}>{row.name}</span> <span>{row.addressDetails.filter((obj) => obj.corpOwnerFlag == "Y").length >= 1 ? <b style={{ color: "#1c0eef" }}>***</b> : ""}</span></React.Fragment>
                                  )}
                              </div>
                            </div>
                          </TableCell>
                          <TableCell
                            className={classes.CellText}
                            style={{
                              //borderRightStyle: "groove",
                              //   backgroundColor: "white"
                            }}
                          >
                            <div className={classes.CellText}>
                              {row.activeCode == "A" ? (
                                <span style={{ color: "black" }}>{row.mpin}</span>
                              ) : (
                                  <span style={{ color: "#58cde8" }}>{row.mpin}</span>
                                )}
                            </div>
                          </TableCell>
                          <TableCell className={classes.CellText}>
                            <Tooltip title={<div style={{
                              backgroundColor: "white",
                              color: "black",
                              width: "100px"
                            }}>
                              <br />
                              <div style={{ marginLeft: "10px" }}>
                                <span >
                                  <b>{(row.mpinTypeDescription == "NOT APPLICABLE" ? "PHYSICIAN" : row.mpinTypeDescription)}</b>
                                </span>
                              </div>
                              <br />
                            </div>} placement="top">
                              {row.activeCode == "A" ? (
                                <span style={{ color: "black" }}>{row.mpinType}</span>
                              ) : (
                                  <span style={{ color: "#58cde8" }}>{row.mpinType}</span>
                                )}
                            </Tooltip>
                          </TableCell>
                          <TableCell className={classes.CellText}>
                            <div className={classes.CellText}>
                              {row.activeCode == "A" && row.npiFlag == "A" ? (
                                <span style={{ color: "black" }}>{row.npi == 0 ? "" : row.additionalNpiFlag !== "" ? <React.Fragment><span style={{ color: "black" }}>{row.npi}</span> <span>{row.additionalNpiFlag == "Y" ? <b style={{ color: "#1c0eef" }}>*</b> : <b style={{ color: "#58cde8" }}>*</b>}</span></React.Fragment> : row.npi}</span>
                              ) : (
                                  <span style={{ color: "#58cde8" }}>{row.npi == 0 ? "" : row.additionalNpiFlag !== "" ? <React.Fragment><span style={{ color: "#58cde8" }}>{row.npi}</span> <span>{row.additionalNpiFlag == "Y" ? <b style={{ color: "#1c0eef" }}>*</b> : <b style={{ color: "#58cde8" }}>*</b>}</span></React.Fragment> : row.npi}</span>
                                )}
                            </div>
                          </TableCell>
                          <TableCell className={classes.CellText}>
                            <div>
                              {row.addressDetails.map(ad => (
                                <div style={{ width: "79px" }}>
                                  {
                                    <div className={classes.rowHeight}>
                                      <div>
                                        {ad.isTextIdVisible ? (
                                          <div>
                                            {
                                              row.activeCode === "I" || ad.taxIdStatus === "I" ? (
                                                <span style={{ color: "#58cde8" }}>
                                                  <b>{ad.taxtIdTypeCode}</b>-{" "}
                                                </span>
                                              ) : (
                                                  <span style={{ color: "blue" }}>
                                                    <b>{ad.taxtIdTypeCode}</b>-{" "}
                                                  </span>

                                                )}
                                            {
                                              row.activeCode === "I" || ad.taxIdStatus === "I" ? (
                                                <React.Fragment>
                                                  <span style={{ color: "#58cde8" }}>
                                                    {ad.taxtId}
                                                  </span>
                                                  <span>{ad.corpOwnerFlag == "Y" ? <b style={{ color: "#1c0eef" }}> *</b> : ""}</span>
                                                </React.Fragment>
                                              ) : (
                                                  <React.Fragment>
                                                    <span style={{ color: "black" }}>
                                                      {ad.taxtId}
                                                    </span>
                                                    <span>{ad.corpOwnerFlag == "Y" ? <b style={{ color: "#1c0eef" }}> *</b> : ""}</span>
                                                  </React.Fragment>
                                                )}
                                          </div>
                                        ) : (
                                            <br />
                                          )}
                                      </div>
                                    </div>
                                  }
                                  <br />
                                  <br />
                                  <br />
                                </div>
                              ))}
                            </div>
                          </TableCell>
                          <TableCell className={classes.CellText}>
                            <div>
                              {row.addressDetails.map(ad => (
                                <div className={classes.rowHeight}>
                                  {
                                    row.activeCode === "I" || ad.taxIdStatus === "I" || ad.addressinfo.addressStatus === "I" ? (
                                      <span style={{ color: "#58cde8" }}>
                                        {(ad.addressinfo.topsTinSuffix === "" || ad.addressinfo.topsTinSuffix === undefined) && (ad.addressinfo.topsTinPrefix === "" || ad.addressinfo.topsTinPrefix === undefined) ? (
                                          <div className={classes.rowHeight}>
                                            <div style={{ color: "white" }}><span>&nbsp;</span></div>
                                          </div>
                                        ) : (
                                            <div className={classes.rowHeight}>
                                              {ad.addressinfo.topsTinPrefix}-
                                              {ad.addressinfo.topsTinSuffix}
                                            </div>
                                          )}
                                      </span>
                                    ) : (
                                        <span style={{ color: "black" }}>
                                          {(ad.addressinfo.topsTinSuffix === "" || ad.addressinfo.topsTinSuffix === undefined) && (ad.addressinfo.topsTinPrefix === "" || ad.addressinfo.topsTinPrefix === undefined) ? (
                                            <div className={classes.rowHeight}>
                                              <div style={{ color: "white" }}><span>&nbsp;</span></div>
                                            </div>
                                          ) : (
                                              <div className={classes.rowHeight}>
                                                {ad.addressinfo.topsTinPrefix}-
                                                {ad.addressinfo.topsTinSuffix}
                                              </div>
                                            )}
                                        </span>
                                      )}
                                  <br />
                                  <br />
                                  <br />
                                </div>
                              ))}
                            </div>
                          </TableCell>
                          <TableCell className={classes.CellText}>
                            <div>

                              {row.addressDetails.map((ad, counter) => (

                                <div>
                                  <Tooltip classes={{ tooltip: classes.customWidth }}
                                    title={
                                      <div
                                        style={{
                                          backgroundColor: "white",
                                          color: "black",
                                          width: "350px"
                                        }}
                                      >
                                        <table border="0" cellSpacing="0" cellPadding="0">
                                          <tbody>
                                            <tr>
                                              <td width="50%" valign="top">
                                                <table border="0" width="100%">
                                                  <tr>
                                                    <td>
                                                      {row.activeCode === "A" ? (
                                                        <React.Fragment>
                                                          <span style={{ color: "black" }}>
                                                            <b>{row.qname}</b>
                                                          </span>
                                                          <span><b>{row.primaryDegreeCode == "" ? " " : ", " + row.primaryDegreeCode + " "}</b></span>
                                                          <span>{ad.corpOwnerFlag == "Y" ? <b style={{ color: "#1c0eef" }}>***</b> : ""}</span>
                                                          <span> <b>({row.mpinType})</b></span>
                                                        </React.Fragment>
                                                      ) : (
                                                          <React.Fragment>
                                                            <span style={{ color: "#58cde8" }}>
                                                              <b>{row.qname}</b>
                                                            </span>
                                                            <span><b>{row.primaryDegreeCode == "" ? " " : ", " + row.primaryDegreeCode + " "}</b></span>
                                                            <span style={{ color: "#58cde8" }}>{ad.corpOwnerFlag == "Y" ? <b style={{ color: "#1c0eef" }}>***</b> : ""}</span>
                                                            <span style={{ color: "#58cde8" }}> <b>({row.mpinType})</b></span>
                                                          </React.Fragment>
                                                        )}
                                                    </td>
                                                  </tr>
                                                  <tr>
                                                    <td> <b>DOB: </b>{""}
                                                      {row.activeCode === "A" ? (
                                                        <span style={{ color: "black" }}>
                                                          {row.dob !== "" ? "##/##/" + row.dob.substring(0, 4) : ""}
                                                        </span>
                                                      ) : (
                                                          <span style={{ color: "#58cde8" }}>
                                                            {row.dob !== "" ? "##/##/" + row.dob.substring(0, 4) : ""}
                                                          </span>
                                                        )}
                                                    </td>
                                                  </tr>
                                                  <tr>
                                                    <td>
                                                      <b>GENDER: </b>{" "}
                                                      {row.activeCode === "A" ? (
                                                        <span style={{ color: "black" }}>
                                                          {getgender(row.gender)}
                                                        </span>
                                                      ) : (
                                                          <span style={{ color: "#58cde8" }}>
                                                            {getgender(row.gender)}
                                                          </span>
                                                        )}
                                                    </td>
                                                  </tr>
                                                  <tr>
                                                    <td>
                                                      <b>SERVICES:</b>{" "}
                                                      {row.activeCode === "A" ? (
                                                        <span style={{ color: "black" }}>
                                                          {row.services}
                                                        </span>
                                                      ) : (
                                                          <span style={{ color: "#58cde8" }}>
                                                            {row.services}
                                                          </span>
                                                        )}
                                                    </td>
                                                  </tr> <br />
                                                  <tr>
                                                    <td>
                                                      <b>MPIN:</b>
                                                      {row.activeCode === "A" ? (
                                                        <span style={{ color: "black" }}>
                                                          &nbsp;{row.mpin}
                                                        </span>
                                                      ) : (
                                                          <span style={{ color: "#58cde8" }}>
                                                            &nbsp;{row.mpin}
                                                          </span>
                                                        )}
                                                    </td>
                                                  </tr>
                                                  <tr>
                                                    <td>
                                                      <b>TAXID :</b>{" "}
                                                      {row.activeCode === "I" || ad.taxIdStatus === "I" ? (
                                                        <span style={{ color: "#58cde8" }}>
                                                          <b>{ad.taxtIdTypeCode}</b>-{" "}
                                                        </span>
                                                      ) : (
                                                          <span style={{ color: "blue" }}>
                                                            <b>{ad.taxtIdTypeCode}</b>-{" "}
                                                          </span>

                                                        )}
                                                      {row.activeCode === "I" || ad.taxIdStatus === "I" ? (
                                                        <React.Fragment>
                                                          <span style={{ color: "#58cde8" }}>
                                                            {ad.taxtId}
                                                          </span>
                                                          <span>{ad.corpOwnerFlag == "Y" ? <b style={{ color: "#1c0eef" }}> *</b> : ""}</span>
                                                        </React.Fragment>
                                                      ) : (
                                                          <React.Fragment>
                                                            <span style={{ color: "black" }}>
                                                              {ad.taxtId}
                                                            </span>
                                                            <span>{ad.corpOwnerFlag == "Y" ? <b style={{ color: "#1c0eef" }}> *</b> : ""}</span>
                                                          </React.Fragment>
                                                        )}
                                                    </td>
                                                  </tr>
                                                  <tr>
                                                    <td>
                                                      <b>SSN:</b>{" "}
                                                      {row.activeCode === "I" ? (
                                                        <span style={{ color: "#58cde8" }}>
                                                          {row.ssn !== "" ? "###-##-" + row.ssn.substr(row.ssn.length - 4) : ""}
                                                        </span>
                                                      ) : (
                                                          <span style={{ color: "black" }}>
                                                            {row.ssn !== "" ? "###-##-" + row.ssn.substr(row.ssn.length - 4) : ""}
                                                          </span>
                                                        )}
                                                    </td>
                                                  </tr><br />
                                                  <tr>
                                                    <td style={{ "vertical-align": "top" }}>
                                                      <b>CORPORATE MPIN/NAME:</b>{" "}<br />
                                                      {ad.corpStatus === "A" ? (
                                                        <span style={{ color: "black" }}>
                                                          {ad.corpMpin}&nbsp;&nbsp;{ad.corpMpinName}
                                                        </span>
                                                      ) : (
                                                          <span style={{ color: "#58cde8" }}>
                                                            {ad.corpMpin}&nbsp;&nbsp;{ad.corpMpinName}
                                                          </span>
                                                        )}
                                                      <br />
                                                    </td>
                                                  </tr>
                                                </table>
                                              </td>
                                              <td valign="top">
                                                <table border="0" width="100%">
                                                  <tr>
                                                    <td>
                                                      <b>BILL ADDRESS DETAILS:</b>
                                                      {ad.addressinfo.quickviewAddressInfo.bill_adr_act_flag === "A" ? (
                                                        <span style={{ color: "black" }}>
                                                          <div style={{ fontSize: "10px" }}>
                                                            {ad.addressinfo.quickviewAddressInfo.bill_adr_ln_1_txt}{ad.addressinfo.quickviewAddressInfo.bill_adr_ln_1_txt == "" ? "" : " "}
                                                          </div>
                                                          <div>
                                                            {ad.addressinfo.quickviewAddressInfo.bill_cty_nm}{ ad.addressinfo.quickviewAddressInfo.bill_cty_nm == "" ? "" : ", "}
                                                            {ad.addressinfo.quickviewAddressInfo.bill_st_cd}{ad.addressinfo.quickviewAddressInfo.bill_st_cd == "" ? "" : " "}
                                                            {addZerosforZip(ad.addressinfo.quickviewAddressInfo.bill_zip_cd)}{ad.addressinfo.quickviewAddressInfo.bill_zip_cd == ""?"":"-"}
                                                                      {addZeros(ad.addressinfo.quickviewAddressInfo.bill_zip_pls_4_cd)}
                                                          </div>
                                                        </span>
                                                      ) : (
                                                          <span style={{ color: "#58cde8" }}>
                                                            <div style={{ fontSize: "10px" }}>
                                                              {ad.addressinfo.quickviewAddressInfo.bill_adr_ln_1_txt}{ad.addressinfo.quickviewAddressInfo.bill_adr_ln_1_txt == "" ? "" : " "}
                                                            </div>
                                                            <div>
                                                              {ad.addressinfo.quickviewAddressInfo.bill_cty_nm}{ad.addressinfo.quickviewAddressInfo.bill_cty_nm == "" ? "" : ", "}
                                                              {ad.addressinfo.quickviewAddressInfo.bill_st_cd}{ad.addressinfo.quickviewAddressInfo.bill_st_cd == "" ? "" : " "}
                                                              {addZerosforZip(ad.addressinfo.quickviewAddressInfo.bill_zip_cd)}{ad.addressinfo.quickviewAddressInfo.bill_zip_cd == ""?"":"-"}
                                                                        {addZeros(ad.addressinfo.quickviewAddressInfo.bill_zip_pls_4_cd)}
                                                            </div>
                                                          </span>
                                                        )
                                                      }
                                                    </td>
                                                  </tr>
                                                  <tr>
                                                    <td>
                                                      <b>TYPE: </b>{" "}
                                                      {ad.addressinfo.quickviewAddressInfo.bill_adr_act_flag === "A" ? (
                                                        <span style={{ color: "black" }}>
                                                          {getAddressType(ad.addressinfo.quickviewAddressInfo.bil_adr_typ)}
                                                        </span>
                                                      ) : (
                                                          <span style={{ color: "#58cde8" }}>
                                                            {getAddressType(ad.addressinfo.quickviewAddressInfo.bil_adr_typ)}
                                                          </span>
                                                        )
                                                      }
                                                      {" "}
                                                      <b>BAID:</b>{" "}
                                                      {ad.addressinfo.quickviewAddressInfo.bill_adr_act_flag === "A" ? (
                                                        <span style={{ color: "black" }}>
                                                          {ad.addressinfo.billAddressId}
                                                        </span>
                                                      ) : (
                                                          <span style={{ color: "#58cde8" }}>
                                                            {ad.addressinfo.billAddressId}
                                                          </span>
                                                        )
                                                      }
                                                    </td>
                                                  </tr><br />
                                                  <tr>
                                                    <td>
                                                      <b>PHONE: </b>
                                                      {
                                                        ad.addressinfo.quickviewAddressInfo.bill_adr_act_flag === "A" ? (
                                                          <span style={{ color: "black" }}>
                                                            {
                                                              (ad.addressinfo.quickViewTelephoneObj.tel_nbr ?
                                                                <span className={classes.rowHeight}>({ad.addressinfo.quickViewTelephoneObj.tel_nbr.substr(0, 3)}) {ad.addressinfo.quickViewTelephoneObj.tel_nbr.substr(3, 3)}-{ad.addressinfo.quickViewTelephoneObj.tel_nbr.substr(6, 4)}{ad.addressinfo.quickViewTelephoneObj.ext_nbr == '0' ? "" : <span>{" "} EXT {addZeros(ad.addressinfo.quickViewTelephoneObj.ext_nbr)}</span>}</span>
                                                                : ""
                                                              )}
                                                          </span>
                                                        ) : (
                                                            <span style={{ color: "#58cde8" }}>
                                                              {
                                                                (ad.addressinfo.quickViewTelephoneObj.tel_nbr ?
                                                                  <span className={classes.rowHeight}>({ad.addressinfo.quickViewTelephoneObj.tel_nbr.substr(0, 3)}) {ad.addressinfo.quickViewTelephoneObj.tel_nbr.substr(3, 3)}-{ad.addressinfo.quickViewTelephoneObj.tel_nbr.substr(6, 4)}{ad.addressinfo.quickViewTelephoneObj.ext_nbr == '0' ? "" : <span>{" "} EXT  {addZeros(ad.addressinfo.quickViewTelephoneObj.ext_nbr)}</span>}</span>
                                                                  : ""
                                                                )}
                                                            </span>
                                                          )
                                                      }
                                                    </td>
                                                  </tr><br /><br /><br />
                                                  <tr>
                                                    <td>
                                                      <br />
                                                      <b>PTI IND/MPIN/NAME: </b>{""}<br />
                                                      {ad.ptiStatus === "A" ? (
                                                        <span style={{ color: "black" }}>
                                                          {ad.ptiIndicator}&nbsp;&nbsp;{ad.ptiMpin}&nbsp;&nbsp;{ad.ptiMpinName}
                                                        </span>
                                                      ) : (
                                                          <span style={{ color: "#58cde8" }}>
                                                            {ad.ptiIndicator}&nbsp;&nbsp;{ad.ptiMpin}&nbsp;&nbsp;{ad.ptiMpinName}
                                                          </span>
                                                        )}
                                                    </td>
                                                  </tr>
                                                </table>
                                              </td>
                                            </tr>
                                          </tbody>
                                        </table>
                                      </div>
                                    }
                                    placement="right"
                                  >
                                    {/* ASK here */}
                                    <b style={{ marginLeft: _counter < 9 ? "-13px" : "-19px", placeContent: "left" }}>
                                      {new_counter()}
                                    </b>
                                  </Tooltip>
                                    - {" "}
                                  {
                                    row.activeCode === "I" || ad.taxIdStatus === "I" || ad.addressinfo.addressStatus === "I" ? (
                                      <span style={{ color: "#58cde8" }}>
                                        {ad.addressinfo.postaladdressinfo.adr_ln_1_txt}{" "}
                                        <div>
                                          {ad.addressinfo.postaladdressinfo.cty_nm},{" "}
                                          {ad.addressinfo.postaladdressinfo.st_cd}{" "}
                                          {addZerosforZip(ad.addressinfo.postaladdressinfo.zip_cd)}-
                                          {addZeros(ad.addressinfo.postaladdressinfo.zip_pls_4_cd)}
                                        </div>
                                        {
                                          (ad.addressinfo.telephoneObj.tel_nbr ?
                                            <div className={classes.rowHeight}>{ad.addressinfo.telephoneObj.tel_use_typ_cd}- ({ad.addressinfo.telephoneObj.tel_nbr.substr(0, 3)}) {ad.addressinfo.telephoneObj.tel_nbr.substr(3, 3)}-{ad.addressinfo.telephoneObj.tel_nbr.substr(6, 4)}{ad.addressinfo.telephoneObj.ext_nbr == '0' ? "" : <span>{" "} EXT  {addZeros(ad.addressinfo.telephoneObj.ext_nbr)}</span>}</div> : ""
                                          )
                                        }
                                      </span>
                                    ) : (
                                        <span style={{ color: "black" }}>
                                          {ad.addressinfo.postaladdressinfo.adr_ln_1_txt
                                          }{" "}
                                          <div>
                                            {ad.addressinfo.postaladdressinfo.cty_nm},{" "}
                                            {ad.addressinfo.postaladdressinfo.st_cd}{" "}
                                            {addZerosforZip(ad.addressinfo.postaladdressinfo.zip_cd)}-
                                            {addZeros(ad.addressinfo.postaladdressinfo.zip_pls_4_cd)}
                                          </div>
                                          {
                                            (ad.addressinfo.telephoneObj.tel_nbr ?
                                              <div className={classes.rowHeight}>{ad.addressinfo.telephoneObj.tel_use_typ_cd}- ({ad.addressinfo.telephoneObj.tel_nbr.substr(0, 3)}) {ad.addressinfo.telephoneObj.tel_nbr.substr(3, 3)}-{ad.addressinfo.telephoneObj.tel_nbr.substr(6, 4)}{ad.addressinfo.telephoneObj.ext_nbr == '0' ? "" : <span>{" "} EXT  {addZeros(ad.addressinfo.telephoneObj.ext_nbr)}</span>}</div> : ""
                                            )
                                          }
                                        </span>
                                      )}{" "}
                                  <br />
                                  {/* </Tooltip> */}
                                </div>
                              ))}
                            </div>
                          </TableCell>
                          <TableCell className={classes.CellText}>
                            <div>
                              {row.addressDetails.map(ad => (
                                <div>
                                  {
                                    row.activeCode === "I" || ad.taxIdStatus === "I" || ad.addressinfo.addressStatus === "I" ? (
                                      <span style={{ color: "#58cde8" }}>
                                        {getAddressType(ad.addressinfo.addressTypeCode)}
                                        <br />
                                        {ad.addressinfo.addressId}
                                      </span>
                                    ) : (
                                        <span style={{ color: "black" }}>
                                          {getAddressType(ad.addressinfo.addressTypeCode)}
                                          <br />
                                          {ad.addressinfo.addressId}
                                        </span>
                                      )}
                                  <br /><br /><br />
                                </div>
                              ))}
                            </div>
                          </TableCell>
                          <TableCell className={classes.CellText}>
                            <div>
                              {row.addressDetails.map(ad => (
                                <div>
                                  {
                                    row.activeCode === "I" || ad.taxIdStatus === "I" || ad.addressinfo.addressStatus === "I" ? (
                                      <div
                                        style={{ color: "#58cde8" }}
                                        className={classes.rowHeight}
                                      >
                                        {ad.addressinfo.addressIndicator === "P" && ad.addressinfo.addressCorrespondence !== "P" ? (
                                          <React.Fragment>
                                            <b>
                                              {ad.addressinfo.addressIndicator}
                                            </b> <span>-{ad.addressinfo.addressCorrespondence}</span>
                                          </React.Fragment>
                                        ) : ad.addressinfo.addressCorrespondence === "P" && ad.addressinfo.addressIndicator !== "P" ? (
                                          <React.Fragment>
                                            {ad.addressinfo.addressIndicator}
                                            <span>- <b>{ad.addressinfo.addressCorrespondence}</b></span>
                                          </React.Fragment>
                                        ) : ad.addressinfo.addressCorrespondence === "P" && ad.addressinfo.addressIndicator === "P" ? (
                                          <React.Fragment>
                                            <b>{ad.addressinfo.addressIndicator}</b>
                                            <span>- <b>{ad.addressinfo.addressCorrespondence}</b></span>
                                          </React.Fragment>
                                        ) : (
                                                <span>{ad.addressinfo.addressIndicator} -{ad.addressinfo.addressCorrespondence}</span>
                                              )}
                                        <br />
                                        {ad.addressinfo.epqAddressSequence}
                                      </div>
                                    ) : (
                                        <div
                                          style={{ color: "black" }}
                                          className={classes.rowHeight}
                                        >
                                          {ad.addressinfo.addressIndicator === "P" && ad.addressinfo.addressCorrespondence !== "P" ? (
                                            <React.Fragment>
                                              <b>
                                                {ad.addressinfo.addressIndicator}
                                              </b> <span>-{ad.addressinfo.addressCorrespondence}</span>
                                            </React.Fragment>
                                          ) : ad.addressinfo.addressCorrespondence === "P" && ad.addressinfo.addressIndicator !== "P" ? (
                                            <React.Fragment>
                                              {ad.addressinfo.addressIndicator}
                                              <span>- <b>{ad.addressinfo.addressCorrespondence}</b></span>
                                            </React.Fragment>
                                          ) : ad.addressinfo.addressCorrespondence === "P" && ad.addressinfo.addressIndicator === "P" ? (
                                            <React.Fragment>
                                              <b>{ad.addressinfo.addressIndicator}</b>
                                              <span>- <b>{ad.addressinfo.addressCorrespondence}</b></span>
                                            </React.Fragment>
                                          ) : (
                                                  <span>{ad.addressinfo.addressIndicator} -{ad.addressinfo.addressCorrespondence}</span>
                                                )}
                                          <br />
                                          {ad.addressinfo.epqAddressSequence}
                                        </div>
                                      )}
                                  <br /><br />
                                </div>
                              ))}
                            </div>
                          </TableCell>
                          <TableCell className={classes.CellText}>
                            <div>
                              <br />
                              {row.addressDetails.map(ad1 => (

                                <div>

                                  {row.activeCode === "I" || ad1.taxIdStatus === "I" || ad1.addressinfo.addressStatus === "I" ? (
                                    <span style={{ color: "#58cde8" }}>
                                      {ad1.addressinfo.billSequence}
                                    </span>
                                  ) : (
                                      <span style={{ color: "black" }}>
                                        {ad1.addressinfo.billSequence}
                                      </span>
                                    )}
                                  <br /><br /><br /><br />
                                </div>
                              ))}
                            </div>
                          </TableCell>
                          <TableCell className={classes.CellText} style={{ display: metadata.searchParams.uhcid !== '' ? "" : "none" }}>
                            <div>
                              {row.addressDetails.map(ad1 => (
                                <div>
                                  {row.activeCode === "I" || ad1.taxIdStatus === "I" || ad1.addressinfo.addressStatus === "I" || ad1.addressinfo.uhcidFlag === "I" ? (
                                    <React.Fragment>
                                      <span style={{ color: "#58cde8" }}>
                                        {ad1.addressinfo.uhcidInfo}
                                      </span><span>{ad1.addressinfo.additionalUhcidFlag !== "" ? ad1.addressinfo.additionalUhcidFlag === "Y" ? <b style={{ color: "#1c0eef" }}> *</b> : <b style={{ color: "#58cde8" }}> *</b> : ""} </span></React.Fragment>
                                  ) : (
                                      <React.Fragment>
                                        <span style={{ color: "black" }}>
                                          {ad1.addressinfo.uhcidInfo}
                                        </span><span>{ad1.addressinfo.additionalUhcidFlag !== "" ? ad1.addressinfo.additionalUhcidFlag === "Y" ? <b style={{ color: "#1c0eef" }}> *</b> : <b style={{ color: "#58cde8" }}> *</b> : ""} </span></React.Fragment>
                                    )}
                                  <br /><br /><br /><br />
                                </div>
                              ))}
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    ) : (
                        <TableRow>
                          <TableCell className={classes.CellText}>
                            0 Providers found{" "}
                          </TableCell>
                        </TableRow>
                      )}
                  </TableBody>
                </Table>
              </TableContainer>
            </Paper>

          ) : state.isLoading == true ? (
            <div
              style={{
                width: "100%",
                height: "100",
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                color: "#48ce1c"
              }}
            ></div>
          ) : (
                " No records found for your search criteria"
              )}

          {/*--Old table
       <DetailsList 
              items={state.providerPageList}
              columns={columns}
              
              setKey="set"
              selectionMode={SelectionMode.none}
              enableShimmer={state.isLoading}
              className={classes.tableY}
              onRenderRow={_renderRow}
              styles={_style}
            
              />
*/}

          {/* :
                null
            }
             {
               resultList[0].activeCode == "N" ?

               <ShimmeredDetailsList 
              items={state.providerPageList}
              columns={columns}
              selectionMode={SelectionMode.none}
              enableShimmer={state.isLoading}
              className={classes.tableN}
              onRenderRow={_renderRow}
              />
                :
                null
            } */}
          <div style={{ display: state.isLoading ? "none" : "block", paddingBottom: 10 }}>
            <Pagination
              items={resultList}
              onChangePage={onChangePage}
              // handleTaxIdChange={handleTaxIdChange}
              // handleAddressChange={handleAddressChange}
              // handleMPINChange={handleMPINChange}
              handleResultFilterChange={handleResultFilterChange}
              ExportData={multiDataSet}
              fetchResultsOnPageChange={fetchResultsOnPageChange}
              metadata={metadata}
              fetchResultsOnExportExcel={fetchResultsOnExportExcel}
              exportSearchParams={multiDataSet_with_search_param}
              clearAllFilters={clearAllFilters}
              handleError={handleError}
              errorDetails={errorDetails}
            ></Pagination>
          </div>
        </div>
      </React.Fragment >
    </div >

  );
}

TableResultProviderComponent.propTypes = {
  resultList: PropTypes.arrayOf(PropTypes.any),
  fetchingResults: PropTypes.bool.isRequired
};

export default TableResultProviderComponent;
