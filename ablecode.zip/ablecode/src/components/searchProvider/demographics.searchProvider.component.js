/* eslint-disable */
import React, { useState } from 'react';
import PropTypes from 'prop-types';
//import { Multiselect } from 'multiselect-react-dropdown'
import { Multiselect } from '../customComponents/multiselect-react-dropdown/src/multiselect/multiselect.component.js';
import { makeStyles, withStyles } from '@material-ui/core/styles';
import Paper from '@material-ui/core/Paper';
import Typography from '@material-ui/core/Typography';
import Grid from '@material-ui/core/Grid';
import FormControl from '@material-ui/core/FormControl';
import OutlinedInput from '@material-ui/core/OutlinedInput';
import HelpIcon from '@material-ui/icons/Help';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import Tooltip from '@material-ui/core/Tooltip';
import FormHelperText from '@material-ui/core/FormHelperText';

import fieldList, { states } from '../../utils/fields.constant';
import validateField from '../../utils/validator';
import { PhoneMask, ZipMask } from '../../utils/custom.input';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import RadioGroup from '@material-ui/core/RadioGroup';
import Radio from '@material-ui/core/Radio';
import Autocomplete from "@material-ui/lab/Autocomplete";
import TextField from "@material-ui/core/TextField";
import { getStatefullname } from "../../utils/fields.constant";
import { TramRounded } from '@material-ui/icons';
//import Select from 'react-select';
//import style from 'react-select/dist/react-select.css';

const LightTooltip = withStyles(theme => ({
  tooltip: {
    backgroundColor: theme.palette.common.white,
    color: 'rgba(0, 0, 0, 0.87)',
    boxShadow: theme.shadows[5],
    fontSize: 11,
    maxWidth: 120
  },
  arrow: {
    color: theme.palette.common.white,
  }
}))(Tooltip);

const useStyles = makeStyles(() => ({
  root: {
    margin: '1rem',
    padding: '1rem'
  },
  headerText: {
    color: '#757588',
    fontWeight: 'bold',
    marginBottom: '1em'
  },
  inputText: {
    color: '#000000',
    fontSize: '12px',
    // lineHeight: '1',
    //marginBottom: '0.25em',
  },
  inputNamesText: {
    cursor: 'text',
    color: '#000000',
    fontSize: '12px',
    // lineHeight: '1',
    marginBottom: '-2.00em',
    marginLeft: '1.25em'
  },
  icon: {
    color: '#757588',
    width: '0.6em',
    height: '0.6em',
    paddingLeft: '0.5em',
  },
  customInput: {
    padding: '6px 10px'
  },
  customRadioCheckedIcon: {
    width: 10,
    height: 10,
    border: '2px solid #0091FF',
    borderRadius: '12px',
    backgroundColor: '#0091FF'
  },
  customRadioIcon: {
    width: 10,
    height: 10,
    border: '2px solid #0091FF',
    borderRadius: '12px'
  },
  formControl: {
    marginTop: '0.25rem'
  },
  radioInput: {
    padding: '0px 9px 0px 9px'
  },
  disabled: {
    backgroundColor: 'rgba(0, 0, 0, 0.09)'
  },
  customWidth: {
    maxWidth: 320,
  },
}));

function DemographicsSearchProviderComponent({ handleDemographicsChange, demographicsDetails, platformDetails, universalDetails, handleError, errorDetails }) {
  const classes = useStyles();
  let _states = useState(states);
  let _selectValues = [];
  for (var i = 0; i < demographicsDetails.state.split(',').length; i++) {
    if (demographicsDetails.state.split(',')[i] != "") {
      _selectValues.push({
        label: demographicsDetails.state.split(',')[i],
        value: demographicsDetails.state.split(',')[i],
        title: getStatefullname(demographicsDetails.state.split(',')[i])
      })
    }
  }
  let _statesNew = [];
  for (var i = 0; i < _states[0].length; i++) {
    _statesNew.push({
      label: _states[0][i].label,
      value: _states[0][i].value,
      title: getStatefullname(_states[0][i].label)
    })
  }
  const options = _statesNew;
  // console.log("********************************")
  // console.log("options", options)
  // console.log("********************************")
  const { lastGroupName, firstName, middleName, telephone, state, zip, areacode } = demographicsDetails;
  let selectedstate = [];
  if (demographicsDetails.state.split(",").length > 0) {
    for (var i = 0; i < demographicsDetails.state.split(",").length; i++) {
      if (demographicsDetails.state.split(",")[i] != "")
        selectedstate.push({ value: demographicsDetails.state.split(",")[i], label: demographicsDetails.state.split(",")[i] });
    }
    //demographicsDetails.state.length>0? demographicsDetails.state.split(','):[];
  }
  const { ziperror, stateerror } = errorDetails;
  const [fieldState, setState] = React.useState({
    lastGroupName: false,
    firstName: false,
    middleName: false,
    telephone: false,
    zip: false,
    areacode: false,
    altLastGroupName: false,
    altFirstName: false,
    altMiddleName: false,
    lastGroupNameWild: false,
    firstNameWild: false,
    middleNameWild: false
  });
  const [statefor, setStatefor] = React.useState({
    lastNameType: 'LastName',
    firstNameType: 'firstName',
    middleNameType: 'middleName'
  })
  const handleLastNameChange = event => {
    setStatefor({ ...statefor, lastNameType: event.target.value });
  };
  const handleFirstNameChange = event => {
    setStatefor({ ...statefor, firstNameType: event.target.value })
  }
  const handleMiddleNameChange = event => {
    setStatefor({ ...statefor, middleNameType: event.target.value })
  }
  const handleInputChange = prop => event => {
    // setState({
    //   ...fieldState,
    //   [prop]: !validateField(prop, event.target.value)
    // });
    if (!validateField(prop, event.target.value)) {
      setState({ ...fieldState, [prop]: true })
      handleError('disableButton', true)
    }
    else {
      handleError('disableButton', false)
      setState({ ...fieldState, [prop]: false })
    }
    handleDemographicsChange(prop, event.target.value)
    let value = event.target.value
    if (prop == 'lastGroupName') {
      if (hideErrorafterClickingDependent() == true) {
        handleError('ziperror', false)
        handleError('pfxsfxerror', false)
        handleError('uhciderror', false)
        handleError('stateerror', false)
        handleError('disableButton', false)
      }
      if (value.length == 0) {
        setState({ ...fieldState, lastGroupNameWild: false, lastGroupName: false })
      }
      if (value.length == 65) {
        document.getElementById('first-name').focus()
      }
      if (fieldState.lastGroupNameWild == true) {
        value = value.split('')
        if (value.includes('*') == false || value.length >= 6) {
          setState({ ...fieldState, lastGroupNameWild: false })
          handleError('disableButton', false)
        }
      }
    }
    if (prop == 'firstName') {
      if (hideErrorafterClickingDependent() == true) {
        handleError('ziperror', false)
        handleError('pfxsfxerror', false)
        handleError('uhciderror', false)
        handleError('stateerror', false)
        handleError('disableButton', false)
      }
      if (value.length == 20) {
        document.getElementById('middle-name').focus()
      }
      if (value.length == 0) {
        setState({ ...fieldState, firstNameWild: false, firstName: false })
      }
      if (fieldState.firstNameWild == true) {
        value = value.split('')
        if (value.includes('*') == false || value.length >= 6) {
          setState({ ...fieldState, firstNameWild: false })
          handleError('disableButton', false)
        }
      }
    }
    if (prop == 'zip') {
      if (value.length == 0) {
        handleError('ziperror', false)
        handleError('disableButton', false)
      }
    }
    if (prop == 'middleName') {
      if (hideErrorafterClickingDependent() == true) {
        handleError('ziperror', false)
        handleError('pfxsfxerror', false)
        handleError('uhciderror', false)
        handleError('stateerror', false)
        handleError('disableButton', false)
      }
      if (value.length == 20) {
        document.getElementById('telephone-id').focus()
      }
      if (value.length == 0) {
        setState({ ...fieldState, middleNameWild: false, middleName: false })
        handleError('disableButton', false)
      }
      if (fieldState.middleNameWild == true) {
        value = value.split('')
        if (value.includes('*') == false || value.length >= 6) {
          setState({ ...fieldState, middleNameWild: false })
          handleError('disableButton', false)
        }
      }
    }
    if (prop == 'telephone') {
      if (hideErrorafterClickingDependent() == true) {
        handleError('ziperror', false)
        handleError('pfxsfxerror', false)
        handleError('uhciderror', false)
        handleError('stateerror', false)
        handleError('disableButton', false)
      }
      if (value.length == 14) {
        setState({ ...state, telephone: false })
        handleError('disableButton', false)
        document.getElementById('state-name_input').focus()
      }
    }
  };
  const handleKeyPress = prop => event => {
    if (prop == 'lastGroupName') {
      let value = event.target.value
      value = value.split('')
      if (event.key === 'Enter') {
        if (value.includes('*') && value.length < 6) {
          setState({ ...fieldState, lastGroupNameWild: true })
          handleError('disableButton', true)
        }
        // if(fieldState.lastGroupName == true){
        //   handleError('disableButton', true)
        // }
      }
    }
    if (prop == 'firstName') {
      let value = event.target.value
      value = value.split('')
      if (event.key === 'Enter') {
        if (value.includes('*') && value.length < 6) {
          setState({ ...fieldState, firstNameWild: true })
          handleError('disableButton', true)
        }
        // if(fieldState.firstName == true){
        //   handleError('disableButton', true)
        // }
      }
    }
    if (prop == 'middleName') {
      let value = event.target.value
      value = value.split('')
      if (event.key === 'Enter') {
        if (value.includes('*') && value.length < 6) {
          setState({ ...fieldState, middleNameWild: true })
          handleError('disableButton', true)
        }
        // if(fieldState.middleName == true){
        //   handleError('disableButton', true)
        // }
      }
    }
  }
  const handleBlurForMobile = event => {
    let value = event.target.value
    if (value.length == 14) {
      let telnum = value.replace(/\D/g, '');
      telnum.replace(/\D/g, '(');
      telnum.replace(/\D/g, ')');
      telnum.replace(/\s/g, '');
      handleDemographicsChange("telephone", telnum);
    }
    else {
      if (value.length !== 0) {
        setState({ ...fieldState, telephone: true })
        handleError('disableButton', true)
      }
    }
  }
  const handleChangeState = prop => event => {
    setState({
      ...fieldState,
      [prop]: !validateField(prop, event.target.innerText)
    });
    handleDemographicsChange(prop, event.target.innerText);
  }
  const onSelectStatesChange = prop => (selectedList, selectedItem) => { //create for multiple select of state
    // console.log("STATE here A ==== ", prop, selectedList, selectedItem)
    let stateList = selectedList.map(obj => {
      return obj.value
    })
    // console.log("selectedList here A ==== ", stateList)
    let stateValue = "";
    stateValue = (selectedList.length) ? selectedList[0].value : ""
    setState({
      ...fieldState,
      [prop]: !validateField(prop, stateValue)
    });
    handleDemographicsChange(prop, stateList.toString());
    if (showErrorForDependentField() == true) {
      handleError('stateerror', true)
      handleError('disableButton', true)
    }
    if (stateValue == '') {
      handleError('stateerror', false)
      handleError('disableButton', false)
    }
  }
  function isFieldDisabled(type) {
    const field = fieldList.find(fieldItem => fieldItem.type === type);
    return field.isDisabled;
  }

  const handleInputBlur = prop => event => {
    let value = event.target.value;
    if (prop === 'zip' && value !== '') {
      if (showErrorForDependentField() == true) {
        handleError('ziperror', true)
        handleError('disableButton', true)
      }
      for (let i = value.length; i < 5; i++) {
        value = '0' + value;
      }
    }
    const getNum = value.replace(/\D/g, '');
    if (getNum.length === 5) {
      handleDemographicsChange(prop, getNum);
    }
    //setState({ zip: false })
    //handleError('disableButton',false)
  }
  const handleInputBlurForNames = prop => event => {
    let value = event.target.value
    if (prop == 'lastGroupName') {
      value = value.split('')
      if (value.includes('*')) {
        if (value.length < 6) {
          setState({ ...fieldState, lastGroupNameWild: true, lastGroupName: false })
          handleError('disableButton', true)
        }
        else {
          setState({ ...fieldState, lastGroupNameWild: false, lastGroupName: false })
          handleError('disableButton', false)
        }
      }
      // if (value.length == 0) {
      //   setState({ ...fieldState, lastGroupNameWild: false, lastGroupName: false })
      //   handleError('disableButton', false)
      // }
    }
    if (prop == 'firstName') {
      if (value.length == 20) {
        document.getElementById('middle-name').focus()
      }
      value = value.split('')
      if (value.includes('*')) {
        if (value.length < 6) {
          setState({ ...fieldState, firstNameWild: true, firstName: false })
          handleError('disableButton', true)
        }
        else {
          setState({ ...fieldState, firstNameWild: false, firstName: false })
          handleError('disableButton', false)
        }
      }
      // if (value.length == 0) {
      //   setState({ ...fieldState, firstNameWild: false, firstName: false })
      //   handleError('disableButton', false)
      // }
    }
    if (prop == 'middleName') {
      if (value.length == 20) {
        document.getElementById('telephone-id').focus()
      }
      value = value.split('')
      if (value.includes('*')) {
        if (value.length < 6) {
          setState({ ...fieldState, middleNameWild: true, middleName: false })
          handleError('disableButton', true)
        }
        else {
          setState({ ...fieldState, middleNameWild: false, middleName: false })
          handleError('disableButton', false)
        }
      }
      if (fieldState.lastGroupName || fieldState.firstName || fieldState.middleName) {
        handleError('disableButton', true)
      }
      // if (value.length == 0) {
      //   setState({ ...fieldState, middleNameWild: false, middleName: false })
      //   handleError('disableButton', false)
      // }
    }
  }
  const showErrorForDependentField = () => {
    if (platformDetails.mpin !== '' || platformDetails.ptiMpin !== '' || platformDetails.maid !== '' || platformDetails.baid !== '' || platformDetails.uhcid.length >= 11) {
      return false
    }
    else if (universalDetails.taxId !== '' || universalDetails.ssn !== '' || universalDetails.npi !== '') {
      return false
    }
    else if (demographicsDetails.lastGroupName !== '' || demographicsDetails.firstName !== '' || demographicsDetails.middleName !== '' || demographicsDetails.telephone !== '') {
      return false
    }
    else {
      return true
    }
  }
  const hideErrorafterClickingDependent = () => {
    if (platformDetails.uhcid !== '') {
      return true
    }
    else if (universalDetails.pfxsfx !== '') {
      return true
    }
    else if (demographicsDetails.zip !== '') {
      return true
    }
    else if (demographicsDetails.state !== '') {
      return true
    }
    else {
      return false
    }
  }
  return (
    <Paper classes={{ root: classes.root }}>
      <Typography variant="body1" component="div" className={classes.headerText}>
        Demographics
      </Typography>
      <Grid container spacing={5}>
        <Grid item xs={3}>
          <div>
            <FormControl component="fieldset">
              <Tooltip  classes={{ tooltip: classes.customWidth }} title={<div style={{
                backgroundColor: "white",
                color: "black",
                width: "300px",
              }}>
                <br />
                <span style={{ marginLeft: "10px" }}>Begins*, *Ends, *Contains*, and wildcard search supported using:</span>
                <ul style={{ marginTop: "", marginLeft: "-18px" }}>
                  <li>Asterisk (*) for an indefinite amount of additional unknown characters.</li>
                  <li>Question (?) to search a single unknown character space for each ? entered.</li>
                </ul>

                <span style={{ marginLeft: "9px" }}><b>NOTE:</b> 5 or more characters required to execute an asterisk (*) &nbsp;&nbsp;&nbsp;&nbsp;wildcard search.</span>
                <br />  <br />
              </div>} placement="top">
                <FormControlLabel value="LastName" classes={{ label: classes.inputNamesText }} control={<CustomRadio />} label="Last/Group Name" />
                {/* <TextField value="Last/Group Name"  classes={{ label: classes.inputNamesText }} ></TextField> */}
              </Tooltip>
            </FormControl>
          </div>
          <FormControl variant="outlined" fullWidth error={fieldState.lastGroupName || fieldState.lastGroupNameWild}>
            {statefor.lastNameType == 'LastName' ? (
              <OutlinedInput
                id="last-group-name"
                classes={{ input: classes.customInput, disabled: classes.disabled }}
                value={lastGroupName}
                onChange={handleInputChange('lastGroupName')}
                aria-describedby="input-last-or-group-name"
                onBlur={handleInputBlurForNames('lastGroupName')}
                inputProps={{ maxlength: 65 }}
                onKeyPress={handleKeyPress('lastGroupName')}
              // disabled={isFieldDisabled('lastGroupName')}
              />) : (
                <OutlinedInput
                  id="middle-name"
                  classes={{ input: classes.customInput, disabled: classes.disabled }}
                  value={middleName}
                  onChange={handleInputChange('middleName')}
                  aria-describedby="input-middle-name"
                // disabled={isFieldDisabled('middleName')}
                />
              )
            }
            <FormHelperText error style={{ display: fieldState.lastGroupName ? 'block' : 'none' }}>
              Unsupported character combinations:  ",|
            </FormHelperText>
            <FormHelperText error style={{ display: fieldState.lastGroupNameWild ? 'block' : 'none' }}>
              * Wildcard requires 5 character minimum to execute.
            </FormHelperText>
          </FormControl>
        </Grid>
        <Grid item xs={2}>
          <FormControl component="fieldset">
            <RadioGroup aria-label="mpinType" name="mpinType" onChange={handleFirstNameChange} row >
              <Tooltip  classes={{ tooltip: classes.customWidth }} title={<div style={{
                backgroundColor: "white",
                color: "black",
                width: "300px"
              }}>
                <br />
                <span style={{ marginLeft: "10px" }}>Begins*, *Ends, *Contains*, and wildcard search supported using:</span>
                <ul style={{ marginTop: "", marginLeft: "-18px" }}>
                  <li>Asterisk (*) for an indefinite amount of additional unknown characters.</li>
                  <li>Question (?) to search a single unknown character space for each ? entered.</li>
                </ul>

                <span style={{ marginLeft: "9px" }}><b>NOTE:</b> 5 or more characters required to execute an asterisk (*) &nbsp;&nbsp;&nbsp;&nbsp;wildcard search.</span>
                <br />  <br />
              </div>} placement="top">
                <FormControlLabel value="LastName" classes={{ label: classes.inputNamesText }} control={<CustomRadio />} label="First Name" />
              </Tooltip>
            </RadioGroup>
          </FormControl>
          <FormControl variant="outlined" fullWidth error={fieldState.firstName || fieldState.firstNameWild}>
            {statefor.firstNameType == 'firstName' ? (
              <OutlinedInput
                id="first-name"
                classes={{ input: classes.customInput, disabled: classes.disabled }}
                value={firstName}
                onChange={handleInputChange('firstName')}
                aria-describedby="input-first-name"
                disabled={isFieldDisabled('firstName')}
                onBlur={handleInputBlurForNames('firstName')}
                inputProps={{ maxlength: 20 }}
                onKeyPress={handleKeyPress('firstName')}
              />) : (
                <OutlinedInput
                  id="middle-name"
                  classes={{ input: classes.customInput, disabled: classes.disabled }}
                  value={middleName}
                  onChange={handleInputChange('middleName')}
                  aria-describedby="input-middle-name"
                  disabled={isFieldDisabled('middleName')}
                />
              )
            }
            <FormHelperText error style={{ display: fieldState.firstName ? 'block' : 'none' }}>
              Unsupported character combinations:  ",|
            </FormHelperText>
            <FormHelperText error style={{ display: fieldState.firstNameWild ? 'block' : 'none' }}>
              * Wildcard requires 5 character minimum to execute.
            </FormHelperText>
          </FormControl>
        </Grid>
        <Grid item xs={2}>
          <FormControl component="fieldset">
            <RadioGroup aria-label="mpinType" name="mpinType" onChange={handleMiddleNameChange} row>
              <Tooltip  classes={{ tooltip: classes.customWidth }} title={<div style={{
                backgroundColor: "white",
                color: "black",
                width: "300px"
              }}>
                <br />
                <span style={{ marginLeft: "10px" }}>Begins*, *Ends, *Contains*, and wildcard search supported using:</span>
                <ul style={{ marginTop: "", marginLeft: "-18px" }}>
                  <li>Asterisk (*) for an indefinite amount of additional unknown characters.</li>
                  <li>Question (?) to search a single unknown character space for each ? entered.</li>
                </ul>


                <span style={{ marginLeft: "9px" }}><b>NOTE:</b> 5 or more characters required to execute an asterisk (*) &nbsp;&nbsp;&nbsp;&nbsp;wildcard search.</span>
                <br />  <br />
              </div>} placement="top">
                <FormControlLabel value="LastName" classes={{ label: classes.inputNamesText }} control={<CustomRadio />} label="Middle Name" />
              </Tooltip>
            </RadioGroup>
          </FormControl>
          <FormControl variant="outlined" fullWidth error={fieldState.middleName || fieldState.middleNameWild}>
            <OutlinedInput
              id="middle-name"
              classes={{ input: classes.customInput, disabled: classes.disabled }}
              value={middleName}
              onChange={handleInputChange('middleName')}
              aria-describedby="input-middle-name"
              onBlur={handleInputBlurForNames('middleName')}
              inputProps={{ maxlength: 20 }}
              onKeyPress={handleKeyPress('middleName')}
            // disabled={isFieldDisabled('middleName')}
            />
          </FormControl>
          <FormHelperText error style={{ display: fieldState.middleName ? 'block' : 'none' }}>
            Unsupported character combinations:  ",|
          </FormHelperText>
          <FormHelperText error style={{ display: fieldState.middleNameWild ? 'block' : 'none' }}>
            * Wildcard requires 5 character minimum to execute.
            </FormHelperText>
        </Grid>
        <Grid item xs={2} style={{ paddingTop: 25 }}>
          <Tooltip title={<div style={{
            backgroundColor: "white",
            color: "black",
            width: "250px"
          }}>
            <br />
            <span style={{ marginLeft: "10px" }}>10 Digit address telephone number</span>

            <br />  <br />
          </div>} placement="top">
            <Typography variant="body1" component="div" className={classes.inputText}>
              Telephone
          </Typography>
          </Tooltip>

          <FormControl variant="outlined" fullWidth error={fieldState.telephone}>
            <OutlinedInput
              id="telephone-id"
              classes={{ input: classes.customInput, disabled: classes.disabled }}
              value={telephone}
              onChange={handleInputChange('telephone')}
              aria-describedby="input-telephone"
              placeholder="(###) ###-####"
              inputComponent={PhoneMask}
              onBlur={handleBlurForMobile}
            />
            <FormHelperText error style={{ display: fieldState.telephone ? 'block' : 'none' }}>
              10 Digits required
            </FormHelperText>
          </FormControl>
        </Grid>
        <Grid item xs={2} style={{ paddingTop: 25 }}>
          <Tooltip title={<div style={{
            backgroundColor: "white",
            color: "black",
            width: "250px"
          }}>
            <br />
            <div style={{ marginLeft: "10px" }}>
              <span >User may select one or more states.  This is a dependent search field and requires another field
(not identified as dependent) to be populated to execute search.</span>
              <br />
              <span>Hoovering cursor over state code will display full state name.</span>
            </div>

            <br />
          </div>} placement="top">
            <Typography variant="body1" component="div" className={classes.inputText}>
              State
          </Typography>
          </Tooltip>
          <FormControl variant="outlined" fullWidth error={stateerror}>
            <div>
              <Multiselect id="state-name" selectedValues={_selectValues} options={options} avoidHighlightFirstOption={true} showCheckbox={true} closeOnSelect={false} displayValue="label" onSelect={onSelectStatesChange('state')} onRemove={onSelectStatesChange('state')}></Multiselect>
            </div>
            <FormHelperText error style={{ display: stateerror ? 'block' : 'none' }}>
              State requires independent field
            </FormHelperText>
          </FormControl>
          <FormControl variant="outlined" fullWidth>
            {/* <Select
              id="state-name"
              classes={{ root: classes.customInput, disabled: classes.disabled }}
              value={state}
              onChange={handleInputChange('state')}
              aria-describedby="input-state-name"
              disabled={isFieldDisabled('state')}
            >
              <MenuItem value="">State Code</MenuItem>
              {
                states.map(s => (
               <MenuItem title={getStatefullname(s.value)}  key={s.value} value={s.value}>{s.label}</MenuItem>
                ))
              }
            </Select> */}
          </FormControl>
          {/* <Select
          id='state-drop-down'
          options={states}
          onChange={handleInputChange('state')}
          //value={state}
          disabled={isFieldDisabled('state')}
          /> */}
        </Grid>
        <Grid item xs={1} style={{ paddingTop: 25 }}>
          <Tooltip title={<div style={{
            backgroundColor: "white",
            color: "black",
            width: "250px"
          }}>
            <br />
            <div style={{ marginLeft: "10px" }}>
              <span >5 Digit address zip code.  This is a dependent search field and requires another field (not identified as dependent) to be populated to execute search.</span>
            </div>

            <br />
          </div>} placement="top">
            <Typography variant="body1" component="div" className={classes.inputText}>
              Zip Code
          </Typography>
          </Tooltip>
          <FormControl variant="outlined" fullWidth error={ziperror}>
            <OutlinedInput
              id="zip-code"
              classes={{ input: classes.customInput, disabled: classes.disabled }}
              value={zip}
              onChange={handleInputChange('zip')}
              aria-describedby="input-zip-code"
              //placeholder="#####"
              inputComponent={ZipMask}
              disabled={isFieldDisabled('zip')}
              onBlur={handleInputBlur('zip')}
            //onKeyDown ={handleClick}
            />
            <FormHelperText error style={{ display: ziperror ? 'block' : 'none' }}>
            Zip code requires independent field
            </FormHelperText>
          </FormControl>
        </Grid>
      </Grid>
    </Paper>
  );
}

function CustomRadio(props) {
  const classes = useStyles();
  return (
    <h6></h6>
    // <Radio
    //   size="small"
    //   disableRipple
    //   disableFocusRipple
    //   disableTouchRipple
    //   classes={{ root: classes.radioInput }}
    //   icon={<span className={classes.customRadioIcon} />}
    //   checkedIcon={<span className={classes.customRadioCheckedIcon} />}
    //   {...props}
    // />
  );
}

DemographicsSearchProviderComponent.propTypes = {
  handleDemographicsChange: PropTypes.func.isRequired,
  demographicsDetails: PropTypes.any
};

export default DemographicsSearchProviderComponent;
