/* eslint-disable */
import React from 'react';
import PropTypes from 'prop-types';

import { makeStyles } from '@material-ui/core/styles';
import Paper from '@material-ui/core/Paper';
import Typography from '@material-ui/core/Typography';
import Grid from '@material-ui/core/Grid';
import FormControl from '@material-ui/core/FormControl';
import OutlinedInput from '@material-ui/core/OutlinedInput';
import HelpIcon from '@material-ui/icons/Help';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import FormHelperText from '@material-ui/core/FormHelperText';
import Tooltip from '@material-ui/core/Tooltip';
import fieldList from '../../utils/fields.constant';
import validateField from '../../utils/validator';
import { MpinMask,PTIMpinMask,MaidMask,BaidMask,UhcidMask,BsarMask,CspidMask,SequenceMask,DivMask,SpecialityMask } from '../../utils/custom.input';
import {conformToMask} from 'react-text-mask';
import { error } from 'winston';
import { KeyboardTab } from '@material-ui/icons';


const useStyles = makeStyles(() => ({
  root: {
    margin: '1rem',
    padding: '1rem'
  },
  headerText: {
    color: '#757588',
    fontWeight: 'bold',
    marginBottom: '1em'
  },
  inputText: {
    color: '#000000',
    fontSize: '12px',
    lineHeight: '1',
    marginBottom: '0.25em'
  },
  icon: {
    color: '#757588',
    width: '0.6em'
  },
  customInput: {
    padding: '6px 10px'
  },
  sequenceInput:{
    padding: '6px 6px'
  },
  customRadioCheckedIcon: {
    width: 10,
    height: 10,
    border: '2px solid #0091FF',
    borderRadius: '12px',
    backgroundColor: '#0091FF'
  },
  customRadioIcon: {
    width: 10,
    height: 10,
    border: '2px solid #0091FF',
    borderRadius: '12px'
  },
  formControl: {
    marginTop: '0.25rem'
  },
  radioInput: {
    padding: '0px 9px 0px 9px'
  },
  disabled: {
    backgroundColor: 'rgba(0, 0, 0, 0.09)'
  }
}));

function PlatformSearchProviderComponent ({ handlePlatformChanges, platformDetails,universalDetails,demographicsDetails,handleError,errorDetails }) {
  const classes = useStyles();
  const [state, setState] = React.useState({
    mpinType: platformDetails.ptiMpin != '' ? 'ptiMpin':'mpin',
    aidType: platformDetails.baid !='' ? 'baid':'maid',
    claimType: 'dec_fac',
    mpin: false,
    ptiMpin: false,
    maid: false,
    baid: false,
    uhcid: false,
    sequence:false,
    bsar: false,
    hccp: false,
    decFac: false,
    claimId: false,
    pulseId: false,
    cspId: false
  });
  const {uhciderror,speciality,sequence,div} = errorDetails
  const { mpin, ptiMpin, maid, baid, uhcid, bsar, hccp, decFac, claimId, pulseId, cspId } = platformDetails;
  const handleInputChange = prop => event => {
    setState({
      ...state,
      [prop]: !validateField(prop, event.target.value)
    });
    if(hideErrorafterClickingDependent() == true){
      handleError('disableButton',false)
      handleError('ziperror',false)
      handleError('pfxsfxerror',false)
      handleError('stateerror',false)
      handleError('uhciderror',false)
    }
    handlePlatformChanges(prop, event.target.value);
    let value = event.target.value
    if(prop == 'mpin' || prop == 'ptiMpin'){
      if(value.length == 9){
        if(prop =='ptiMpin' && state.aidType =='baid'){
          document.getElementById('baid-id').focus()
        }else{
          document.getElementById('maid-id').focus()
        }
      }
    }
    if(prop =='maid' || prop=='baid'){
      if(value.length ==9){
        document.getElementById('uhc-id').focus()
      }
    }
  };
  const handleMPINTypeChange = event => {
    setState({...state, mpinType: event.target.value});
    handlePlatformChanges('mpin','')
    handlePlatformChanges('ptiMpin','')
  };
  const handleAIDTypeChange = event => {
    handlePlatformChanges('maid','')
    handlePlatformChanges('baid','')
    setState({...state, aidType: event.target.value});
  };
  const handleClaimTypeChange = event => {
    setState({...state, claimType: event.target.value});
  };
  const handleInputChangeForSpeciality =  event =>{
    if(event.target.value.length == 0){
      handleError('uhciderror',false)
      handleError('disableButton',false)
    }
    //setUhcid({...Uhcid,speciality:event.target.value})
    if(event.target.value.length == 4){
      document.getElementById('uhc-id-sequence').focus()
    }
    if(hideErrorafterClickingDependent() == true && platformDetails.uhcid.length >=11){
      handleError('disableButton',false)
      handleError('ziperror',false)
      handleError('pfxsfxerror',false)
      handleError('stateerror',false)
      handleError('uhciderror',false)
    }
    if(state.sequence == true && sequence !='' && sequence != undefined){
      setState({...state,sequence:false})
      handleError('sequenceError',false)
      handleError('disableButton',false)
      let value = event.target.value
      handleError('speciality',value)
      handlePlatformChanges('uhcid',value+'-'+sequence)
      if(div !='' && div != undefined){
        handlePlatformChanges('uhcid',value+'-'+sequence+'-'+div)
      }
    }
    else{
      if(sequence !='' && sequence != undefined && event.target.value.length !=0){
      handlePlatformChanges('uhcid', event.target.value+'-'+sequence)
      handleError('speciality',event.target.value)
      if(div !='' && div != undefined){
        handlePlatformChanges('uhcid',event.target.value+'-'+sequence+'-'+div)
      }  }
      else{
      if(event.target.value.length <=4){
      handlePlatformChanges('uhcid', event.target.value)
      handleError('speciality',event.target.value)
      if(sequence !='' && sequence != undefined && event.target.value ==0){
        handlePlatformChanges('uhcid',sequence)
        setState({...state,sequence:true})
        handleError('sequenceError',true)
      }
      }
      else{
        let tempValue = event.target.value
        if(tempValue.length >= 5){
          document.getElementById('uhc-id').value = tempValue
        }
          else{
            handlePlatformChanges('uhcid', event.target.value.substr(0,4))
          }
      }
    }
      }
  }
  // console.log('uhcid details ------->',platformDetails.uhcid)
  const handleInputBlurForSpeciality = event =>{
    if(event.target.value.length >= 5){
        let value = event.target.value
        let tempValue =value.replace(/[^a-zA-Z0-9]/g, "")
        if(tempValue.substr(11,3).match(/^[A-Za-z]+$/)){
          handleError('speciality',tempValue.substr(0,4))
          handleError('sequence',tempValue.substr(4,7))
          handleError('div',tempValue.substr(11,3))
          handlePlatformChanges('uhcid',tempValue.substr(0,4)+'-'+tempValue.substr(4,7)+'-'+tempValue.substr(11,3))
        }
        else{
          if(tempValue.length >= 5){
            handleError('speciality',tempValue.substr(0,4))
            let tempSequence = tempValue.substr(4,tempValue.length)
            if(tempSequence.length <= 7){
              for(let i = tempSequence.length; i < 7; i++ ) {
                tempSequence = '0' + tempSequence;
              }
              handleError('sequence',tempSequence)
              handlePlatformChanges('uhcid',tempValue.substr(0,4)+'-'+tempSequence)
            }
          }
        }
        // document.getElementById('uhc-id').value = tempValue.substr(0,4)
        // handleError('speciality',tempValue.substr(0,4))
        // document.getElementById('uhc-id-sequence').value = tempValue.substr(4,7)
        // handleError('sequence',tempValue.substr(4,7))
        // if(tempValue.substr(11,3).match(/^[A-Za-z]+$/))
        // {
        // document.getElementById('uhc-id-div').value = tempValue.substr(11,3)
        // handleError('div',tempValue.substr(11,3))
        // let maskedUhcid = mask(value)
        // handlePlatformChanges('uhcid',maskedUhcid)
        // document.getElementById('tax-id').focus()
        // }
        // else{
        // let maskedUhcid = tempValue.substr(0,11)
        //  maskedUhcid = mask(maskedUhcid).slice(0,-1)
        // handlePlatformChanges('uhcid',maskedUhcid)
        // document.getElementById('uhc-id-div').focus()
         //}
    }
    else{
    let value = event.target.value;
    if(value.length >=1 && speciality.length <4){
      if(showErrorForDependentField() == true && sequence == ''){
        handleError('uhciderror',true)
        handleError('disableButton',true)
      }
      for(let i = value.length; i < 4; i++ ) {
        value = '0' + value;
      }
      let tempValue = value
      document.getElementById('uhc-id').value = tempValue
      handleError('speciality',tempValue)
      //setUhcid({...Uhcid,speciality:tempValue})
      if(sequence !='' && sequence != undefined){
        handlePlatformChanges('uhcid',tempValue+'-'+sequence)
        if(div !='' && div != undefined){
          handlePlatformChanges('uhcid',tempValue+'-'+sequence+'-'+div)
        }
      }
      else{
      handlePlatformChanges('uhcid', tempValue)
      handleError('speciality',tempValue)}
      if(state.sequence == true && sequence !='' && sequence != undefined){
        setState({...state,sequence:false})
        handleError('sequenceError',false)
        handleError('disableButton',false)
        handlePlatformChanges('uhcid',value+'-'+sequence)
        if(div != '' && div != undefined){
          handlePlatformChanges('uhcid',value+'-'+div)
        }
      }
    }
    }
    if(hideErrorafterClickingDependent() == true && platformDetails.uhcid.length >=11){
      handleError('disableButton',false)
      handleError('ziperror',false)
      handleError('pfxsfxerror',false)
      handleError('stateerror',false)
      handleError('uhciderror',false)
      }
  }
  const handleKeyPress = prop => event =>{
    if(prop == 'speciality'){
      let value = event.target.value
      if (event.key === 'Enter'&& value.length != 0) {
       if(value.length <=4){
        for(let i = value.length; i < 4; i++ ) {
          value = '0' + value;
        }
        handleError('speciality',value)
        handlePlatformChanges('uhcid',value)
        if(sequence !='' && sequence != undefined){
        handlePlatformChanges('uhcid',value+'-'+sequence)
        if(div !='' && div != undefined){
          handlePlatformChanges('uhcid',value+'-'+sequence+'-'+div)
        }}
      }
      else{
        handleError('speciality',value.substr(0,4))
        handlePlatformChanges('uhcid',value.substr(0,4))
        if(sequence !='' && sequence != undefined){
          handlePlatformChanges('uhcid',value.substr(0,4)+'-'+sequence)
          if(div !='' && div != undefined){
            handlePlatformChanges('uhcid',value.substr(0,4)+'-'+sequence+'-'+div)
          }}
      }    
  }}
    if(prop == 'sequence'){
      let value = event.target.value
      if (event.key === 'Enter' && value.length != 0) {
         if(speciality != '' && speciality != undefined && value.length <=7){
          for(let i = value.length; i < 7; i++ ) {
            value = '0' + value;
          }
          handleError('sequence',value)
          handlePlatformChanges('uhcid',speciality+'-'+value)
          if(div !='' && div != undefined){
            handlePlatformChanges('uhcid',speciality+'-'+value+'-'+div)
          }
          }
          else{
            setState({...state,sequence:true})
            handleError('sequenceError',true)
            handleError('disableButton',true)
          }
    }}
}
  const handleInputChangeForSequence =  event =>{
    if(event.target.value.length == 0){
      handleError('uhciderror',false)
      handleError('disableButton',false)
    }
    if(speciality != '' && speciality != undefined && event.target.value.length !=0){
      //setUhcid({...Uhcid,sequence:event.target.value})
      handleError('uhciderror',false)
      handleError('disableButton',false)
      handleError('sequence',event.target.value)
      let value = speciality+'-'+event.target.value
      handlePlatformChanges('uhcid', value)
      if(div != '' && div != undefined){
        handlePlatformChanges('uhcid',value+'-'+div)
      }
    }
    else{
    //setUhcid({...Uhcid,sequence:event.target.value})
    handlePlatformChanges('uhcid', event.target.value)
    handleError('sequence',event.target.value);
    if(div !='' && div != undefined){
      handlePlatformChanges('uhcid', div)
    }
    if(speciality !='' && speciality != undefined){
      handlePlatformChanges('uhcid',speciality)
    }
   }
    if(event.target.value.length == 0){
      setState({...state,sequence:false})
      handleError('sequenceError',false)
    }
    if(event.target.value.length == 7){
      document.getElementById('uhc-id-div').focus()
    }
    if(hideErrorafterClickingDependent() == true && platformDetails.uhcid.length >=11){
      handleError('disableButton',false)
      handleError('ziperror',false)
      handleError('pfxsfxerror',false)
      handleError('stateerror',false)
      handleError('uhciderror',false)
    }
  }

  const handleInputBlurForSequence = event =>{
    let value = event.target.value;
    if(value.length >=1 && sequence.length <=7){
      for(let i = value.length; i < 7; i++ ) {
        value = '0' + value;
      }
      let tempValue = value
      document.getElementById('uhc-id-sequence').value = tempValue
      //setUhcid({...Uhcid,sequence:tempValue})
      //handleError('sequence',tempValue)
      let value1 =''
      if(speciality != '' && speciality != undefined){
          handleError('uhciderror',false)
          handleError('disableButton',false)
           value1 = speciality+'-'+tempValue
          handleError('sequence',tempValue)
          handlePlatformChanges('uhcid',value1)
          if(div != '' && div != undefined){
            handlePlatformChanges('uhcid',value1+'-'+div)
          }
      }
       else{
         if(showErrorForDependentField() == true){
          setState({...state,sequence:true})
          handleError('sequenceError',true)
          //handleError('uhciderror',true)
          handleError('disableButton',true)
        }
        setState({...state,sequence:true})
        handleError('sequenceError',true)
        handleError('disableButton',true)
        handlePlatformChanges('uhcid', tempValue)
        handleError('sequence', tempValue)
       }
       if(hideErrorafterClickingDependent() == true && value1.length >=11){
        handleError('disableButton',false)
        handleError('ziperror',false)
        handleError('pfxsfxerror',false)
        handleError('stateerror',false)
        handleError('uhciderror',false)
      }
    }
  }
  const handleInputChangeForDiv =  event =>{
    if(event.target.value.length == 0){
      handleError('uhciderror',false)
      handleError('disableButton',false)
    }
    if(speciality != '' && speciality !=undefined && sequence !='' && sequence !=undefined){
      //setUhcid({...Uhcid,div:event.target.value})
      handleError('div',event.target.value)
      let value = speciality+'-'+sequence+'-'+event.target.value
      if(event.target.value.length ==0){
        value = speciality+'-'+sequence
      }
      handlePlatformChanges('uhcid', value.toUpperCase())
      if(hideErrorafterClickingDependent() == true && platformDetails.uhcid.length >=11){
        handleError('disableButton',false)
        handleError('ziperror',false)
        handleError('pfxsfxerror',false)
        handleError('stateerror',false)
        handleError('uhciderror',false)
      }
      //handleError('div',event.target.value)
    }
    // else if(Uhcid.speciality !== '' && Uhcid.sequence == ''){
    //   setUhcid({...Uhcid,div:event.target.value})
    //   let value = Uhcid.speciality+'-'+event.target.value
    //   handlePlatformChanges('uhcid', value)
    // }
    // else if(Uhcid.speciality =='' && Uhcid.sequence !==''){
    //   setUhcid({...Uhcid,div:event.target.value})
    //   let value = Uhcid.sequence+'-'+event.target.value
    //   handlePlatformChanges('uhcid', value)
    // }
    else{
    //setUhcid({...Uhcid,div:event.target.value})
    handlePlatformChanges('uhcid', event.target.value.toUpperCase());
      handleError('div',event.target.value.toUpperCase())
  }
    if(event.target.value.length == 3){
      document.getElementById('tax-id').focus()
    }
  }
  const handleInputBlurForDiv = event =>{
    let value = event.target.value;
    if(value.length >=1){
      if(showErrorForDependentField() == true){
        handleError('uhciderror',true)
        handleError('disableButton',true)
        //handlePlatformChanges('uhcid', value)
      }
      if(speciality !='' && sequence !='' && speciality != undefined && sequence !=undefined){
        handleError('uhciderror',false)
        handleError('disableButton',false)
      }
      if(hideErrorafterClickingDependent() == true && platformDetails.uhcid.length >=11){
        handleError('disableButton',false)
        handleError('ziperror',false)
        handleError('pfxsfxerror',false)
        handleError('stateerror',false)
        handleError('uhciderror',false)
      }
    }
  }

  const handleInputBlur = prop => event => {
    let value = event.target.value;
    if (prop === 'maid' && value !== '') {
      for(let i = value.length; i < 9; i++ ) {
        value = '0' + value;
      }
      handlePlatformChanges(prop, value);
    }
    if (prop === 'baid' && value !== '') {
      for(let i = value.length; i < 9; i++ ) {
        value = '0' + value;
      }
      handlePlatformChanges(prop, value);
    }
    // const getNum = value.replace(/\D/g, '');
    //if (value.length === 9) {
      //console.log('value---->',value)
      // handlePlatformChanges(prop, getNum.match(/\d{3}(?=\d{2,2})|\d+/g).join("-"));
    //}
  };
  
  const mask = (rawValue) => {
    let maskUhcid = [/[0-9]/,/[0-9]/, /[0-9]/, /[0-9]/, "-" ,/[0-9]/, /[0-9]/, /[0-9]/,/[0-9]/, /[0-9]/, /[0-9]/, /[0-9]/,"-",/[a-zA-Z]/, /[a-zA-Z]/, /[a-zA-Z]/]
    return conformToMask(rawValue,maskUhcid,{guide: false}).conformedValue
  }

  function isFieldDisabled (type) {
    const field = fieldList.find(fieldItem => fieldItem.type === type);
    return field.isDisabled;
  }

  const showErrorForDependentField = () => {
      if(platformDetails.mpin !== '' || platformDetails.ptiMpin !=='' ||platformDetails.maid !=='' ||platformDetails.baid !=='' ||platformDetails.uhcid.length >= 11){
        return false
      }
      else if(universalDetails.taxId !=='' || universalDetails.ssn !=='' ||universalDetails.npi !==''){
        return false
      }
      else if(demographicsDetails.lastGroupName !=='' || demographicsDetails.firstName !=='' || demographicsDetails.middleName !=='' || demographicsDetails.telephone !==''){
        return false
      }
      else {
        return true
      }
  }
  const hideErrorafterClickingDependent =() =>{
    if(platformDetails.uhcid !== ''){
      return true
    }
    else if(universalDetails.pfxsfx !==''){
      return true
    }
    else if(demographicsDetails.zip !==''){
      return true
    }
    else if(demographicsDetails.state !==''){
      return true
    }
    else{
      return false
    }
  }
  //console.log('length of uhcid',platformDetails.uhcid.length)
  return (
    <Paper classes={{root: classes.root}}>
      <Typography variant="body1" component="div" className={classes.headerText}>
        Platform ID&apos;s
      </Typography>
      <Grid container spacing={5}>
        <Grid item xs={3}>
          <div>
          <FormControl component="fieldset">
            <RadioGroup aria-label="mpinType" name="mpinType" onChange={handleMPINTypeChange} row>
            <Tooltip title={<div style={{
                  backgroundColor: "white",
                  color: "black",
                  width: "260px"
                }}>
                  <br />
                  <div style={{ marginLeft: "10px" }}>
                  <span >9 Digit NDB Medical Provider Identification Number leveraged to uniquely identify a single provider 
                         and reference associated details such as (but not limited to):<br/>
                         • Profile/Credentialing<br/>
                         • Contracts/Rates<br/>
                         • Claims
                  </span>
                  </div>
               
                   <br />
                </div>} placement="top">
              <FormControlLabel value="mpin" classes={{label: classes.inputText}} control={<CustomRadio />} label="MPIN" checked={state.mpinType === 'mpin'} />
            </Tooltip>
            <Tooltip title={<div style={{
                  backgroundColor: "white",
                  color: "black",
                  width: "260px"
                }}>
                  <br />
                  <div style={{ marginLeft: "10px" }}>
                  <span >
                  Group Medical Provider Identification Number (MPIN) to which individual provider records(s) are 
                  tied.  Selecting radio option to search by PTI MPIN will return both the entered PTI MPIN and its 
                  affiliated practitioners.  If there are no affiliated MPIN’s, only the MPIN entered will be 
                  returned.

                        </span>
                  </div>
               
                   <br />
                </div>} placement="top">
              <FormControlLabel value="ptiMpin" classes={{label: classes.inputText}} control={<CustomRadio />} label="PTI MPIN" checked={state.mpinType === 'ptiMpin'} />
            </Tooltip>
            </RadioGroup>
          </FormControl>
        {/*<HelpIcon className={classes.icon} style={{height: '16px'}} />*/} 
          {
            state.mpinType === 'mpin' ? (
              <FormControl variant="outlined" fullWidth error={state.mpin}>
                <OutlinedInput
                  id="mpin-id"
                  classes={{input: classes.customInput, disabled: classes.disabled}}
                  value={mpin}
                  onChange={handleInputChange('mpin')}
                  aria-describedby="input-mpin-id"
                  inputComponent={MpinMask}
                  disabled={isFieldDisabled('mpin')}
                  //onBlur={handleInputBlur('mpin')}
                />
              </FormControl>
            ) : (
              <FormControl variant="outlined" fullWidth>
                <OutlinedInput
                  id="ptiMpin-id"
                  classes={{input: classes.customInput, disabled: classes.disabled}}
                  value={ptiMpin}
                  inputComponent={PTIMpinMask}
                  onChange={handleInputChange('ptiMpin')}
                  aria-describedby="input-ptiMpin-id"
                  // disabled={isFieldDisabled('ptiMpin')}
                />
              </FormControl>
            )
          }
          </div>
        </Grid>
        <Grid item xs={3}>
          <FormControl component="fieldset">
            <RadioGroup aria-label="aidType" name="aidType" onChange={handleAIDTypeChange} row>
            <Tooltip title={<div style={{
                  backgroundColor: "white",
                  color: "black",
                  width: "260px"
                }}>
                  <br />
                  <div style={{ marginLeft: "10px" }}>
                  <span >
                  Master Address ID (M-AID) is a system assigned reference number used to identify a specific, unique 
                 address record on the NDB master table.  


                        </span>
                  </div>
               
                   <br />
                </div>} placement="top">
              <FormControlLabel value="maid" classes={{label: classes.inputText}} control={<CustomRadio />} label="MAID" checked={state.aidType === 'maid'} />
              </Tooltip>
              <Tooltip title={<div style={{
                  backgroundColor: "white",
                  color: "black",
                  width: "260px"
                }}>
                  <br />
                  <div style={{ marginLeft: "10px" }}>
                  <span >
                  Billing Address ID (B-AID) can be leveraged to search Master Address ID records with a Billing/Combination address type.  
                  Returned results will display any address with BAID entered and any addresses affiliated with searched Billing/Combination addresses (e.g. Place of Service, Mail, Credentialing).
                  If there are no affiliated addresses, only the BAID entered will be returned.
                 </span>
                  </div>
               
                   <br />
                </div>} placement="top">
              <FormControlLabel value="baid" classes={{label: classes.inputText}} control={<CustomRadio />} label="BAID" checked={state.aidType === 'baid'} />
              </Tooltip>
            </RadioGroup>
          </FormControl>
          {/* <HelpIcon className={classes.icon} style={{height: '16px'}}/>*/}
         
          <FormControl variant="outlined" fullWidth>
            {
              state.aidType === 'maid' ?
                <OutlinedInput
                  id="maid-id"
                  classes={{input: classes.customInput, disabled: classes.disabled}}
                  value={maid}
                  onChange={handleInputChange('maid')}
                  aria-describedby="input-maid-id"
                  inputComponent={MaidMask}
                  onBlur={handleInputBlur('maid')}
                  // placeholder="##########"
                  // disabled={isFieldDisabled('maid')}
                />
              :
                <OutlinedInput
                  id="baid-id"
                  classes={{input: classes.customInput, disabled: classes.disabled}}
                  value={baid}
                  inputComponent={BaidMask}
                  onChange={handleInputChange('baid')}
                  aria-describedby="input-baid-id"
                  onBlur={handleInputBlur('baid')}
                  //placeholder="##########"
                  // disabled={isFieldDisabled('baid')}
                />
            }
          </FormControl>
        </Grid>
        <Grid item xs={3}>
        <Tooltip title={<div style={{
                  backgroundColor: "white",
                  color: "black",
                  width: "260px",
                  height:"114px"
                }}>
                  <div style={{ marginLeft: "10px"}}>
                  <span >
                  11 Digit United Healthcare Identification (UHCID) is a two-part NDB provider number leveraged to 
                  identify provider in COSMOS within a DIV:  
                 </span>
                 <ul style={{ marginTop: "", marginLeft: "-18px" }}>
                    <li>First 4 digits represent the provider specialty.</li>
                    <li>Last 7 digits in combination with the specialty code complete the UHCID number.</li>
                    <li>3 Alpha-character DIV uniquely identifies provider</li>
                  </ul>
                  <br/> 
                  </div>  
                           
                </div>} placement="top">
          <Typography variant="body1" component="div" className={classes.inputText}>
            UHCID
          </Typography>
          </Tooltip>
          <FormControl variant="outlined" fullWidth className={classes.formControl}>
            <Grid container style={{marginTop:0}}>
            <Grid item xs={4}>
            <FormControl error={uhciderror}>  
            <OutlinedInput
              id="uhc-id"
              classes={{input: classes.customInput, disabled: classes.disabled}}
              value={speciality}
              onChange={handleInputChangeForSpeciality}
              aria-describedby="input-uhc-id"
              placeholder="####"
              onBlur={handleInputBlurForSpeciality}
              onKeyPress={handleKeyPress('speciality')}
              inputComponent={UhcidMask}
            />
            </FormControl>
            </Grid>
            <Grid item xs={5}>
            <FormControl error={uhciderror}>  
            <OutlinedInput
              id="uhc-id-sequence"
              classes={{input: classes.customInput, disabled: classes.disabled}}
              value={sequence}
              onChange={handleInputChangeForSequence}
              aria-describedby="input-uhc-id"
              placeholder="#######"
              inputComponent={SequenceMask}
              onBlur={handleInputBlurForSequence}
              onKeyPress={handleKeyPress('sequence')}
            />
            </FormControl>
            </Grid>
            <Grid item xs={3}>
            <FormControl error={uhciderror}>  
            <OutlinedInput
              id="uhc-id-div"
              classes={{input: classes.customInput, disabled: classes.disabled}}
              value={div}
              onChange={handleInputChangeForDiv}
              aria-describedby="input-uhc-id"
              placeholder="DIV"
              inputComponent={DivMask}
              onBlur={handleInputBlurForDiv}
              //onKeyPress={handleKeyPress('div')}
            />
            </FormControl>
            </Grid>
            </Grid>
          </FormControl>
          <FormHelperText error style={{ display: uhciderror ? 'block' : 'none' }}>
          DIV/UHCID 4 digit specialty code requires independent field.
          </FormHelperText>
          <FormHelperText error style={{ display: state.sequence ? 'block' : 'none' }}>
          UHCID 7 digit sequence number requires 4 digit specialty code.
          </FormHelperText>
        </Grid>
        {/* <Grid item xs={2}>
        <Tooltip title={<div style={{
                  backgroundColor: "white",
                  color: "black",
                  width: "260px"
                }}>
                  <br />
                  <div style={{ marginLeft: "10px" }}>
                  <span >
                  11 digit United Healthcare Identification (UHCID) is a two part NDB provider number leveraged to 
                  identify provider in COSMOS.  The first 4 digits represent the provider specialty.  The last 7 digits in 
                  combination with the specialty code uniquely identify provider and their location.  
                 </span>
                  </div>
               
                   <br />
                </div>} placement="top">
          <Typography variant="body1" component="div" className={classes.inputText}>
            UHCID
          </Typography>
          </Tooltip>
          <FormControl variant="outlined" fullWidth className={classes.formControl}>
            <OutlinedInput
              id="uhc-id"
              classes={{input: classes.customInput, disabled: classes.disabled}}
              value={uhcid}
              onChange={handleInputChange('uhcid')}
              aria-describedby="input-uhc-id"
              placeholder="#### ####### DIV"
              disabled={isFieldDisabled('uhcid')}
              inputComponent={UhcidMask}
              onBlur={handleInputBlur('uhcid')}
            />
          </FormControl>
        </Grid>
        <Grid item xs={2}>
        <Tooltip title={<div style={{
                  backgroundColor: "white",
                  color: "black",
                  width: "260px"
                }}>
                  <br />
                  <div style={{ marginLeft: "10px" }}>
                  <span >
                  9 Digit NDB Business Segment Address Relation (BSAR) number leveraged to identify provider in CSP (Community & State) platform.  
                 </span>
                  </div>
               
                   <br />
                </div>} placement="top">
          <Typography variant="body1" component="div" className={classes.inputText}>
            BSAR
          </Typography>
          </Tooltip>
          <FormControl variant="outlined" fullWidth className={classes.formControl}>
            <OutlinedInput
              id="bsar-id"
              classes={{input: classes.customInput, disabled: classes.disabled}}
              value={bsar}
              onChange={handleInputChange('bsar')}
              aria-describedby="input-bsar-id"
              //placeholder="##########"
              inputComponent={BsarMask}
              disabled={isFieldDisabled('bsar')}
            />
          </FormControl>
        </Grid> */}
        {/* <Grid item xs={3}>
          <Typography variant="body1" component="div" className={classes.inputText}>
            HCCP
          </Typography>
          <FormControl variant="outlined" fullWidth className={classes.formControl}>
            <OutlinedInput
              id="hccp-id"
              classes={{input: classes.customInput, disabled: classes.disabled}}
              value={hccp}
              onChange={handleInputChange('hccp')}
              aria-describedby="input-hccp-id"
              placeholder="##########"
              disabled={isFieldDisabled('hccp')}
            />
          </FormControl>
        </Grid> */}
        {/* <Grid item xs={3}>
          <FormControl component="fieldset">
            <RadioGroup aria-label="claimType" name="claimType" onChange={handleClaimTypeChange} row>
              <FormControlLabel value="dec_fac" classes={{label: classes.inputText}} control={<CustomRadio />} label="DEC-FAC" checked={state.claimType === 'dec_fac'} />
              <FormControlLabel value="claimId" classes={{label: classes.inputText}} control={<CustomRadio />} label="Claim ID" checked={state.claimType === 'claimId'} />
            </RadioGroup>
          </FormControl>
          <HelpIcon className={classes.icon} />
          <FormControl variant="outlined" fullWidth>
            {
              state.claimType === 'dec_fac' ?
                <OutlinedInput
                  id="dec_fac-id"
                  classes={{input: classes.customInput, disabled: classes.disabled}}
                  value={decFac}
                  onChange={handleInputChange('decFac')}
                  aria-describedby="input-dec_fac-id"
                  placeholder="##########"
                  disabled={isFieldDisabled('decFac')}
                />
              :
                <OutlinedInput
                  id="claim-id"
                  classes={{input: classes.customInput, disabled: classes.disabled}}
                  value={claimId}
                  onChange={handleInputChange('claimId')}
                  aria-describedby="input-claim-id"
                  placeholder="##########"
                  disabled={isFieldDisabled('claimId')}
                />
            }
          </FormControl>
        </Grid> */}
        {/* <Grid item xs={3}>
          <Typography variant="body1" component="div" className={classes.inputText}>
            Pulse Provider ID
          </Typography>
          <FormControl variant="outlined" fullWidth className={classes.formControl}>
            <OutlinedInput
              id="pulse-id"
              classes={{input: classes.customInput, disabled: classes.disabled}}
              value={pulseId}
              onChange={handleInputChange('pulseId')}
              aria-describedby="input-pulse-id"
              placeholder="##########"
              disabled={isFieldDisabled('pulseId')}
            />
          </FormControl>
        </Grid> */}
        {/* <Grid item xs={2}>
        <Tooltip title={<div style={{
                  backgroundColor: "white",
                  color: "black",
                  width: "260px"
                }}>
                  <br />
                  <div style={{ marginLeft: "10px" }}>
                  <span >
                  12 Digit NDB number leveraged to identify provider in CSP (Community & State) platform.  Number consists of 9 digit MPIN and 3 digit system generated sequence:<br/><br/>  
                  •	Specialist providers will have one CSP ID for each Bill Address record for all its affiliated BSAR records under a given MPIN-TaxID.<br/>
                  •	Primary Care providers will have one CSP ID for each Place of Service Address record and affiliated BSAR records.<br/>
         </span>
                  </div>
               
                   <br />
                </div>} placement="top">
          <Typography variant="body1" component="div" className={classes.inputText}>
            CSP ID
          </Typography>
          </Tooltip>
          <FormControl variant="outlined" fullWidth className={classes.formControl}>
            <OutlinedInput
              id="csp-id"
              classes={{input: classes.customInput, disabled: classes.disabled}}
              value={cspId}
              onChange={handleInputChange('cspId')}
              aria-describedby="input-csp-id"
              placeholder="######### ###"
              inputComponent={CspidMask}
              disabled={isFieldDisabled('cspId')}
            />
          </FormControl>
        </Grid> */}
      </Grid>
    </Paper>
  );
}

function CustomRadio(props) {
  const classes = useStyles();
  return (
    <Radio
      size="small"
      disableRipple
      disableFocusRipple
      disableTouchRipple
      classes={{root: classes.radioInput}}
      icon={<span className={classes.customRadioIcon} />}
      checkedIcon={<span className={classes.customRadioCheckedIcon} />}
      {...props}
    />
  );
}

PlatformSearchProviderComponent.propTypes = {
  handlePlatformChanges: PropTypes.func.isRequired,
  platformDetails: PropTypes.any
};

export default PlatformSearchProviderComponent;