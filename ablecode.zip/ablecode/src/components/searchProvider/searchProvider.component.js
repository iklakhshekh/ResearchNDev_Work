/* eslint-disable */
import React, { useRef } from 'react';
import PropTypes from 'prop-types';

import { makeStyles, responsiveFontSizes } from '@material-ui/core/styles';
import Grid from '@material-ui/core/Grid';
import Button from '@material-ui/core/Button';

import DemographicsSearchProviderComponent from './demographics.searchProvider.component';
import UniversalSearchProviderComponent from './universal.searchProvider.component';
import PlatformSearchProviderComponent from './platform.searchProvider.component';
import HeaderComponent from '../header/header.component';
import { useHistory } from "react-router-dom";
import {clearErrors} from './demographics.searchProvider.component';

const useStyles = makeStyles(() => ({
  root: {
    margin: '4rem 0rem'
  },
  customButton: {
    textTransform: 'none'
  },
  btnPos: {
    textAlign: 'center'
  }
}));

function SearchProviderComponent ({
  handleDemographicsChange,
  demographicsDetails,
  handleUniversalChanges,
  universalDetails,
  handlePlatformChanges,
  platformDetails,
  handleSearchSubmit,
  clearAll,
  clearedSearch,
  handleError,
  errorDetails,
  formError }) 
  {
  // const [state,setState] = React.useState({
  //   disableByUniversal:false
  // })
  // const callbackFunction = (childData) => {
  //   setState({disableByUniversal: childData})
  // }
  const {disableButton,sequenceError} = errorDetails;
  const classes = useStyles();
  let history = useHistory();
  function removeClass(){
    if(document.querySelectorAll('div.Mui-error').length>0){
      var elems = document.querySelectorAll('div.Mui-error')
      for(var i=0;i<elems.length;i++){
        elems[i].classList.remove('Mui-error');
      }
    } 
     if(document.querySelectorAll('p.MuiFormHelperText-filled').length>0){
       var pTags = document.querySelectorAll('p.MuiFormHelperText-filled');
       for(var j=0;j<pTags.length;j++){
        pTags[j].style.display='none';
       }
    clearAll();
      }
    clearAll();
    //comment below code if user doesn't want the default state of search providers page 
    history.push("/providers/");
  }
  const handleFindProviderClick = event =>{
    if(universalDetails.pfxsfx !== '' && showErrorForDependentField() == true){
      handleError('pfxsfxerror',true)
      handleError('disableButton',true)
    }
    else if(demographicsDetails.zip !== '' && showErrorForDependentField() == true){
      handleError('ziperror',true)
      handleError('disableButton',true)
    }
    else if (sequenceError == true){
      handleError('disableButton',true)
    }
    else if(platformDetails.uhcid !=='' && showErrorForDependentField()==true){
      let value = platformDetails.uhcid
      if(value.length >= 3 && value.length <=4 || value.length ==7){
        handleError('uhciderror',true)
        handleError('disableButton',true)
        if(value.length ==7){
          handleError('uhciderror',false)
          handleError('disableButton',true)
        }
      }
      else{
        handleSearchSubmit(event)
      }
    }
    else if(demographicsDetails.state !=='' && showErrorForDependentField()==true){
      handleError('stateerror',true)
      handleError('disableButton',true)
    }
    else if(demographicsDetails.lastGroupName != '' || demographicsDetails.firstName !='' || demographicsDetails.middleName != ''){
        let lastValue = demographicsDetails.lastGroupName
        let firstValue = demographicsDetails.firstName
        let middleValue = demographicsDetails.middleName
        lastValue = lastValue.split('')
        firstValue = firstValue.split('')
        middleValue = middleValue.split('')
        if((lastValue.includes('*') && lastValue.length < 6)||(firstValue.includes('*') && firstValue.length < 6)||(middleValue.includes('*') && middleValue.length < 6)){
          handleError('disableButton',true)
        }
        else if(lastValue.includes('|')||lastValue.includes('"')||firstValue.includes('|')||firstValue.includes('"')||middleValue.includes('|')||middleValue.includes('"')){
          handleError('disableButton',true)
        }
        else{
          handleSearchSubmit(event)
        }
    }
    else{
      if(platformDetails.uhcid.length ==7){
        handleError('disableButton',true)
      }
      else{
      handleSearchSubmit(event)}
    }
  }
  const showErrorForDependentField = () => {
    if(platformDetails.mpin !== '' || platformDetails.ptiMpin !=='' ||platformDetails.maid !=='' ||platformDetails.baid !=='' ||platformDetails.uhcid.length >= 11){
      return false
    }
    else if(universalDetails.taxId !=='' || universalDetails.ssn !=='' ||universalDetails.npi !==''){
      return false
    }
    else if(demographicsDetails.lastGroupName !=='' || demographicsDetails.firstName !=='' || demographicsDetails.middleName !=='' || demographicsDetails.telephone !==''){
      return false
    }
    else {
      return true
    }
}
  return (
    <form>
    <div>
      <HeaderComponent/>
      <PlatformSearchProviderComponent handlePlatformChanges={handlePlatformChanges} platformDetails={platformDetails} universalDetails={universalDetails} 
      demographicsDetails={demographicsDetails} handleError={handleError} errorDetails={errorDetails}/>
      <UniversalSearchProviderComponent handleUniversalChanges={handleUniversalChanges} universalDetails={universalDetails} platformDetails={platformDetails} 
      demographicsDetails={demographicsDetails} handleError={handleError} errorDetails={errorDetails}/>
      <DemographicsSearchProviderComponent handleDemographicsChange={handleDemographicsChange} demographicsDetails={demographicsDetails} platformDetails={platformDetails} 
      universalDetails={universalDetails} handleError={handleError} errorDetails={errorDetails}/>
      <div className={classes.root}>
        <Grid container>
          <Grid item xs={8} />
          <Grid item xs={4}>
            <Grid container spacing={1}>
              <Grid item xs classes={{item: classes.btnPos}}>
                {/* <Button color="primary" className={classes.customButton}>Advance Options</Button> */}
              </Grid>
              <Grid item xs classes={{item: classes.btnPos}}>
                <Button
                  variant="contained"
                  disableElevation
                  className={classes.customButton}
                  onClick={removeClass}
                >
                  Clear All 
                </Button>
              </Grid>
              <Grid item xs>
                <Button
                 type = "submit"
                  variant="contained"
                  color="primary"
                  disableElevation
                  className={classes.customButton}
                  onClick={handleFindProviderClick}
                  disabled={clearedSearch || formError || disableButton}
                >
                  Find Provider
                </Button>
              </Grid>
            </Grid>
          </Grid>
        </Grid>
      </div>
    </div>
    </form>
  );
}

SearchProviderComponent.propTypes = {
  handleDemographicsChange: PropTypes.func.isRequired,
  handleUniversalChanges: PropTypes.func.isRequired,
  handlePlatformChanges: PropTypes.func.isRequired,
  handleSearchSubmit: PropTypes.func.isRequired,
  clearAll: PropTypes.func.isRequired,
  platformDetails: PropTypes.any,
  universalDetails: PropTypes.any,
  demographicsDetails: PropTypes.any,
  clearedSearch: PropTypes.bool.isRequired,
  formError: PropTypes.bool.isRequired,
  handleError:PropTypes.func
};

export default SearchProviderComponent;
