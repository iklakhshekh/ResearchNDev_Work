/* eslint-disable */
import React from 'react';
import PropTypes from 'prop-types';

import { makeStyles } from '@material-ui/core/styles';
import Paper from '@material-ui/core/Paper';
import Typography from '@material-ui/core/Typography';
import Grid from '@material-ui/core/Grid';
import FormControl from '@material-ui/core/FormControl';
import OutlinedInput from '@material-ui/core/OutlinedInput';
import FormHelperText from '@material-ui/core/FormHelperText';
import Tooltip from '@material-ui/core/Tooltip';
import fieldList from '../../utils/fields.constant';
import validateField from '../../utils/validator';
import { TaxMask } from '../../utils/custom.input';
import { NpiMask, SSNMask, PrefixSuffixMask } from '../../utils/custom.input';
import RadioGroup from '@material-ui/core/RadioGroup';
import Radio from '@material-ui/core/Radio';
import FormControlLabel from '@material-ui/core/FormControlLabel';

const useStyles = makeStyles(() => ({
  root: {
    margin: '1rem',
    padding: '1rem'
  },
  headerText: {
    color: '#757588',
    fontWeight: 'bold',
    marginBottom: '1em'
  },
  inputText: {
    color: '#000000',
    fontSize: '12px',
    lineHeight: '1',
    marginBottom: '0.25em'
  },
  customInput: {
    padding: '6px 10px'
  },
  disabled: {
    backgroundColor: 'rgba(0, 0, 0, 0.09)'
  },
  customRadioCheckedIcon: {
    width: 10,
    height: 10,
    border: '2px solid #0091FF',
    borderRadius: '12px',
    backgroundColor: '#0091FF'
  },
  customRadioIcon: {
    width: 10,
    height: 10,
    border: '2px solid #0091FF',
    borderRadius: '12px'
  },
  radioInput: {
    padding: '0px 9px 0px 9px'
  }
}));

function UniversalSearchProviderComponent({ handleUniversalChanges, universalDetails, platformDetails, demographicsDetails, handleError, errorDetails }) {
  const classes = useStyles();
  const { taxId, ssn, npi, pfxsfx } = universalDetails;
  const { pfxsfxerror } = errorDetails;
  const [state, setState] = React.useState({
    ssn: false,
    npi: false,
    ssn: false,
    prfxsfxType: 'prefix',
    ssnWildCard: false
  });

  const handlePrfxSfxTypeChange = event => {
    setState({ ...state, prfxsfxType: event.target.value });
  };
  const handleInputChange = prop => event => {
    setState({
      ...state,
      [prop]: !validateField(prop, event.target.value)
    });
    handleUniversalChanges(prop, event.target.value);
    let value = event.target.value
    if (prop == 'taxId') {
      if (hideErrorafterClickingDependent() == true) {
        handleError('disableButton', false)
        handleError('ziperror', false)
        handleError('pfxsfxerror', false)
        handleError('stateerror', false)
        handleError('uhciderror', false)
      }
      if (value.length == 9) {
        document.getElementById('ssn-id').focus()
      }
    }
    if (prop == 'npi') {
      if (hideErrorafterClickingDependent() == true) {
        handleError('disableButton', false)
        handleError('ziperror', false)
        handleError('pfxsfxerror', false)
        handleError('stateerror', false)
        handleError('uhciderror', false)
      }
      if (value.length == 10) {
        handleError('disableButton', false)
        document.getElementById('pfx_sfx-id').focus()
        setState({ ...state, npi: false })
      }
    }
    if (prop == 'pfxsfx') {
      if (value.length == 0) {
        handleError('pfxsfxerror', false)
        handleError('disableButton', false)
      }
      if (value.length == 7) {
        document.getElementById('last-group-name').focus()
      }
    }
  };
  const handleInputChangeForSSN = prop => event => {
    let value = event.target.value
    if (hideErrorafterClickingDependent() == true) {
      handleError('pfxsfxerror', false)
      handleError('disableButton', false)
    }
    if (hideErrorafterClickingDependent() == true) {
      handleError('disableButton', false)
      handleError('ziperror', false)
      handleError('pfxsfxerror', false)
      handleError('stateerror', false)
      handleError('uhciderror', false)
    }
    value = value.split('')
    if (state.ssnWildCard == true) {
      if (value.includes('*') == false || value.length >= 5) {
        setState({ ...state, ssnWildCard: false })
        handleError('disableButton', false)
      }
    }
    if (value.includes('*')) {
      if (value.length < 5) {
        setState({ ssnWildCard: true, ssn: false })
        handleError('disableButton', true)
      }
      else {
        setState({ ssnWildCard: false, ssn: false })
        handleError('disableButton', false)
      }
      handleUniversalChanges(prop, value.join(''))
    }
    else {
      if (value.length == 9 || value.length == 0) {
        setState({ ssn: false })
        handleError('disableButton', false)
      }
      value = value.join('')
      handleUniversalChanges(prop, value)
    }
    if (value.length == 9) {
      document.getElementById('npi-id').focus()
    }
  }

  const handleInputBlur = prop => event => {
    let value = event.target.value;
    if (prop === 'taxId' && value.length >= 5) {
      for (let i = value.length; i < 9; i++) {
        value = '0' + value;
      }
      handleUniversalChanges(prop, value);
    }
    if (prop === 'pfxsfx' && value.length >= 1) {
      if (showErrorForDependentField() == true) {
        handleError('pfxsfxerror', true)
        handleError('disableButton', true)
      }
      if (value.length >= 3) {
        value = value.split(' ')
        let tempValue = value[0]
        value = value[1]
        for (let i = value.length; i < 5; i++) {
          value = '0' + value;
        }
        value = tempValue + ' ' + value
      }
      handleUniversalChanges(prop, value)
    }
    if (prop === "ssn" && value.length < 9) {
      value = value.split('')
      if (value.includes('*') || value.includes('?')) {
        handleUniversalChanges(prop, value.join(''))
      }
      else {
        if(value.length >= 5){
          value = value.join('')
          for (let i = value.length; i < 9; i++) {
            value = '0' + value;
          }
          handleUniversalChanges(prop, value)
        }
        if (value.length < 5 && value.length != 0) {
          setState({ ...state, ssn: true })
          handleError('disableButton', true)
        }
      }
      // if(value.length ==0){
      //   setState({...state,ssn:false})
      //   handleError('disableButton',false)
      // }
    }
  }
  
  const handleKeyPress = prop => event => {
    if (prop == 'npi') {
      let value = event.target.value
      value = value.split('')
      if (event.key === 'Enter') {
        if (value.length !== 0) {
          setState({ ...state, npi: true })
          handleError('disableButton', true)
        }
      }
    }
    if (prop == 'ssn') {
      let value = event.target.value
      value = value.split('')
      if (event.key === 'Enter') {
        if (prop === "ssn" && value.length < 9) {
          if (value.includes('*') || value.includes('?')) {
            handleUniversalChanges(prop, value.join(''))
          }
          else {
            if(value.length >= 5){
              value = value.join('')
              for (let i = value.length; i < 9; i++) {
                value = '0' + value;
              }
              handleUniversalChanges(prop, value)
              handleError('disableButton', false)
            }
            if (value.length < 5 && value.length != 0) {
              setState({ ...state, ssn: true })
              handleError('disableButton', true)
            }
          }
        }
      }
    }
    if (prop == 'pfxsfx') {
      let value = event.target.value
      if (value.length >= 3 && event.key === 'Enter') {
        value = value.split(' ')
        let tempValue = value[0]
        value = value[1]
        for (let i = value.length; i < 5; i++) {
          value = '0' + value;
        }
        value = tempValue + ' ' + value
      }
      handleUniversalChanges(prop, value)
    }
  }
  const handleInputBlurForNPI = event => {
    let value = event.target.value
    if (value.length == 10) {
      handleUniversalChanges("npi", value);
    }
    else {
      if (value.length !== 0) {
        setState({ ...state, npi: true })
        handleError('disableButton', true)
      }
    }
  }
  function isFieldDisabled(type) {
    const field = fieldList.find(fieldItem => fieldItem.type === type);
    return field.isDisabled;
  }
  const showErrorForDependentField = () => {
    if (platformDetails.mpin !== '' || platformDetails.ptiMpin !== '' || platformDetails.maid !== '' || platformDetails.baid !== '' || platformDetails.uhcid.length >= 11) {
      return false
    }
    else if (universalDetails.taxId !== '' || universalDetails.ssn !== '' || universalDetails.npi !== '') {
      return false
    }
    else if (demographicsDetails.lastGroupName !== '' || demographicsDetails.firstName !== '' || demographicsDetails.middleName !== '' || demographicsDetails.telephone !== '') {
      return false
    }
    else {
      return true
    }
  }
  const hideErrorafterClickingDependent = () => {
    if (platformDetails.uhcid != '') {
      return true
    }
    else if (universalDetails.pfxsfx !== '') {
      return true
    }
    else if (demographicsDetails.zip !== '') {
      return true
    }
    else if (demographicsDetails.state !== '') {
      return true
    }
    else {
      return false
    }
  }
  return (
    <Paper classes={{ root: classes.root }}>
      <Typography variant="body1" component="div" className={classes.headerText}>
        Universal ID&apos;s
      </Typography>
      <Grid container spacing={5}>
        <Grid item xs={3}>
          <Tooltip title={<div style={{
            backgroundColor: "white",
            color: "black",
            width: "250px"
          }}>
            <br />
            <div style={{ marginLeft: "10px" }}>
              <span >9 Digit Tax Identification Number assigned by IRS as an identifier for claims payment.  Provider may also bill their SSN as a Tax ID.</span>
            </div>

            <br />
          </div>} placement="top">
            <Typography variant="body1" component="div" className={classes.inputText}>
              TAXID
          </Typography>
          </Tooltip>
          <FormControl variant="outlined" fullWidth error={state.taxId}>
            <OutlinedInput
              id="tax-id"
              classes={{ input: classes.customInput, disabled: classes.disabled }}
              value={taxId}
              onChange={handleInputChange('taxId')}
              aria-describedby="input-tax-id"
              inputComponent={TaxMask}
              disabled={isFieldDisabled('taxId')}
              onBlur={handleInputBlur('taxId')}
            />
            <FormHelperText error style={{ display: state.taxId ? 'block' : 'none' }}>
              Tax Id can have only 9 numeric characters
            </FormHelperText>
          </FormControl>
        </Grid>
        <Grid item xs={3}>
          <Tooltip title={<div style={{
            backgroundColor: "white",
            color: "black",
            width: "250px"
          }}>
            <br />
            <div style={{ marginLeft: "10px" }}>
              <span >To perform wildcard search, enter asterisk (*) followed by last 4 or more digits.
                  <br /><br />
                <b>  Example:</b>  *2578
               <br /><br />
        9 digit Social Security Number assigned by IRS as an identifier for personal earnings.  Provider may
        also bill their SSN as a Tax ID. Advanced search option is available to compare SSN entered to TAXID.
      </span>
            </div>

            <br />
          </div>} placement="top">
            <Typography variant="body1" component="div" className={classes.inputText}>
              SSN
          </Typography>
          </Tooltip>
          <FormControl variant="outlined" fullWidth error={state.ssn || state.ssnWildCard}>
            <OutlinedInput
              id="ssn-id"
              classes={{ input: classes.customInput, disabled: classes.disabled }}
              value={ssn}
              onChange={handleInputChangeForSSN('ssn')}
              aria-describedby="input-ssn-id"
              inputComponent={SSNMask}
              onBlur={handleInputBlur('ssn')}
              //placeholder="###-####-##"
              disabled={isFieldDisabled('ssn')}
              onKeyPress={handleKeyPress('ssn')}
            />
            <FormHelperText error style={{ display: state.ssn ? 'block' : 'none' }}>
              Exact search requires 9 digits
            </FormHelperText>
            <FormHelperText error style={{ display: state.ssnWildCard ? 'block' : 'none' }}>
              Wildcard search requires 4 digits
            </FormHelperText>
          </FormControl>
        </Grid>
        <Grid item xs={3}>  <Tooltip title={<div style={{
          backgroundColor: "white",
          color: "black",
          width: "250px"
        }}>
          <br />
          <div style={{ marginLeft: "10px" }}>
            <span >10 digit National Provider Identifier </span>
          </div>

          <br />
        </div>} placement="top">
          <Typography variant="body1" component="div" className={classes.inputText}>
            NPI
          </Typography>
        </Tooltip>
          <FormControl variant="outlined" fullWidth error={state.npi}>
            <OutlinedInput
              id="npi-id"
              classes={{ input: classes.customInput, disabled: classes.disabled }}
              value={npi}
              onChange={handleInputChange('npi')}
              aria-describedby="input-npi-id"
              //placeholder="##########"
              inputComponent={NpiMask}
              disabled={isFieldDisabled('npi')}
              onBlur={handleInputBlurForNPI}
              onKeyPress={handleKeyPress('npi')}
            />
            <FormHelperText error style={{ display: state.npi ? 'block' : 'none' }}>
              10 Digits required
            </FormHelperText>
          </FormControl>
        </Grid>
        {/* <Grid item xs={3}>
          <div>
            <FormControl component="fieldset">
              <RadioGroup aria-label="prfxsfxType" name="prfxsfxType" onChange={handlePrfxSfxTypeChange} row>
              <Tooltip title={<div style={{
                  backgroundColor: "white",
                  color: "black",
                  width: "250px"
                }}>
                  <br />
                  <div style={{ marginLeft: "10px" }}>
                  <span >Prefix requires TAXID to be populated to search by this two-part field: <br/>
                      ●  PFX (1 digit) (Does not require SFX to search with this value)<br/>
                  </span>
                  </div>  
               
                   <br />
                </div>} placement="top">
                  <FormControlLabel value="prefix" classes={{ label: classes.inputText }} control={<CustomRadio />} label="Prefix" checked={state.prfxsfxType === 'prefix'} />
                </Tooltip>
                <Tooltip title={<div style={{
                  backgroundColor: "white",
                  color: "black",
                  width: "250px"
                }}>
                  <br />
                  <div style={{ marginLeft: "10px" }}>
                  <span >Suffix requires TAXID to be populated to search by this two-part field: <br/>
                  ●  SFX (1-5 digits) (Requires PFX to search with this value). <br/>         
                  </span>
                  </div>  
               
                   <br />
                </div>} placement="top">
                <FormControlLabel value="sufix" classes={{ label: classes.inputText }} control={<CustomRadio />} label="Sufix" checked={state.prfxsfxType === 'sufix'} />
                </Tooltip>
              </RadioGroup>
            </FormControl>
            <Typography variant="caption">
            </Typography>
          </div>
          <FormControl variant="outlined" fullWidth> 
            {state.prfxsfxType == 'prefix' ? (
              <OutlinedInput
                id="prefix"
                classes={{ input: classes.customInput, disabled: classes.disabled }}
                value={prefix}
                onChange={handleInputChange('prefix')}
                aria-describedby="input-last-or-group-name"
              />) : (
                <OutlinedInput
                  id="sufix"
                  classes={{ input: classes.customInput, disabled: classes.disabled }}
                  value={sufix}
                  onChange={handleInputChange('sufix')}
                  aria-describedby="input-middle-name"
                />
              )
            }
          </FormControl>
        </Grid> */}
        <Grid item xs={3}>
          <Tooltip title={<div style={{
            backgroundColor: "white",
            color: "black",
            width: "250px"
          }}>
            <br />
            <div style={{ marginLeft: "10px" }}>
              <span >To search by this two-part field:<br />
                          • PFX (1 digit) is a dependent search field and requires another field (not identified as dependent) to
                          be populated to execute search.<br />
                          • SFX (1-5 digits) Requires PFX and Tax ID to search to execute search.
                  </span>
            </div>
            <br />
          </div>} placement="top">
            <Typography variant="body1" component="div" className={classes.inputText}>
              PFX/SFX
          </Typography>
          </Tooltip>
          <FormControl variant="outlined" fullWidth error={pfxsfxerror}>
            <OutlinedInput
              id="pfx_sfx-id"
              classes={{ input: classes.customInput, disabled: classes.disabled }}
              value={pfxsfx}
              onChange={handleInputChange('pfxsfx')}
              aria-describedby="input-pfx_sfx-id"
              inputComponent={PrefixSuffixMask}
              //disabled={isFieldDisabled('pfxsfx')}
              placeholder='# #####'
              onBlur={handleInputBlur('pfxsfx')}
              onKeyPress={handleKeyPress('pfxsfx')}
            />
            <FormHelperText error style={{ display: pfxsfxerror ? 'block' : 'none' }}>
              Prefix requires independent field
            </FormHelperText>
          </FormControl>
        </Grid>
      </Grid>
    </Paper>
  );
}

function CustomRadio(props) {
  const classes = useStyles();
  return (
    <Radio
      size="small"
      disableRipple
      disableFocusRipple
      disableTouchRipple
      classes={{ root: classes.radioInput }}
      icon={<span className={classes.customRadioIcon} />}
      checkedIcon={<span className={classes.customRadioCheckedIcon} />}
      {...props}
    />
  );
}

UniversalSearchProviderComponent.propTypes = {
  handleUniversalChanges: PropTypes.func.isRequired,
  universalDetails: PropTypes.any
};

export default UniversalSearchProviderComponent;
