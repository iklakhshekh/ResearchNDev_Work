/* eslint-disable */
import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useHistory } from "react-router-dom";
// import UHC_LOGO from '../../assets/UHC_LOGO.svg';
import Paper from '@material-ui/core/Paper';
import Menu from '@material-ui/core/Menu';
import MenuItem from '@material-ui/core/MenuItem';
import Grid from '@material-ui/core/Grid';
import FormControl from '@material-ui/core/FormControl';
import OutlinedInput from '@material-ui/core/OutlinedInput';
import HelpIcon from '@material-ui/icons/Help';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import NotificationsNoneOutlinedIcon from '@material-ui/icons/NotificationsNoneOutlined';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import Badge from '@material-ui/core/Badge';
import { makeStyles } from '@material-ui/core/styles';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import PersonIcon from '@material-ui/icons/Person';
import Typography from '@material-ui/core/Typography';
import IconButton from '@material-ui/core/IconButton';
import List from '@material-ui/core/List';
import Divider from '@material-ui/core/Divider';
const {getCookie} = require('../../utils/helper');
import initUrlFun from '../../utils/initUrls';
//import { data } from '../../../server/services/logger.service';

let userObj = JSON.parse(getCookie("openIdInfo"));
//debugger

   let user_name;
   let msid;
   let email_id;
   let employee_id;
 



const useStyles = makeStyles(() => ({
    root: {
        flexGrow: 1
    },
    headerText: {
        color: '#757588',
        fontWeight: 'bold',
        marginBottom: '1em',
       
      },
    customAppBar: {
        boxShadow: '0px 0px 0px 0px',
        backgroundColor: '#FFFFFF'
    },
    logo: {
        margin: '15px 0px 10px 25px',
        maxWidth: '180px'
    },
    profileHead: {
        display: 'inline-flex'
    },
    profileText: {
        marginTop: '1em',
        userSelect: 'none',
        color: '#757588',
        fontWeight: 'bold'
    },
    tabRoot: {
        textTransform: 'none'
    },
    panelBg: {
        backgroundColor: '#F9F9F9'
    },
    panel: {
        width: 300
    },
    card: {
        width: 280,
        margin: '0px 10px'
    },
    cardAction: {
        float: 'right'
    },
    fontStyle:{
      "font-size": "1rem",
   "font-family": "Roboto,Helvetica,Arial,sans-serif",
    "font-weight": "400",
    "line-height": "1.5",
    "letter-spacing": "0.00938em"
    }
   
}));

const TabList = [
    // {
    //   label: 'Home',
    //   path: 'home'
    // },
    {
        label: 'Search Provider',
        path: 'search-provider'
    }
    // ,
    // {
    //   label: 'Request list',
    //   path: 'request-list'
    // }
];

export default function HeaderComponent() {
    let history = useHistory();
    const classes = useStyles();
    const { pathname } = useLocation();
    const [state, setState] = React.useState({
        anchorElement: null,
        selectedTab: 0,
        showPanel: false
    });
    if(userObj==null)
    {
      window.location.href = initUrlFun();
    //  user_name=user_name_back;
    }
    else
    {
    user_name=userObj.name;
    msid=userObj.sub;
    email_id=userObj.email;
    employee_id=userObj.employeeId;
    //user_name_back=userObj.name;
    }
    const [getdata,setData] = React.useState('')
    React.useEffect(() => {

        fetchData();
      
      }, []);

   
      const handlelogout = () => {setState({...state, anchorElement: null}),history.push("/providers/logout")};
      const handleuserprofile = () => {setState({...state, anchorElement: null}),history.push("/providers/provider-userprofile")};
    const open = Boolean(state.anchorElement);
    const handleProfileOptionClick = event => setState({...state, anchorElement: event.currentTarget});

    const handleProfileOptionClose = () => setState({...state, anchorElement: null});
    const id = open ? 'profile-options-id' : undefined;
    const toggleNotificationPanel = open => event => {
        if (event.type === 'keydown' && (event.key === 'Tab' || event.key === 'Shift')) {
          return;
        }
        setState({...state, showPanel: open });
      }
    const paths = pathname.split('/');
    if (paths[1] === 'providers' && paths[2]) {
        const index = TabList.findIndex(({ path }) => path === paths[2]);
        if (state.selectedTab !== index) {
            if (paths[2] === 'result-provider' && state.selectedTab !== 1) {
                setState({ ...state, selectedTab: 1 });
            } else if (index !== -1) {
                setState({ ...state, selectedTab: index });
            }
        }
    } 
        const fetchData= () =>{
            let data =''
            fetch('http://localhost:4000/try',{

                method: 'POST',
                body : data
              })
                .then(
                  (response) => {
                    // console.log("response json",response);
                    return response.json();
                  } // if the response is a JSON object
                ).then(
                success =>console.log("sucess object",success) // Handle the success response object
              ).catch(
                error => null // Handle the error response object
              )
                .then(results => {
                    setData(results)
                });
        }
    return (
        <div className={classes.root}>
            <AppBar position="static" color="default" className={classes.customAppBar}>
          
            </AppBar>
       
      <Menu
        id={id}
        anchorEl={state.anchorElement}
        keepMounted
        open={open}
        onClose={handleProfileOptionClose}
        aria-label="page tabs"
      >
        <MenuItem onClick={handleuserprofile}>Profile</MenuItem>
        <MenuItem onClick={handleProfileOptionClose}>My account</MenuItem>
        <MenuItem onClick={handlelogout}>Logout</MenuItem>
      </Menu>

<Paper classes={{root: classes.root}}>
    <br/>
      <Typography variant="body1" component="div" className={classes.headerText}>
          
      &nbsp;&nbsp;&nbsp; User profile
      </Typography>
      <Grid container spacing={5}>
        <Grid item xs={3}>
          <div>
          <FormControl component="fieldset">
          <span className={classes.fontStyle}>    &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Msid :  {msid}</span>
          </FormControl>
       
          </div>
        </Grid>
        <Grid item xs={3}>
          <div>
          <FormControl component="fieldset">
          <span className={classes.fontStyle}>  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Name :  {user_name}</span>
          </FormControl>
       
          </div>
        </Grid>
        <Grid item xs={3}>
          <div>
          <FormControl component="fieldset">
          <span className={classes.fontStyle}>  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Employee Id :  {employee_id}</span>
          </FormControl>
       
          </div>
        </Grid>

        <Grid item xs={3}>
          <div>
          <FormControl component="fieldset">
          <span className={classes.fontStyle}> &nbsp;&nbsp;&nbsp;Email Id :  {email_id}</span>
          </FormControl>
       
          </div>
        </Grid>
      </Grid>
    </Paper>

        </div>
    );
}
