/* eslint-disable */
import ProviderComponent from '../components/provider/provider.component';

const ProviderContainer = ProviderComponent;

export default ProviderContainer;
