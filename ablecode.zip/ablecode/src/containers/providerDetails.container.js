/* eslint-disable */
import React from "react";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import ProviderDetailsComponent from "../components/providerDetails/providerDetails.component";
// import fieldList from '../utils/fields.constant';
import { fetchResults } from "../actions/action";

function providerDetails(resultList, fetchResults) {
  return <ProviderDetailsComponent resultList={resultList} />;
}

providerDetails.propTypes = {
  resultList: PropTypes.any,
  fetchResults: PropTypes.func.isRequired
};
const mapStateToProps = state => {
  return {
    resultList: state.result
  };
};

const mapDispatchToProps = dispatch => ({
  fetchResults: queryParam => dispatch(fetchResults(queryParam))
});

export default connect(mapStateToProps, mapDispatchToProps)(providerDetails);
