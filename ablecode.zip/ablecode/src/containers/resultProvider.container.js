/* eslint-disable */
import React from "react";
import { connect } from "react-redux";
import PropTypes from "prop-types";

import ResultProviderComponent from "../components/resultProvider/resultProvider.component";

import fieldList from "../utils/fields.constant";
import initUrlFun from '../utils/initUrls'
const { getCookie } = require('../utils/helper');
let userObj = JSON.parse(getCookie("openIdInfo"));
let msid;

import {
  removeResultFilter,
  setDemographicsInput,
  setUniversalInput,
  setPlatformInput,
  fetchResults,
  setSelectedMPIN,
  fetchResultsForExcel,
  setErrorInput
} from "../actions/action";

function ResultProviderContainer({
  demographicsDetails,
  universalDetails,
  platformDetails,
  resultList,
  removeResultFilter,
  setDemographicsInput,
  setUniversalInput,
  setPlatformInput,
  fetchingResults,
  fetchResults,
  setSelectedMPIN,
  metadata,
  fetchResultsForExcel,
  setErrorInput,
  errorDetails
}) {
  //console.log("***********getting data",resultList)
  if (userObj == null) {
    window.location.href = initUrlFun();
  }
  else {
    msid = userObj.sub;
  }
  const allList = {
    ...demographicsDetails,
    ...universalDetails,
    ...platformDetails
  };
  function handleError(field, value) {
    setErrorInput(field, value)
  }
  const filterItems = Object.keys(allList).filter(
    item => allList[item] && allList[item] !== "" && allList[item] !== null
  );
  const actualFilters = filterItems.map(field => {
    const fieldType = fieldList.find(item => item.type === field);
    return {
      ...fieldType,
      value: allList[field]
    };
  });
  const setNewFilterValue = (value, type) => {
    if (Object.keys(demographicsDetails).indexOf(type) !== -1) {
      setDemographicsInput(type, value);
    } else if (Object.keys(universalDetails).indexOf(type) !== -1) {
      setUniversalInput(type, value);
    } else if (Object.keys(platformDetails).indexOf(type) !== -1) {
      setPlatformInput(type, value);
    }
  };
  const fetchResultsOnFilterChange = () => {
    const allSearchKeys = Object.keys(allList).filter(
      key => allList[key] !== ""
    );
    let searchParam = { ...allList, "start": 0, "count": 50, "exCount": 0, "exStart": 0 };
    allSearchKeys.forEach(key => {
      searchParam["exCount"] = "0";
      searchParam["action"] = "filter";
      searchParam["user"] = msid;
      searchParam["isHeaderFilterApplied"] = false;
      // const value = allList[key].replace(/\D/g, "");
      if ("" + key == "telephone") {
        const telephoneRemove = allList[key].replace(/[- )(]/g, "");
        // const code = telephoneRemove.substr(0, 3);
        // const telePho = telephoneRemove.substr(-7);
        // searchParam["areacode"] =
        //   code && code.length > 0 ? code : allList["areacode"];
        searchParam["telephone"] = telephoneRemove
          //telePho && telePho.length > 0 ? telePho : allList["telephone"];
      }
      //else {
      //searchParam[key] = value && value.length > 0 ? value : allList[key];
      //}
    });
    //console.log("search params before server add-------->",searchParam)
    fetchResults(searchParam);
  };
  const fetchResultsOnPageChange = (params) => {
    fetchResults(params);
  }
  const fetchResultsOnExportExcel = (params) => {
    fetchResultsForExcel(params);
    //fetchResultsForExcel
  }
  return (
    <ResultProviderComponent
      fetchingResults={fetchingResults}
      resultList={resultList}
      filterFields={actualFilters}
      removeResultFilter={removeResultFilter}
      setFilterValue={setNewFilterValue}
      fetchResultsOnFilterChange={fetchResultsOnFilterChange}
      setSelectedMPIN={setSelectedMPIN}
      fetchResultsOnPageChange={fetchResultsOnPageChange}
      metadata={metadata}
      fetchResultsOnExportExcel={fetchResultsOnExportExcel}
      handleError={handleError}
      errorDetails={errorDetails}
    />
  );
}


ResultProviderContainer.propTypes = {
  platformDetails: PropTypes.any,
  universalDetails: PropTypes.any,
  demographicsDetails: PropTypes.any,
  resultList: PropTypes.arrayOf(PropTypes.any),
  removeResultFilter: PropTypes.func.isRequired,
  setDemographicsInput: PropTypes.func.isRequired,
  setUniversalInput: PropTypes.func.isRequired,
  setPlatformInput: PropTypes.func.isRequired,
  fetchingResults: PropTypes.bool.isRequired,
  fetchResults: PropTypes.func.isRequired,
  setSelectedMPIN: PropTypes.func.isRequired,
  fetchResultsOnPageChange: PropTypes.func.isRequired,
  metadata: PropTypes.any,
  fetchResultsOnExportExcel: PropTypes.func.isRequired,
  errorDetails: PropTypes.any
};

const mapStateToProps = state => {
  return {
    demographicsDetails: state.demographics,
    universalDetails: state.universals,
    platformDetails: state.platforms,
    resultList: state.result.resultList,
    metadata: state.result,
    fetchingResults: state.result.isFetching,
    excelData: state.result.excelData,
    errorDetails: state.errors
  };
};

const mapDispatchToProps = dispatch => ({
  setDemographicsInput: (field, value) =>
    dispatch(setDemographicsInput(field, value)),
  setUniversalInput: (field, value) =>
    dispatch(setUniversalInput(field, value)),
  setPlatformInput: (field, value) => dispatch(setPlatformInput(field, value)),
  removeResultFilter: fieldName => dispatch(removeResultFilter(fieldName)),
  fetchResults: queryParam => dispatch(fetchResults(queryParam)),
  setSelectedMPIN: value => dispatch(setSelectedMPIN(value)),
  fetchResultsForExcel: queryParam => dispatch(fetchResultsForExcel(queryParam)),
  setErrorInput: (field, value) => dispatch(setErrorInput(field, value))
});

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(ResultProviderContainer);
