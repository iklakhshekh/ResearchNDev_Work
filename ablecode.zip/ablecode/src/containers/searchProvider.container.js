/* eslint-disable */
import React from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { useHistory } from "react-router-dom";
import { getTeleStatusType } from '../utils/fields.constant';

import SearchProviderComponent from '../components/searchProvider/searchProvider.component';
import { setDemographicsInput, setUniversalInput, setPlatformInput, fetchResults, clearResults, clearAll, setErrorInput } from '../actions/action';
const { getCookie } = require('../utils/helper');
import initUrlFun from '../utils/initUrls'
let userObj = JSON.parse(getCookie("openIdInfo"));
let msid;
function SearchProviderContainer({
  demographicsDetails,
  setDemographicsInput,
  setUniversalInput,
  universalDetails,
  setPlatformInput,
  platformDetails,
  fetchResults,
  clearResults,
  setErrorInput,
  errorDetails,
  clearAll }) {
  if (userObj == null) {
    window.location.href = initUrlFun();
  }
  else {
    msid = userObj.sub;
  }
  let history = useHistory();
  const allSearchParams = { ...demographicsDetails, ...universalDetails, ...platformDetails };


  const isSearchParams = Object.keys(allSearchParams).find(param => allSearchParams[param] !== '');

  React.useEffect(() => {
    clearResults();
  });
  function handleDemographicsChange(field, value, isInputValid) {
    setDemographicsInput(field, value, isInputValid);
  }
  function handleUniversalChanges(field, value) {
    setUniversalInput(field, value);
  }
  function handlePlatformChanges(field, value) {
    setPlatformInput(field, value);
  }
  function handleError(field, value) {
    setErrorInput(field, value)
  }
  function handleSearchSubmit(event) {
    if (event) {
      const allSearchKeys = Object.keys(allSearchParams).filter(key => allSearchParams[key] !== '');
      //console.log("searchProvider.container === allSearchKeys ", allSearchKeys)
      if (allSearchKeys == 'telephone') {
        localStorage.setItem("BySerach", "yes");
        getTeleStatusType("Y", "Search");
      }
      let searchParam = { ...allSearchParams };
      allSearchKeys.forEach(key => {
        // const value = allSearchParams[key].replace(/\D/g, '');
        // searchParam[key] = value && value.length > 0 ? value : allSearchParams[key]
        searchParam["count"] = "50";
        searchParam["start"] = "0";
        searchParam["exCount"] = "0";
        searchParam["exStart"] = "0";
        searchParam["action"] = "search";
        searchParam["user"] = msid;
        searchParam["isHeaderFilterApplied"] = false;
        if (key === 'lastGroupName') {
          const lastValue = allSearchParams[key].replace(/^\s+|\s+$/gm, '');
          searchParam[key] = lastValue && lastValue.length > 0 ? lastValue : allSearchParams[key]
        }
        if (key === 'mpin') {
          const mpinRemove = allSearchParams[key].replace(/-/g, "");
          searchParam[key] = mpinRemove && mpinRemove.length > 0 ? mpinRemove : allSearchParams[key]
        }
        if (key === 'telephone') {
          const telephoneRemove = allSearchParams[key].replace(/[- )(]/g, '');
          // const code = telephoneRemove.substr(0, 3);
          // const telePho = telephoneRemove.substr(-7);
          // searchParam['areacode'] = code && code.length > 0 ? code : allSearchParams['areacode'];
          searchParam['telephone'] = telephoneRemove
          //telePho && telePho.length > 0 ? telePho : allSearchParams['telephone'];
        }
        if (key === 'zip') {
          let value = allSearchParams['zip']
          if (value !== '' && value.length >= 3) {
            for (let i = value.length; i < 5; i++) {
              value = '0' + value;
            }
            searchParam['zip'] = value
          }
        }
      });
      history.push("/providers/result-provider");
      const userObj = JSON.parse(getCookie("openIdInfo"));
      searchParam['openIdInfo'] = userObj;
      fetchResults(searchParam);
    }
  }
  function handleClearAll() {
    clearAll();
  }
  return (
    <SearchProviderComponent
      handleDemographicsChange={handleDemographicsChange}
      demographicsDetails={demographicsDetails}
      handleUniversalChanges={handleUniversalChanges}
      universalDetails={universalDetails}
      handlePlatformChanges={handlePlatformChanges}
      platformDetails={platformDetails}
      handleSearchSubmit={handleSearchSubmit}
      clearAll={handleClearAll}
      clearedSearch={Boolean(isSearchParams) === false}
      formError={false}
      handleError={handleError}
      errorDetails={errorDetails}
    />
  );
}

const mapStateToProps = (state) => ({
  demographicsDetails: state.demographics,
  universalDetails: state.universals,
  platformDetails: state.platforms,
  errorDetails: state.errors
});

const mapDispatchToProps = (dispatch) => ({
  setDemographicsInput: (field, value) => dispatch(setDemographicsInput(field, value)),
  setUniversalInput: (field, value) => dispatch(setUniversalInput(field, value)),
  setPlatformInput: (field, value) => dispatch(setPlatformInput(field, value)),
  fetchResults: (queryParam) => dispatch(fetchResults(queryParam)),
  clearResults: () => dispatch(clearResults()),
  clearAll: () => dispatch(clearAll()),
  setErrorInput: (field, value) => dispatch(setErrorInput(field, value))
});

SearchProviderContainer.propTypes = {
  setDemographicsInput: PropTypes.func.isRequired,
  setUniversalInput: PropTypes.func.isRequired,
  setPlatformInput: PropTypes.func.isRequired,
  fetchResults: PropTypes.func.isRequired,
  clearResults: PropTypes.func.isRequired,
  clearAll: PropTypes.func.isRequired,
  platformDetails: PropTypes.any,
  universalDetails: PropTypes.any,
  demographicsDetails: PropTypes.any,
  errorDetails: PropTypes.any
};

export default connect(mapStateToProps, mapDispatchToProps)(SearchProviderContainer);

