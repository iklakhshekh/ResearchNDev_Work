/* eslint-disable */
import 'react-app-polyfill/ie9';
import 'react-app-polyfill/ie11';
import 'react-app-polyfill/stable';
import React from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter } from 'react-router-dom';
import { Provider } from 'react-redux';
import { PersistGate } from 'redux-persist/integration/react';

import './styles/scss/index.scss';
import './styles/custom.css';
import Router from './routers/rootRouter';
import Layout from './layout/layout';
import {store, persistor} from './store/configureStore';
import { UserProvider } from './UserContext';
import Error_page from './Page_Error/Error_page';
ReactDOM.render(
  <Error_page>
  <UserProvider>
  <Provider store={store}>
    <PersistGate loading={null} persistor={persistor}>
      <BrowserRouter>
        <Layout>
          <Router />
        </Layout>
      </BrowserRouter>
    </PersistGate>
  </Provider>
  </UserProvider>
  </Error_page>
  , document.getElementById('root'));
