/* eslint-disable */
import React, { useContext } from 'react';
import { UserContext } from '../UserContext';
import PropTypes from 'prop-types';
import { NavLink } from 'react-router-dom';
import { makeStyles } from '@material-ui/core/styles';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Button from '@material-ui/core/Button';
import UHC_LOGO from '../assets/UHC_LOGO.png';
import AuthorizationError from '../components/authError/authorizationError';
import  initUrlFun   from '../utils/initUrls'


//import {getCookie,setCookie} from '../utils/helper.js';
const { getCookie, setCookie } = require('../utils/helper');
const { SSO_PROD_LINK, SSO_TEST_LINK, SSO_DEV_LINK, SSO_stage_LINK } = require('../SSOConfig/config/index')


const useStyles = makeStyles(() => ({
  modelview: {
    //backgroundColor:"gray",
    textAlign: "center",
    color: "red"
  },
  root: {
    flexGrow: 1,
  },
  customAppBar: {
    boxShadow: '0px 0px 0px 0px'
  },
  customButton: {
    color: '#FFFFFF',
    textTransform: 'none',
    fontWeight: 'bold',
    '&:hover': {
      color: '#3f51b5',
      backgroundColor: '#FFFFFF',
      borderRadius: 0
    }
  },
  toolBarDenseCustom: {
    minHeight: 0
  },
  activeLink: {
    color: '#196ECF',
    backgroundColor: '#FFFFFF',
    borderRadius: 0
  },
  gap: {
    flexGrow: 1
  }
}));
let isChrome = !!window.chrome && (!!window.chrome.webstore || !!window.chrome.runtime);
let isAuthorized = false; let isLoading = true;

const url = SSO_DEV_LINK.URL;

let isIE = /*@cc_on!@*/false || !!document.documentMode;

if (isIE) {
  isIE = false;
}
else {
  isIE = true;
}


if (isIE) {





  if (window.location.hash == "" && (getCookie("oAuthAccessTokenInfo") == "" || getCookie("oAuthAccessTokenInfo") == null)) {
    //console.log('making auth request');
    window.location = url;
  }
  else {


    if (getCookie("openIdInfo") != "" && getCookie("openIdInfo") != null) {
      // var openIdInfo = JSON.parse(getCookie("openIdInfo"));// user info with group
      // var oAuthAccessTokenInfo = getCookie("oAuthAccessTokenInfo").split('|');// oAuthAccessToken info 
      // setCookie("oAuthAccessTokenInfo", oAuthAccessTokenInfo[0]+'|'+oAuthAccessTokenInfo[1], parseInt(oAuthAccessTokenInfo[1]));//setting cookie
      // setCookie("openIdInfo", JSON.stringify(openIdInfo), parseInt(oAuthAccessTokenInfo[1]));//setting cookie
      isAuthorized = true;
    }
    else {


      if (getCookie("openIdInfo") != "" && getCookie("openIdInfo") != null) {
        // var openIdInfo = JSON.parse(getCookie("openIdInfo"));// user info with group
        // var oAuthAccessTokenInfo = getCookie("oAuthAccessTokenInfo").split('|');// oAuthAccessToken info 
        // setCookie("oAuthAccessTokenInfo", oAuthAccessTokenInfo[0]+'|'+oAuthAccessTokenInfo[1], parseInt(oAuthAccessTokenInfo[1]));//setting cookie
        // setCookie("openIdInfo", JSON.stringify(openIdInfo), parseInt(oAuthAccessTokenInfo[1]));//setting cookie
        isAuthorized = true;
      }
      else {
        var hash = window.location.hash.split('&');
        var accessToken = hash[0].split('.')[0].split('=')[1];//for session management
        var accessTokenInfo = JSON.parse(atob(hash[0].split('.')[1]));//for session management
        var openIdToken = hash[1].split('.')[0].split('=')[1];
        var openIdInfo = JSON.parse(atob(hash[1].split('.')[1]));// user info with group
        var minutesDiff = (accessTokenInfo.exp - openIdInfo.iat) / 60;
        //debugger
        if (openIdInfo != undefined) {
          if (openIdInfo.groups.indexOf("Able_dev_user") > -1) {
            setCookie("oAuthAccessTokenInfo", accessToken + '|' + 1, minutesDiff);//setting cookie
            setCookie("openIdInfo", JSON.stringify(openIdInfo), minutesDiff);//setting cookie
            isAuthorized = true;
          }
          isLoading = false;
          window.history.pushState("", "", initUrlFun());
        }
      }
      isLoading = false;
      window.history.pushState("", "", initUrlFun());
    }
  }
}
function Layout({ children }) {
  const classes = useStyles();
  const user = useContext(UserContext);
  function redirect() {
    window.open('https://uhgazure.sharepoint.com/sites/ABLE/_layouts/15/listform.aspx?PageType=8&ListId=%7BDDD9E142-9E20-4D97-81D3-3CFE7BDCD651%7D&RootFolder=%2Fsites%2FABLE%2FLists%2FTicket_List&Source=https%3A%2F%2Fuhgazure.sharepoint.com%2Fsites%2FABLE%2FLists%2FTicket_List%2FAllItems.aspx%3Fviewpath%3D%252Fsites%252FABLE%252FLists%252FTicket_List%252FAllItems.aspx&ContentTypeId=0x0100531E01945C06FF4F9C229B6D3270403C')
  }
  return (
    isIE ?
      isAuthorized ?
        <div className={classes.root}>
          {!user.loggedOut ?
            <AppBar position="static" className={classes.customAppBar}>
              <Toolbar variant="dense" classes={{ dense: classes.toolBarDenseCustom }}>
                {/* <Button classes={{root: classes.customButton}} component={NavLink} to="/members" activeClassName={classes.activeLink}>Members</Button> */}
                <Button classes={{ root: classes.customButton }} component={NavLink} to="/providers" activeClassName={classes.activeLink}>Search Provider</Button>
                <Button classes={{ root: classes.customButton }} component={NavLink} to="/userprofile" activeClassName={classes.activeLink}>User Profile</Button>
                <Button classes={{ root: classes.customButton }} component={NavLink} to="/help" activeClassName={classes.activeLink}>Help</Button>
                <Button classes={{ root: classes.customButton }} component={NavLink} to="/alerts" activeClassName={classes.activeLink}>Alerts</Button>
                <div className={classes.gap} />
                <img src={UHC_LOGO} alt="UHC_LOGO" heigth="38" width="175" />
                {/* <Button classes={{root: classes.customButton}} component={NavLink} to="/contacts" activeClassName={classes.activeLink}>Contact Us</Button> */}
              </Toolbar>
            </AppBar> :
            <AppBar position="static" className={classes.customAppBar}>
              <Toolbar variant="dense" classes={{ dense: classes.toolBarDenseCustom }}>
                <Button classes={{ root: classes.customButton }} onClick={redirect} >Send Feedback</Button>
                <div className={classes.gap} />
                <img src={UHC_LOGO} alt="UHC_LOGO" heigth="38" width="175" />
              </Toolbar>

            </AppBar>
          }
          <div>
            {children}
          </div>
        </div> :
        <AuthorizationError isLoading={isLoading} />
      : <div className={classes.modelview}><br /><b>Sorry to see you go!</b><br /><br /> We have detected the use of an unsupported browser. For the best possible experience, please use Google Chrome.</div>

  );
};


Layout.propTypes = {
  children: PropTypes.node.isRequired
};

export default Layout;
