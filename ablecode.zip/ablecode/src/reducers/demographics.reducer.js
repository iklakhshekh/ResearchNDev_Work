/* eslint-disable */
import { UPDATE_DEMOGRAPHICS, REMOVE_FILTER, CLEAR_ALL } from '../utils/redux.constant';

const initialState = {
    lastGroupName: '',
    firstName: '',
    middleName: '',
    telephone: '',
    state: '',
    zip: '',
};

export default function demographics(state = initialState, action) {
  switch(action.type) {
    case UPDATE_DEMOGRAPHICS:
      return {
        ...state,
        [action.field]: action.value
      };
    case REMOVE_FILTER:
      if (Object.keys(state).indexOf(action.fieldName) !== -1) {
        return {
          ...state,
          [action.fieldName]: ''
        };
      } else {
        return state;
      }
    case CLEAR_ALL:
      return initialState;
    default:
      return state;
  }
}
