/* eslint-disable */
import { UPDATE_DISABLE_BUTTON_ON_ERROR,CLEAR_ALL} from '../utils/redux.constant';

const initialState = {
    disableButton:false,
    ziperror:false,
    pfxsfxerror:false,
    uhciderror:false,
    stateerror:false,
    resetfilter:false,
    speciality:'',
    sequence:'',
    div:'',
    sequenceError:false
};

export default function errors(state = initialState, action) {
    switch(action.type) {
      case UPDATE_DISABLE_BUTTON_ON_ERROR:
        return {
          ...state,
          [action.field]: action.value
        };
      case CLEAR_ALL:
        return initialState;
      default:
        return state;
    }
  }
  