/* eslint-disable */
import { combineReducers } from 'redux';

import demographics from './demographics.reducer';
import universals from './universals.reducer';
import platforms from './platforms.reducers';
import result from './result.reducer';
import errors from './errorReducer'

const rootReducer = combineReducers({
  demographics,
  universals,
  platforms,
  result,
  errors
});

export default rootReducer;
