/* eslint-disable */
import { UPDATE_PLATFORMS, REMOVE_FILTER, CLEAR_ALL } from '../utils/redux.constant';

const initialState = {
    mpin: '',
    ptiMpin: '',
    maid: '',
    baid: '',
    uhcid: '',
    bsar: '',
    hccp: '',
    decFac: '',
    claimId: '',
    pulseId: '',
    cspId: ''
};

export default function platforms(state = initialState, action) {
  switch(action.type) {
    case UPDATE_PLATFORMS:
      return {
        ...state,
        [action.field]: action.value
      };
    case REMOVE_FILTER:
      if (Object.keys(state).indexOf(action.fieldName) !== -1) {
        return {
          ...state,
          [action.fieldName]: ''
        };
      } else {
        return state;
      }
    case CLEAR_ALL:
      return initialState;
    default:
      return state;
  }
}
