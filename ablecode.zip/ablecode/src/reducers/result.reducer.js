/* eslint-disable */
import { FETCHING_SEARCH_RESULTS, FETCHED_SEARCH_RESULTS_SUCCESS_FOR_EXCEL_PARAMS, FETCHED_SEARCH_RESULTS_SUCCESS, REMOVE_RESULTS, SELECTED_MPIN, FETCHED_SEARCH_RESULTS_SUCCESS_FOR_EXCEL, ERROR_RESPONSE, FETCHED_ABLE_PROFILE_PAGE_RESULTS } from '../utils/redux.constant';

const initialState = {
  isFetching: false,
  resultList: [],
  selectedMpin: "",
  metadata: {},
  searchParams: {},
  excelData: [],
  excelSearchParams: {},
  excelMetadata: {},
  errorResponce: false,
  ableProfileData: [],
  isHeavyData: false
};

export default function result(state = initialState, action) {
  switch (action.type) {
    case FETCHING_SEARCH_RESULTS:
      return Object.assign({}, state, {
        isFetching: true,
        resultList: []
      });
    case FETCHED_SEARCH_RESULTS_SUCCESS:
      return Object.assign({}, state, {
        isFetching: false,
        resultList: action.data,
        metadata: action.metadata,
        searchParams: action.searchParams
      });
    case FETCHED_SEARCH_RESULTS_SUCCESS_FOR_EXCEL:
      return Object.assign({}, state, {
        excelData: action.excelData,
        excelMetadata: action.excelMetadata,
        isHeavyData: action.isHeavyData
        // excelSearchParams: action.exParams
      });
    case FETCHED_SEARCH_RESULTS_SUCCESS_FOR_EXCEL_PARAMS:
      return Object.assign({}, state, {
        // excelData:  action.excelData,
        excelSearchParams: action.exParams
      });
    case FETCHED_ABLE_PROFILE_PAGE_RESULTS:
      return Object.assign({}, state, {
        // isFetching: false,
        ableProfileData: action.payload,
        // metadata: action.metadata,
        //  searchParams: action.searchParams
      });
    case REMOVE_RESULTS:
      return Object.assign({}, state, {
        resultList: [],
        selectedMpin: '',
        ableProfileData: [],
      });
    case SELECTED_MPIN:
      return {
        ...state,
        selectedMpin: action.value
      };
    case ERROR_RESPONSE:
      return {
        ...state,
        errorResponce: true,
        isFetching: false,
        
      }
    default:
      return state;
  }
}


