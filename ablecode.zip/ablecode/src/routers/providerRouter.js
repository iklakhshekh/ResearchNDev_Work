/* eslint-disable */
import React from 'react';
import { Switch, Route, Redirect } from 'react-router-dom';

import SearchProviderContainer from '../containers/searchProvider.container';
import ResultProviderContainer from '../containers/resultProvider.container';
import ProviderDetailsContainer from '../containers/providerDetails.container';

const ProviderRouter = () => (
  <Switch>
    <Redirect exact from="/providers" to="/providers/search-provider" />
    <Route path="/providers/home"><>Home Page</></Route>
    <Route path="/providers/search-provider" component={SearchProviderContainer} />
    <Route path="/providers/result-provider" component={ResultProviderContainer} />
    <Route path="/providers/provider-Details" component={ProviderDetailsContainer} />
  
    <Route path="/providers/request-list"><>Request List</></Route>
  </Switch>
);

export default ProviderRouter;
