/* eslint-disable */
import React from 'react';
import { Switch, Redirect, Route } from 'react-router-dom';

import ProviderContainer from '../containers/provider.container';
import UserProfile from '../components/userProfile/userProfile.component'
import Help from '../components/help/help'
import Alerts from '../components/alerts/alert'
import providerLogout from '../components/Logout/logout'

const ProviderRouter = () => (

  <Switch>
    <Redirect exact from="/" to="/providers" />
    <Route path="/providers" component={ProviderContainer} />
    <Route path="/userprofile" component={UserProfile}/>
    <Route path="/help" component={Help}/>
    <Route path="/alerts" component={Alerts}/>
    <Route path="/logout" component={providerLogout} />
    {/* <Route exact path="/members"><>Members</></Route>
    <Route path="/contacts"><>Contact Us</></Route> */}
  </Switch>
 
);

export default ProviderRouter;
