import React from 'react';
import PropTypes from 'prop-types';
import MaskedInput from 'react-text-mask';

export const PhoneMask = props => {
  const { inputRef, ...other } = props;

  return (
    <MaskedInput
      {...other}
      ref={ref => { inputRef(ref ? ref.inputElement : null); }}
      //mask={[/\d/, /\d/, /\d/, ".", /\d/, /\d/, /\d/, ".", /\d/, /\d/, /\d/, /\d/]}
      mask={["(", /\d/, /\d/, /\d/, ")", " ", /\d/, /\d/, /\d/, "-", /\d/, /\d/, /\d/, /\d/]}

      showMask={true}
      guide={false}
      keepCharPositions={true}
    />
  );
};

PhoneMask.propTypes = {
  inputRef: PropTypes.func
};

export const TaxMask = props => {
  const { inputRef, ...other } = props;

  return (
    <MaskedInput
      {...other}
      ref={ref => { inputRef(ref ? ref.inputElement : null); }}
      mask={[/\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/]}
      showMask={true}
      guide={false}
      keepCharPositions={true}
    />
  );
};

TaxMask.propTypes = {
  inputRef: PropTypes.func
};


export const ZipMask = props => {
  const { inputRef, ...other } = props;

  return (
    <MaskedInput
      {...other}
      ref={ref => { inputRef(ref ? ref.inputElement : null); }}
      mask={[/\d/, /\d/, /\d/, /\d/, /\d/]}

      showMask={true}
      guide={false}
      keepCharPositions={true}
    />
  );
};

ZipMask.propTypes = {
  inputRef: PropTypes.func
};

export const MpinMask = props => {
  const { inputRef, ...other } = props;

  return (
    <MaskedInput
      {...other}
      ref={ref => { inputRef(ref ? ref.inputElement : null); }}
      mask={[/\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/]}

      showMask={true}
      guide={false}
      keepCharPositions={true}
    />
  );
};

MpinMask.propTypes = {
  inputRef: PropTypes.func
};


export const NpiMask = props => {
  const { inputRef, ...other } = props;

  return (
    <MaskedInput
      {...other}
      ref={ref => { inputRef(ref ? ref.inputElement : null); }}
      mask={[/\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/]}

      showMask={true}
      guide={false}
      keepCharPositions={true}
    />
  );
};

NpiMask.propTypes = {
  inputRef: PropTypes.func
};

export const UhcidMask = props => {
  const { inputRef, ...other } = props;

  return (
    <MaskedInput
      {...other}
      ref={ref => { inputRef(ref ? ref.inputElement : null); }}
      //mask={[/\d/, /\d/, /\d/, ".", /\d/, /\d/, /\d/, ".", /\d/, /\d/, /\d/, /\d/]}
      mask={[/\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /[a-zA-Z]/, /[a-zA-Z]/, /[a-zA-Z]/]}
      showMask={true}
      guide={false}
      keepCharPositions={true}
    />
  );
};

UhcidMask.propTypes = {
  inputRef: PropTypes.func
};

export const UhcidMaskInResult = props => {
  const { inputRef, ...other } = props;

  return (
    <MaskedInput
      {...other}
      ref={ref => { inputRef(ref ? ref.inputElement : null); }}
      //mask={[/\d/, /\d/, /\d/, ".", /\d/, /\d/, /\d/, ".", /\d/, /\d/, /\d/, /\d/]}
      mask={[/[0-9a-zA-Z]/, /[0-9a-zA-z]/, /[0-9a-zA-Z]/, /[0-9]/, "-", /[0-9]/, /[0-9]/, /[0-9]/, /[0-9]/, /[0-9]/, /[0-9]/, /[0-9]/, "-", /[a-zA-Z]/, /[a-zA-Z]/, /[a-zA-Z]/]}
      showMask={true}
      guide={false}
      keepCharPositions={true}
    />
  );
};

UhcidMaskInResult.propTypes = {
  inputRef: PropTypes.func
};

export const SSNMask = props => {
  const { inputRef, ...other } = props;

  return (
    <MaskedInput
      {...other}
      ref={ref => { inputRef(ref ? ref.inputElement : null); }}
      mask={[/[0-9*?]/, /[0-9*?]/, /[0-9*?]/, /[0-9*?]/, /[0-9*?]/, /[0-9*?]/, /[0-9*?]/, /[0-9*?]/, /[0-9*?]/,]}

      showMask={true}
      guide={false}
      keepCharPositions={true}
    />
  );
};

SSNMask.propTypes = {
  inputRef: PropTypes.func
};

export const PTIMpinMask = props => {
  const { inputRef, ...other } = props;

  return (
    <MaskedInput
      {...other}
      ref={ref => { inputRef(ref ? ref.inputElement : null); }}
      mask={[/\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/]}

      showMask={true}
      guide={false}
      keepCharPositions={true}
    />
  );
};

PTIMpinMask.propTypes = {
  inputRef: PropTypes.func
};

export const MaidMask = props => {
  const { inputRef, ...other } = props;

  return (
    <MaskedInput
      {...other}
      ref={ref => { inputRef(ref ? ref.inputElement : null); }}
      mask={[/\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/]}

      showMask={true}
      guide={false}
      keepCharPositions={true}
    />
  );
};

MaidMask.propTypes = {
  inputRef: PropTypes.func
};

export const BaidMask = props => {
  const { inputRef, ...other } = props;

  return (
    <MaskedInput
      {...other}
      ref={ref => { inputRef(ref ? ref.inputElement : null); }}
      mask={[/\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/]}

      showMask={true}
      guide={false}
      keepCharPositions={true}
    />
  );
};

BaidMask.propTypes = {
  inputRef: PropTypes.func
};

export const BsarMask = props => {
  const { inputRef, ...other } = props;

  return (
    <MaskedInput
      {...other}
      ref={ref => { inputRef(ref ? ref.inputElement : null); }}
      mask={[/\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/]}

      showMask={true}
      guide={false}
      keepCharPositions={true}
    />
  );
};

BsarMask.propTypes = {
  inputRef: PropTypes.func
};

export const CspidMask = props => {
  const { inputRef, ...other } = props;

  return (
    <MaskedInput
      {...other}
      ref={ref => { inputRef(ref ? ref.inputElement : null); }}
      mask={[/\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, " ", /\d/, /\d/, /\d/]}

      showMask={true}
      guide={false}
      keepCharPositions={true}
    />
  );
};

CspidMask.propTypes = {
  inputRef: PropTypes.func
};

export const PrefixSuffixMask = props => {
  const { inputRef, ...other } = props;

  return (
    <MaskedInput
      {...other}
      ref={ref => { inputRef(ref ? ref.inputElement : null); }}
      mask={[/\d/, " ", /\d/, /\d/, /\d/, /\d/, /\d/]}

      showMask={true}
      guide={false}
      keepCharPositions={true}
    />
  );
};

PrefixSuffixMask.propTypes = {
  inputRef: PropTypes.func
};

export const SpecialityMask = props => {
  const { inputRef, ...other } = props;

  return (
    <MaskedInput
      {...other}
      ref={ref => { inputRef(ref ? ref.inputElement : null); }}
      mask={[/\d/, /\d/, /\d/, /\d/]}

      showMask={true}
      guide={false}
      keepCharPositions={true}
    />
  );
};

SpecialityMask.propTypes = {
  inputRef: PropTypes.func
};

export const SequenceMask = props => {
  const { inputRef, ...other } = props;

  return (
    <MaskedInput
      {...other}
      ref={ref => { inputRef(ref ? ref.inputElement : null); }}
      mask={[/\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/]}
      showMask={true}
      guide={false}
      keepCharPositions={true}
    />
  );
};

SequenceMask.propTypes = {
  inputRef: PropTypes.func
};

export const DivMask = props => {
  const { inputRef, ...other } = props;

  return (
    <MaskedInput
      {...other}
      ref={ref => { inputRef(ref ? ref.inputElement : null); }}
      mask={[/[a-zA-Z]/, /[a-zA-Z]/, /[a-zA-Z]/]}
      showMask={true}
      guide={false}
      keepCharPositions={true}
    />
  );
};

DivMask.propTypes = {
  inputRef: PropTypes.func
}

export const StateMask = props => {
  // console.log("StateMask ====== ", props)
  const { inputRef, ...other } = props;

  return (
    <MaskedInput
      {...other}
      ref={ref => { inputRef(ref ? ref.inputElement : null); }}
      // mask={[/[a-zA-Z]/, /[a-zA-Z]/, /[a-zA-Z]/, /[a-zA-Z]/, /[a-zA-Z]/, /[a-zA-Z]/, /[a-zA-Z]/, /[a-zA-Z]/, /[a-zA-Z]/, /[a-zA-Z]/]}
      // mask={[/(?!.*[DFIOQU])[A-VXY]/i]}
      // mask={[!/^[a-zA-Z]*$/g]}
      //e.target.value = e.target.value.replace(/[^\dA-Z]/g, '').replace(/(.{4})/g, '$1 ').trim();
      mask={[/[a-zA-Z]/, /[a-zA-Z]/, ",", /[a-zA-Z]/, /[a-zA-Z]/, ",", /[a-zA-Z]/, /[a-zA-Z]/, ",", /[a-zA-Z]/, /[a-zA-Z]/, ",", /[a-zA-Z]/, /[a-zA-Z]/, ",", /[a-zA-Z]/, /[a-zA-Z]/, ",", /[a-zA-Z]/, /[a-zA-Z]/, ",", /[a-zA-Z]/, /[a-zA-Z]/, ",",
        /[a-zA-Z]/, /[a-zA-Z]/, ",", /[a-zA-Z]/, /[a-zA-Z]/, ",", /[a-zA-Z]/, /[a-zA-Z]/, ",", /[a-zA-Z]/, /[a-zA-Z]/, ",", /[a-zA-Z]/, /[a-zA-Z]/, ",", /[a-zA-Z]/, /[a-zA-Z]/, ",", /[a-zA-Z]/, /[a-zA-Z]/, ",", /[a-zA-Z]/, /[a-zA-Z]/, ",",
        /[a-zA-Z]/, /[a-zA-Z]/, ",", /[a-zA-Z]/, /[a-zA-Z]/, ",", /[a-zA-Z]/, /[a-zA-Z]/, ",", /[a-zA-Z]/, /[a-zA-Z]/, ",", /[a-zA-Z]/, /[a-zA-Z]/, ",", /[a-zA-Z]/, /[a-zA-Z]/, ",", /[a-zA-Z]/, /[a-zA-Z]/, ",", /[a-zA-Z]/, /[a-zA-Z]/, ",",
        /[a-zA-Z]/, /[a-zA-Z]/, ",", /[a-zA-Z]/, /[a-zA-Z]/, ",", /[a-zA-Z]/, /[a-zA-Z]/, ",", /[a-zA-Z]/, /[a-zA-Z]/, ",", /[a-zA-Z]/, /[a-zA-Z]/, ",", /[a-zA-Z]/, /[a-zA-Z]/, ",", /[a-zA-Z]/, /[a-zA-Z]/, ",", /[a-zA-Z]/, /[a-zA-Z]/, ",",
        /[a-zA-Z]/, /[a-zA-Z]/, ",", /[a-zA-Z]/, /[a-zA-Z]/, ",", /[a-zA-Z]/, /[a-zA-Z]/, ",", /[a-zA-Z]/, /[a-zA-Z]/, ",", /[a-zA-Z]/, /[a-zA-Z]/, ",", /[a-zA-Z]/, /[a-zA-Z]/, ",", /[a-zA-Z]/, /[a-zA-Z]/, ",", /[a-zA-Z]/, /[a-zA-Z]/, ",",
        /[a-zA-Z]/, /[a-zA-Z]/, ",", /[a-zA-Z]/, /[a-zA-Z]/, ",", /[a-zA-Z]/, /[a-zA-Z]/, ",", /[a-zA-Z]/, /[a-zA-Z]/, ",", /[a-zA-Z]/, /[a-zA-Z]/, ",", /[a-zA-Z]/, /[a-zA-Z]/, ",", /[a-zA-Z]/, /[a-zA-Z]/, ",", /[a-zA-Z]/, /[a-zA-Z]/, ",",
        /[a-zA-Z]/, /[a-zA-Z]/, ",", /[a-zA-Z]/, /[a-zA-Z]/, ",", /[a-zA-Z]/, /[a-zA-Z]/, ",", /[a-zA-Z]/, /[a-zA-Z]/, ",", /[a-zA-Z]/, /[a-zA-Z]/, ",", /[a-zA-Z]/, /[a-zA-Z]/, ",", /[a-zA-Z]/, /[a-zA-Z]/, ",", /[a-zA-Z]/, /[a-zA-Z]/
      ]}
      // mask={['(', /[1-9]/, /\d/, /\d/, ')', ' ', /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/]}
      // mask={[/[^\dA-Z]/g, '']}
      showMask={true}
      guide={false}
      keepCharPositions={true}
    />
  );
};

StateMask.propTypes = {
  inputRef: PropTypes.func
};