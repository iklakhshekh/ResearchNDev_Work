/* eslint-disable */
export default [
  {
    type: 'lastGroupName',
    label: 'Last/Group Name',
    isDisabled: false
  },
  {
    type: 'firstName',
    label: 'First Name',
    isDisabled: false
  },
  {
    type: 'middleName',
    label: 'Middle Name',
    isDisabled: false
  },
  {
    type: 'telephone',
    label: 'Telephone',
    isDisabled: false
  },
  {
    type: 'state',
    label: 'State',
    isDisabled: false
  },
  {
    type: 'zip',
    label: 'Zip Code',
    isDisabled: false
  },
  {
    type: 'taxId',
    label: 'TAXID',
    isDisabled: false
  },
  {
    type: 'ssn',
    label: 'SSN',
    isDisabled: false
  },
  {
    type: 'npi',
    label: 'NPI',
    isDisabled: false
  },
  {
    type: 'pfxsfx',
    label: 'PFX/SFX',
    isDisabled: false
  },
  {
    type: 'mpin',
    label: 'MPIN',
    isDisabled: false
  },
  {
    type: 'ptiMpin',
    label: 'PTI MPIN',
    isDisabled: false
  },
  {
    type: 'maid',
    label: 'MAID',
    isDisabled: false
  },
  {
    type: 'baid',
    label: 'BAID',
    isDisabled: false
  },
  {
    type: 'uhcid',
    label: 'UHCID',
    isDisabled: false
  },
  {
    type: 'hccp',
    label: 'HCCP',
    isDisabled: true
  },
  {
    type: 'decFac',
    label: 'DEC-FAC',
    isDisabled: true
  },
  {
    type: 'claimId',
    label: 'Claim ID',
    isDisabled: true
  },
  {
    type: 'pulseId',
    label: 'Pulse Provider ID',
    isDisabled: true
  }
  // {
  //   type: 'cspId',
  //   label: 'CSP ID',
  //   isDisabled: true
  // }
  // {
  //   type: 'altLastGroupName',
  //   label: 'alt Last/Group Name',
  //   isDisabled: false
  // },
  // {
  //   type: 'altFirstName',
  //   label: 'alt First Name',
  //   isDisabled: false
  // },
  // {
  //   type: 'altMiddleName',
  //   label: 'alt Middle Name',
  //   isDisabled: false
  // },
  // {
  //   type: 'bsar',
  //   label: 'BSAR',
  //   isDisabled: true
  // }
];


export function getAddressType(value) {
  switch (value) {


    case "H":
      return "BILL";
    case "L":
      return "PLSV";
    case "D":
      return "COMB";
    case "P":
      return "CRED";
    case "T":
      return "MAIL";
    default:
  }
}
export function getCosmosStatusType(value) {
  switch (value) {
    case "I":
      return "INACTIVE CSP";
    case "N":
      return "ACTIVE CSP";
    case "P":
      return "ACTIVE CSP AND AGREEMENT ID's";

    default:
      return "";
  }

}

export function getgender(value) {
  switch (value) {
    case "M":
      return "MALE";
    case "F":
      return "FEMALE";
    case "U":
      return "Unknown";


    default:
      return "";
  }

}

export function getStatefullname(value) {
  switch (value) {
    case "AK":
      return "Alaska";
    case "AZ":
      return "Arizona";
    case "AL":
      return "Alabama";
    case "AR":
      return "Arkansas";
    case "CA":
      return "California";
    case "CO":
      return "Colorado";
    case "CT":
      return "Connecticut";
    case "DE":
      return "Delaware";
    case "FL":
      return "Florida";
    case "GA":
      return "Georgia";
    case "HI":
      return "Hawaii";
    case "ID":
      return "Idaho";
    case "IL":
      return "Illinois";
    case "IN":
      return "Indiana";
    case "IA":
      return "Iowa";
    case "KS":
      return "Kansas";
    case "KY":
      return "Kentucky";
    case "LA":
      return "Louisiana";
    case "ME":
      return "Maine";
    case "MD":
      return "Maryland";
    case "MA":
      return "Massachusetts";
    case "MI":
      return "Michigan";
    case "MN":
      return "Minnesota";
    case "WY":
      return "Wyoming";
    case "WI":
      return "Wisconsin";
    case "WV":
      return "West Virginia";
    case "WA":
      return "Washington";
    case "VA":
      return "Virginia";
    case "VT":
      return "Vermont";
    case "UT":
      return "Utah";
    case "TX":
      return "Texas";
    case "TN":
      return "Tennessee";
    case "SD":
      return "South Dakota";
    case "SC":
      return "South Carolina";
    case "RI":
      return "Rhode Island";
    case "PA":
      return "Pennsylvania";
    case "OR":
      return "Oregon";
    case "OK":
      return "Oklahoma";
    case "OH":
      return "Ohio";
    case "ND":
      return "North Dakota";
    case "NY":
      return "New York";
    case "NM":
      return "New Mexico";
    case "NJ":
      return "New Jersey";
    case "NH":
      return "New Hampshire";
    case "NV":
      return "Nevada";
    case "NE":
      return "Nebraska";
    case "MT":
      return "Montana";
    case "MO":
      return "Missouri";
    case "MS":
      return "Mississippi";
    case "MS":
      return "Mississippi";

    case "NC":
      return "North Carolina";
    case "DC":
      return "District of Columbia";
    case "PR":
      return "Puerto Rico";
    case "VI":
      return "Virgin Islands";



    default:
      return "";
  }

}

export function getTeleStatusType(Y, form) {
  if (form == 'Search') {

    return Y;
  } else if (form == 'Tabel') {

    return Y;

  }
}

export const states = [
  {
    label: 'AK',
    value: 'AK'
  }, {
    label: 'AZ',
    value: 'AZ'
  }, {
    label: 'AL',
    value: 'AL'
  }, {
    label: 'AR',
    value: 'AR'
  }, {
    label: 'CA',
    value: 'CA'
  }, {
    label: 'CO',
    value: 'CO'
  }, {
    label: 'CT',
    value: 'CT'
  }, {
    label: 'DC',
    value: 'DC'
  }, {
    label: 'DE',
    value: 'DE'
  }, {
    label: 'FL',
    value: 'FL'
  }, {
    label: 'GA',
    value: 'GA'
  }, {
    label: 'HI',
    value: 'HI'
  }, {
    label: 'ID',
    value: 'ID'
  }, {
    label: 'IL',
    value: 'IL'
  }, {
    label: 'IN',
    value: 'IN'
  }, {
    label: 'IA',
    value: 'IA'
  }, {
    label: 'KS',
    value: 'KS'
  }, {
    label: 'KY',
    value: 'KY'
  }, {
    label: 'LA',
    value: 'LA'
  }, {
    label: 'ME',
    value: 'ME'
  }, {
    label: 'MD',
    value: 'MD'
  }, {
    label: 'MA',
    value: 'MA'
  }, {
    label: 'MI',
    value: 'MI'
  }, {
    label: 'MN',
    value: 'MN'
  }, {
    label: 'MS',
    value: 'MS'
  }, {
    label: 'MO',
    value: 'MO'
  }, {
    label: 'MT',
    value: 'MT'
  }, {
    label: 'NE',
    value: 'NE'
  }, {
    label: 'NV',
    value: 'NV'
  }, {
    label: 'NH',
    value: 'NH'
  }, {
    label: 'NJ',
    value: 'NJ'
  }, {
    label: 'NM',
    value: 'NM'
  }, {
    label: 'NY',
    value: 'NY'
  }, {
    label: 'NC',
    value: 'NC'
  }, {
    label: 'ND',
    value: 'ND'
  }, {
    label: 'OH',
    value: 'OH'
  }, {
    label: 'OK',
    value: 'OK'
  }, {
    label: 'OR',
    value: 'OR'
  }, {
    label: 'PA',
    value: 'PA'
  }, {
    label: 'PR',
    value: 'PR'
  }, {
    label: 'RI',
    value: 'RI'
  }, {
    label: 'SC',
    value: 'SC'
  }, {
    label: 'SD',
    value: 'SD'
  }, {
    label: 'TN',
    value: 'TN'
  }, {
    label: 'TX',
    value: 'TX'
  }, {
    label: 'UT',
    value: 'UT'
  }, {
    label: 'VA',
    value: 'VA'
  }, {
    label: 'VI',
    value: 'VI'
  }, {
    label: 'VT',
    value: 'VT'
  }, {
    label: 'WA',
    value: 'WA'
  }, {
    label: 'WV',
    value: 'WV'
  }, {
    label: 'WI',
    value: 'WI'
  }, {
    label: 'WY',
    value: 'WY'
  }];