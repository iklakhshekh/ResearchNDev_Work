/* eslint-disable */
 export default function initUrlFun() {
    // alert('SET ENV VARIABLE')
    let initUrl = '';
    let LOCAL_ENV = true;
    let DEVELOPMENT_ENV = false;
    let TEST_ENV = false;
    let STAGE_ENV = false;
    let PRODUCTION_ENV = false;
    if (LOCAL_ENV == true)
        initUrl = 'http://localhost:50911/';
    else if (DEVELOPMENT_ENV)
        initUrl = 'http://abledev.uhg.com/';
    else if (TEST_ENV)
        initUrl = 'http://abletest.uhg.com/';
    else if (STAGE_ENV)
        initUrl = 'https://ablestage.uhg.com/';
    else if (PRODUCTION_ENV)
        initUrl = 'http://able.ugh.com/';
    else
        initUrl = 'http://localhost:50911/';

    return initUrl
}

