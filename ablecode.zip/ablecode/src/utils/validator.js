export default function validateField(field, value) {
  let isValid = false;
  const regExName = new RegExp(/^[a-zA-Z0-9`~!@#$&%^*()¢_+\-=[\]{};':,.\\<>/?\s]{0,25}$/);
  const regLastName = new RegExp(/^[a-zA-Z0-9`~!@#$&%^*()¢_+\-=[\]{};':,.\\<>/?\s]{0,66}$/);
  const regExNumHyphen = new RegExp(/^[0-9-/]*$/);
  const regExNumPeriod = new RegExp(/^[0-9-+()\s]*$/);
  const regExNumOnly = new RegExp(/^[0-9]*$/);
  switch (field) {
    case 'lastGroupName':
      if (value.match(regLastName || value === '')) {
         isValid = true;
      
      }
      break;
     case 'firstName':
    case 'middleName':
        if (value.match(regExName) || value === '') {
           isValid = true;
         }
        break;
    case 'telephone':
        if (value.match(regExNumPeriod)) {
         const telnum = value.replace(/\D/g,'');
         telnum.replace(/\D/g,'(');
         telnum.replace(/\D/g,')');
          telnum.replace(/\s/g, '');
       //console.log("telnum"+telnum);
          isValid = true;
          if (telnum.length === 10 || value === '') {
            isValid = true;
          }
        }
        break;
    case 'zip':
      if (value.match(regExNumHyphen)) {
        const zipNum = value.replace(/\D/g,'');
        isValid = true
        if (zipNum.length === 5 || value === '') {
          isValid = true;
        }
      }
      break;
    case 'npi':
      if (value.match(regExNumOnly)) {
        if (isValidNPI(value)) {
          isValid = true;
        }
        isValid = true
      } else if (value.length === 0) {
        isValid = true;
      }
      break;
    case 'mpin':
      if (value.match(regExNumHyphen)) {
        const mpinNum = value.replace(/\D/g,'');
        if (mpinNum.length <= 9){
          isValid = true;
        }
      }
      break;
    default:
      isValid = true;
  }
  return isValid;
}

function isValidNPI(input) {
  const npi = input.toString(10).split("").map(Number);
  let total = 0;
  npi.forEach((val, index) => {
    if (index % 2 === 0) {
      const temp = val * 2;
      if (temp > 9) {
        total += Math.floor(temp / 10) + (temp % 10);
      } else {
        total += temp;
      }
    } else {
      total += val;
    }
  });
  return ((total + 24) % 10 === 0)
}